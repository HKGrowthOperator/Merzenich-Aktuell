<?php
if (!defined('ABSPATH')) { exit; }

function ma_register_content_types(): void {
    register_taxonomy('ma_location', ['post','ma_event','ma_property','ma_job','ma_obituary','ma_family_notice','ma_club','ma_business','ma_tip'], [
        'labels' => ['name'=>'Orte','singular_name'=>'Ort'],
        'public'=>true,
        'hierarchical'=>true,
        'show_in_rest'=>true,
        'rewrite'=>['slug'=>'ort'],
    ]);

    $types = [
        // Adressen wie im statischen Stand: /termine/<slug>/ und /jobs/
        // (Audit 28.09.2026, includes/permalinks.php).
        'ma_event' => ['Veranstaltungen','Veranstaltung','termine','dashicons-calendar-alt'],
        'ma_property' => ['Immobilien','Immobilie','immobilien','dashicons-building'],
        'ma_job' => ['Stellen','Stelle','jobs','dashicons-businessperson'],
        'ma_obituary' => ['Traueranzeigen','Traueranzeige','traueranzeigen','dashicons-heart'],
        'ma_family_notice' => ['Familienanzeigen','Familienanzeige','familienanzeigen','dashicons-groups'],
        'ma_club' => ['Vereine','Verein','vereine','dashicons-groups'],
        // Beschriftung "Unternehmen" wie in der Navigation; die Adresse
        // /betriebe/ bleibt, damit bestehende Links weiter funktionieren.
        'ma_business' => ['Unternehmen','Unternehmen','betriebe','dashicons-store'],
        'ma_tip' => ['Tipps','Tipp','tipp','dashicons-star-filled'],
        'ma_ad' => ['Werbung','Werbemittel','werbung','dashicons-megaphone'],
    ];

    foreach ($types as $slug => $d) {
        register_post_type($slug, [
            'labels'=>[
                'name'=>$d[0],
                'singular_name'=>$d[1],
                'add_new_item'=>$d[1].' hinzufügen',
                'edit_item'=>$d[1].' bearbeiten',
            ],
            'public'=>$slug !== 'ma_ad',
            'show_ui'=>true,
            'show_in_rest'=>true,
            'has_archive'=>$slug !== 'ma_ad' ? $d[2] : false,
            'rewrite'=>$slug !== 'ma_ad' ? ['slug'=>$d[2]] : false,
            'menu_icon'=>$d[3],
            // Werbemittel (02.10.2026): kein Inhaltsfeld, kein Block-Editor. Die Anzeige
            // besteht aus Titel, Bild, Kurztext und den Feldern der Werbeschaltung.
            'supports'=>$slug === 'ma_ad' ? ['title','excerpt','thumbnail','author'] : ['title','editor','excerpt','thumbnail','author'],
        ]);
    }

    register_taxonomy('ma_family_type','ma_family_notice',[
        'labels'=>['name'=>'Anlass','singular_name'=>'Anlass'],
        'public'=>true,
        'hierarchical'=>true,
        'show_in_rest'=>true,
    ]);
}
add_action('init','ma_register_content_types');
// Anzeigen im klassischen Formular auf einem Bildschirm, nie im Block-Editor.
add_filter('use_block_editor_for_post_type', fn($use, $typ) => $typ === 'ma_ad' ? false : $use, 10, 2);
add_filter('enter_title_here', fn($t, $p) => $p instanceof WP_Post && $p->post_type === 'ma_ad' ? 'Name der Anzeige (intern; dient als Alternativtext, wenn keiner gesetzt ist)' : $t, 10, 2);

function ma_meta(string $key, int $post_id = 0, $default = '') {
    $post_id = $post_id ?: get_the_ID();
    $value = get_post_meta($post_id, $key, true);
    return $value === '' ? $default : $value;
}

function ma_event_timestamp(int $post_id, string $kind='start'): int {
    $key = $kind === 'end' ? 'ma_event_end' : 'ma_event_start';
    $v = (string)get_post_meta($post_id, $key, true);
    if (!$v && $kind === 'end') $v = (string)get_post_meta($post_id, 'ma_event_start', true);
    if (!$v) return 0;

    try {
        return (new DateTimeImmutable($v, wp_timezone()))->getTimestamp();
    } catch (Exception $e) {
        return 0;
    }
}

/** Liegt der Termin (Ende, sonst Beginn) in der Vergangenheit? */
function ma_event_vorbei(int $post_id): bool {
    $ende = ma_event_timestamp($post_id, 'end');
    return $ende > 0 && $ende < time();
}

function ma_upcoming_events(int $limit=6): array {
    $now = current_time('timestamp');
    $q = new WP_Query([
        'post_type'=>'ma_event',
        'post_status'=>'publish',
        'posts_per_page'=>50,
        'meta_key'=>'ma_event_start',
        'orderby'=>'meta_value',
        'order'=>'ASC',
    ]);

    $out=[];
    foreach ($q->posts as $p) {
        $end=ma_event_timestamp($p->ID,'end');
        if ($end && $end < $now) continue;
        $out[]=$p;
        if (count($out) >= $limit) break;
    }
    return $out;
}

function ma_active_market_items(string $type, int $limit=3): array {
    $allowed=['ma_property','ma_job','ma_obituary','ma_family_notice','ma_tip'];
    if (!in_array($type,$allowed,true)) return [];

    $now=current_time('Y-m-d H:i:s');
    $q=new WP_Query([
        'post_type'=>$type,
        'post_status'=>'publish',
        'posts_per_page'=>$limit,
        'orderby'=>'date',
        'order'=>'DESC',
        'meta_query'=>[
            'relation'=>'AND',
            ['key'=>'ma_release_confirmed','value'=>'1','compare'=>'='],
            [
                'relation'=>'OR',
                ['key'=>'ma_end_at','compare'=>'NOT EXISTS'],
                ['key'=>'ma_end_at','value'=>'','compare'=>'='],
                ['key'=>'ma_end_at','value'=>$now,'compare'=>'>=','type'=>'DATETIME'],
            ],
        ],
    ]);
    return $q->posts;
}

function ma_filter_public_service_archives(WP_Query $query): void {
    if (is_admin() || !$query->is_main_query()) return;

    $post_type=$query->get('post_type');
    if (is_array($post_type)) return;

    if (in_array($post_type,['ma_property','ma_job','ma_obituary','ma_family_notice','ma_tip'],true) || $query->is_post_type_archive(['ma_property','ma_job','ma_obituary','ma_family_notice','ma_tip'])) {
        $now=current_time('Y-m-d H:i:s');
        $query->set('meta_query',[
            'relation'=>'AND',
            ['key'=>'ma_release_confirmed','value'=>'1','compare'=>'='],
            [
                'relation'=>'OR',
                ['key'=>'ma_end_at','compare'=>'NOT EXISTS'],
                ['key'=>'ma_end_at','value'=>'','compare'=>'='],
                ['key'=>'ma_end_at','value'=>$now,'compare'=>'>=','type'=>'DATETIME'],
            ],
        ]);
        $query->set('orderby','date');
        $query->set('order','DESC');
        return;
    }

    // Listen zeigen nur Kommendes; die Einzelansicht eines vergangenen Termins bleibt erreichbar
    // (Archiv, Sitemap, Suchmaschinen; vorher 404 bei jedem alten Link).
    if (($post_type==='ma_event' || $query->is_post_type_archive('ma_event')) && !$query->is_singular()) {
        // 1.45.1: IDs der kommenden Termine statt meta_query (includes/termine-abfrage.php); vorher 2 bis 4 s je Aufruf.
        $ids = function_exists('ma_termine_kommend_ids') ? ma_termine_kommend_ids() : [];
        $query->set('posts_per_page',20);
        $query->set('post__in',$ids ?: [0]);
        $query->set('orderby','post__in');
    }
}
add_action('pre_get_posts','ma_filter_public_service_archives');

// Trauer- und Familienanzeigen: noindex kommt aus includes/seo.php (Robots-Regel je Seitentyp).
