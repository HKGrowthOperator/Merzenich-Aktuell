<?php
/**
 * SEO und Geo (02.10.2026): Was Suchmaschinen, Nachrichtendienste und
 * KI-Suchen über jede Seite von Merzenich Aktuell wissen sollen.
 *
 * Bisher gab WordPress nur den Titel und auf Einzelseiten ein Canonical aus.
 * Dieses Modul ergänzt je Seite: Description, Canonical (auch Startseite und
 * Listen), Robots-Regel, Open Graph und Twitter Card, Geo-Angaben
 * (Gemeinde Merzenich, Ortsteil), strukturierte Daten als JSON-LD
 * (NewsMediaOrganization, WebSite, NewsArticle, CollectionPage mit ItemList,
 * Place, Event, Organization für Vereine, BreadcrumbList) sowie eine
 * News-Sitemap (/news-sitemap.xml), eine bereinigte Standard-Sitemap (keine
 * Benutzer, keine Trauer- und Familienanzeigen), robots.txt-Zeilen und
 * /llms.txt für KI-Suchen.
 *
 * Adressen: Die Ressorts laufen unter /blaulicht/, /sport/ … (wie die
 * statische Seite und die Navigation); /category/… leitet dorthin um,
 * Blättern und Feeds funktionieren unter der kurzen Adresse. Autorenarchive
 * (/author/…, zeigen Anmeldenamen) und Anhangsseiten leiten weiter.
 *
 * Nur belegte Angaben: Anbieterin KBS Consulting (Pvt) Ltd (Impressum, seit 27.11.2026), Ortsmitte
 * aus den Wetter-Einstellungen, Ortsteil-Koordinaten nur, wo GeoNames sie
 * führt (Golzheim, Girbelsrath; Abruf 02.10.2026 über die Open-Meteo
 * Geocoding-API). Social-Profile (sameAs) und Verifizierungs-Codes trägt der
 * Betreiber unter Merzenich Aktuell → SEO ein; ohne Eintrag werden sie nicht
 * ausgegeben.
 */
if (!defined('ABSPATH')) { exit; }

const MA_SEO_MARKE = 'Merzenich Aktuell';
const MA_SEO_UNTERTITEL = 'Lokalzeitung online für die Gemeinde Merzenich';
// Andere Schreibweisen des Namens für den Seitennamen in den Google-Treffern (WebSite.alternateName, 1.27.0).
const MA_SEO_NAMEN = ['Merzenich-Aktuell', 'merzenich-aktuell.de'];
// Unter 65 Zeichen, damit Google ihn nicht abschneidet (1.26.0); die Ortsteile stehen in der Beschreibung.
// 1.42.0 (Schlüsselwörter, docs/SEO-KEYWORDS.md): „merzenich aktuell“, „nachrichten merzenich“, „polizei merzenich“, „termine“.
const MA_SEO_STARTTITEL = 'Merzenich Aktuell: Nachrichten aus Merzenich, Polizei, Termine';
// Startseiten-Description: Google zeigt rund 155 Zeichen; die Langfassung steht in llms.txt.
// „Kreis Düren“ grenzt die Gemeinde gegen den Hirnforscher Michael Merzenich und die Bäckerei Merzenich (Köln) ab.
const MA_SEO_BESCHREIBUNG = 'Lokalzeitung für Merzenich im Kreis Düren: Polizei, Feuerwehr, Unfälle, Termine und Rathaus aus Merzenich, Golzheim, Girbelsrath, Morschenich, Bürgewald.';
const MA_SEO_BESCHREIBUNG_LANG = 'Merzenich Aktuell ist die Lokalzeitung online für die Gemeinde Merzenich im Kreis Düren: Nachrichten, Blaulicht, Termine, Vereine und Rathaus aus Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald. Jede Meldung mit Quelle und Bildcredit.';
const MA_SEO_PLZ = '52399';

/** Liegt der Ort eines Termins außerhalb der Gemeinde? Erkennt eine fremde Postleitzahl oder einen Nachbarort im Ortsnamen. */
function ma_ort_auswaerts(string $ort): bool {
    if (preg_match('/\b(\d{5})\b/', $ort, $m)) return $m[1] !== MA_SEO_PLZ;
    return (bool) preg_match('/\b(Düren|Niederzier|Nörvenich|Kerpen|Buir|Jülich|Langerwehe|Inden|Vettweiß|Kreuzau|Heimbach|Nideggen|Aachen|Köln|Online)\b/u', $ort);
}
const MA_SEO_GEBIET = 'Gemeinde Merzenich, Kreis Düren, Nordrhein-Westfalen';

/**
 * Ortsteile: Name, Beschreibung (wie die Ortsseiten der statischen Seite), Koordinaten nur mit Quelle.
 * wikidata/wikipedia (1.38.0): Kennung und deutscher Artikel je Ort, abgerufen am 02.11.2026 bei
 * wikidata.org (wbgetentities: Bezeichnung, Beschreibung „Ortsteil von Merzenich“ bzw. Gemeinde,
 * dewiki-Sitelink; Girbelsrath über P131 = Q200044). Verknüpft die Orte für Suchmaschinen und KI-Suchen.
 */
function ma_seo_orte(): array {
    return [
        // 1.42.0: 'titel' und 'seo' für Google (Suchanfragen „<ort> aktuell“, „unfall <ort> heute“); 'beschreibung' bleibt der Ortstext.
        'merzenich' => ['name' => 'Merzenich', 'beschreibung' => 'Hauptort der Gemeinde mit Rathaus, Bürgerhaus, Pfarrkirche St. Laurentius, Heimatmuseum und S-Bahn-Halt an der Strecke Köln–Aachen.', 'wikidata' => 'Q200044', 'wikipedia' => 'Merzenich',
            'titel' => 'Merzenich (Ort) aktuell: Nachrichten, Blaulicht und Termine', 'seo' => 'Aktuelles aus dem Hauptort Merzenich im Kreis Düren: Polizei und Feuerwehr, Unfälle, Sperrungen, Termine, Vereine und Rathaus, jeweils mit Quelle.'],
        'golzheim' => ['name' => 'Golzheim', 'beschreibung' => 'Ländlicher Ortsteil im Norden der Gemeinde mit Pfarrkirche St. Gregorius, eigener Grundschule, Schützenhalle und einer der ältesten Schützenbruderschaften der Region.', 'lat' => 50.83966, 'lon' => 6.58118, 'wikidata' => 'Q1284626', 'wikipedia' => 'Golzheim_(Merzenich)',
            'titel' => 'Golzheim aktuell: Nachrichten, Blaulicht und Termine', 'seo' => 'Nachrichten aus Golzheim (Gemeinde Merzenich, Kreis Düren): Polizei, Feuerwehr, Unfälle, Schützen, Karneval, Schule und Termine, jeweils mit Quelle.'],
        'girbelsrath' => ['name' => 'Girbelsrath', 'beschreibung' => 'Ortsteil im Süden der Gemeinde mit der Kirche St. Amandus, Sportplatz, eigener Löschgruppe und aktivem Karnevalsverein inmitten der Feldflur Richtung Binsfeld.', 'lat' => 50.81185, 'lon' => 6.55163, 'wikidata' => 'Q1526685', 'wikipedia' => 'Girbelsrath',
            'titel' => 'Girbelsrath aktuell: Nachrichten, Blaulicht und Termine', 'seo' => 'Nachrichten aus Girbelsrath (Gemeinde Merzenich, Kreis Düren): Unfälle auf der L 264, Polizei, Feuerwehr, Karneval, Sport und Termine, jeweils mit Quelle.'],
        'morschenich' => ['name' => 'Morschenich', 'beschreibung' => 'Der ab 2015 bezogene Umsiedlungsort „Zwischen den Höfen“ zwischen Merzenich und Golzheim, bis Juli 2024 Morschenich-Neu genannt, mit Bürgewaldzentrum, Kirche St. Lambertus und aktivem Vereinsleben.', 'wikidata' => 'Q19059925', 'wikipedia' => 'Morschenich',
            'titel' => 'Morschenich aktuell: Nachrichten, Blaulicht und Termine', 'seo' => 'Nachrichten aus Morschenich (Gemeinde Merzenich, Kreis Düren): Bürgewaldzentrum, Vereine, Polizei, Feuerwehr und Termine im Umsiedlungsort, mit Quelle.'],
        'buergewald' => ['name' => 'Bürgewald', 'beschreibung' => 'Das alte Morschenich am Rand des Hambacher Forsts, seit 6. Juli 2024 Bürgewald genannt und als „Ort der Zukunft“ von Gemeinde, Land NRW und RWE gemeinsam neu entwickelt.', 'wikidata' => 'Q1650249', 'wikipedia' => 'Bürgewald_(Merzenich)',
            'titel' => 'Bürgewald aktuell: Ort der Zukunft, Nachrichten und Termine', 'seo' => 'Nachrichten aus Bürgewald, dem alten Morschenich am Hambacher Forst (Gemeinde Merzenich): Ort der Zukunft, Strukturwandel, Bauflächen und Termine.'],
    ];
}

/**
 * Einleitung der Ortsseiten (1.46.0, SEO-GEO-BERICHT 03.11.2026 Befund 7: vorher etwa 25 Wörter).
 * Nur Angaben der Gemeinde Merzenich (Ortsteilseiten unter /politik/ortsteile/ und
 * Pressemitteilung zum Förderbescheid), gelesen am 03.11.2026; in eigenen Worten.
 * Je Ort: Absätze und Quellen [[Name, URL]]. Prüfung zweimal im Jahr (Ortsvorsteher nach Wahlen).
 */
function ma_seo_ort_einleitungen(): array {
    $g = 'https://www.gemeinde-merzenich.de/politik/ortsteile/';
    return [
        'merzenich' => ['absaetze' => [
            'Merzenich ist der Hauptort der Gemeinde: Hier laufen nach Angaben der Gemeinde die Fäden zusammen, knapp 7.000 Menschen leben im Ort. Mit 15,38 Quadratkilometern ist Merzenich auch der flächengrößte Ortsteil.',
            'Erstmals genannt wird Merzenich 1225 in einer Urkunde des Grafen Otto von Neuenahr; 2025 feierte der Ort sein 800-jähriges Bestehen. Wahrzeichen ist die alte katholische Pfarrkirche, um 1300 erstmals erwähnt. Ihr hochgotischer Turm und Reste des spätgotischen Langhauses sind gesichert und stehen heute als Ruine inmitten eines Soldatenfriedhofs.',
            'Die Gesamtschule trägt Merzenich gemeinsam mit Niederzier im Schulverband Niederzier/Merzenich. Das Trinkwasser für Merzenich und Morschenich kommt laut Gemeinde von den Stadtwerken Düren. Ortsvorsteher ist laut Gemeinde Dirk Guder.',
        ], 'quellen' => [['Gemeinde Merzenich, Ortsteil Merzenich', $g . 'merzenich.php']]],
        'golzheim' => ['absaetze' => [
            'Golzheim ist laut Gemeinde der zweitgrößte Ortsteil: Rund 1.300 Menschen leben hier auf 11,31 Quadratkilometern. Erstmals erwähnt wird der Ort 1143 als Godelsheim, später als Goidelsheim (1373) und Goltsheim (1427). Der Name geht vermutlich auf einen fränkischen Personennamen zurück, das Heim des Gotolf oder Godulf.',
            'Besiedelt war Golzheim schon in gallo-römischer Zeit. Ein 1933 gefundener römischer Sarkophag steht heute im Pfarrgarten vor der Fatimakapelle; in der Nähe kamen weitere römische Gräber, Reste einer Villa mit Hypokaustum und der Torso einer Jupiterstatue ans Licht. Im 14. Jahrhundert werden die Ahrburg und die Stachenburg genannt.',
            'Seit dem 1. Juli 1969 gehört Golzheim zur Gemeinde Merzenich. Ortsvorsteher ist laut Gemeinde seit 2020 Ignaz Foerster.',
        ], 'quellen' => [['Gemeinde Merzenich, Ortsteil Golzheim', $g . 'golzheim.php']]],
        'girbelsrath' => ['absaetze' => [
            'Girbelsrath liegt im Süden der Gemeinde; laut Gemeinde leben hier rund 1.200 Menschen auf 4,62 Quadratkilometern. Früher hieß der Ort Gerbätzräude, die Rodung des Gerbrecht. 1382 wurde das Dorf an den Erzbischof von Köln abgetreten, bis 1794 gehörte es zum Dingstuhl und Gericht Hambach im Amt Nörvenich. Im selben Jahr schlugen französische Truppen bei Girbelsrath die Österreicher.',
            'Heute prägt das Gewerbe den Ort: Seit Anfang der 1970er Jahre sind auf ausgewiesenem Gewerbegelände laut Gemeinde rund 600 Arbeitsplätze entstanden. Der frühere Bürgermeister Matthias von den Driesch vermachte der Gemeinde den größten Teil seines Vermögens; der Erlös fördert soziale und kulturelle Zwecke für die Menschen in Girbelsrath.',
            'Seit dem 1. Juli 1969 gehört Girbelsrath zu Merzenich. Ortsvorsteher ist laut Gemeinde Ralf Locker.',
        ], 'quellen' => [['Gemeinde Merzenich, Ortsteil Girbelsrath', $g . 'girbelsrath.php']]],
        'morschenich' => ['absaetze' => [
            'Morschenich ist der jüngste Ort der Gemeinde. Weil das alte Dorf lange dem Tagebau Hambach weichen sollte, entstand zwischen Merzenich und Golzheim die Ortschaft Morschenich-Neu; die Umsiedlung begann im Januar 2015. Seit dem Abschluss der Umsiedlung im Juli 2024 heißt der neue Ort Morschenich, das alte Dorf Bürgewald.',
            'Im Ort gibt es laut Gemeinde mehr als 130 Grundstücke. Die Straßennamen folgen denen des alten Dorfes, und alle Häuser werden über Nahwärme aus einer Pelletheizung versorgt.',
            'Der Name ist alt: 1158 hieß der Ort Morsaz, die heutige Schreibweise ist seit 1775 belegt. Die Stiftung von Ludwig Rixen kommt nach dem Willen des Stifters jedes Jahr Menschen mit wenig Einkommen im Ort zugute. Ortsvorsteherin ist laut Gemeinde Inga Dohmes.',
        ], 'quellen' => [['Gemeinde Merzenich, Ortsteil Morschenich', $g . 'morschenich.php']]],
        'buergewald' => ['absaetze' => [
            'Bürgewald ist das alte Morschenich am Rand des Hambacher Forsts. Lange sollte das Dorf dem Tagebau Hambach weichen. Mit der Leitentscheidung der Landesregierung 2020 stand fest, dass der Ort und der Hambacher Forst bleiben können. Seit dem 6. Juli 2024 trägt der alte Ort den Namen Bürgewald.',
            'Die Gemeinde Merzenich hat den Ort zurückgekauft und entwickelt ihn zum „Ort der Zukunft“. Am 14. Juni 2024 übergab NRW-Ministerin Ina Scharrenbach den ersten Förderbescheid über rund 57 Millionen Euro, davon 40,4 Millionen Euro für den Grunderwerb. Insgesamt stehen laut Gemeinde rund 90 Millionen Euro bereit.',
            'Gebaut werden soll klimaschonend und flächensparend; die abgebrannte Kirche St. Lambertus soll wieder aufgebaut werden. Weil viele Gebäude lange leer standen, rechnet die Gemeinde zugleich mit Rückbau.',
        ], 'quellen' => [['Gemeinde Merzenich, Ortsteil Morschenich', $g . 'morschenich.php'], ['Gemeinde Merzenich, Pressemitteilung „57 Millionen Euro für den Ort der Zukunft“', 'https://www.gemeinde-merzenich.de/aktuelles/pressemitteilungen/uebergabe-foerderbescheid-mo-alt.php']]],
    ];
}

/** HTML der Einleitung einer Ortsseite (reine Funktion, ohne WordPress-Escaping). Leer, wenn der Ort keine hat. */
function ma_seo_ort_einleitung_html(string $slug): string {
    $e = ma_seo_ort_einleitungen()[$slug] ?? null;
    $name = ma_seo_orte()[$slug]['name'] ?? '';
    if (!$e || $name === '') return '';
    $h = fn(string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    $html = '<section class="section ort-einleitung"><div class="shell"><div class="prose"><h2>Über ' . $h($name) . '</h2>';
    foreach ($e['absaetze'] as $a) $html .= '<p>' . $h($a) . '</p>';
    $html .= '<p class="quelle"><small>Quelle: ' . implode(' · ', array_map(fn($q) => '<a href="' . $h($q[1]) . '" target="_blank" rel="noopener">' . $h($q[0]) . '</a>', $e['quellen'])) . '. Stand: 3. November 2026.</small></p>';
    return $html . '</div></div></section>';
}

/** sameAs eines Orts: Wikidata und deutsche Wikipedia (reine Funktion). */
function ma_seo_ort_sameas(array $d): array {
    $aus = [];
    if (!empty($d['wikidata'])) $aus[] = 'https://www.wikidata.org/wiki/' . $d['wikidata'];
    if (!empty($d['wikipedia'])) $aus[] = 'https://de.wikipedia.org/wiki/' . rawurlencode((string) $d['wikipedia']);
    return $aus;
}

/** KI- und Such-Crawler, die robots.txt ausdrücklich zulässt (1.38.0): Zitieren ist gewollt. */
const MA_SEO_KI_CRAWLER = ['GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'PerplexityBot', 'ClaudeBot', 'Claude-SearchBot', 'Google-Extended', 'Bingbot', 'Applebot-Extended'];

/** Ressorts und Listen: Titel und Beschreibung (Texte der statischen Seite). Schlüssel = Adresse /<slug>/. */
function ma_seo_ressorte(): array {
    return [
        // 1.42.0: Titel nach den Suchanfragen (Search Console und Google-Vorschläge, 02.11.2026): „polizeieinsatz merzenich heute“, „unfall merzenich“, „feuerwehr merzenich einsätze“.
        'blaulicht' => ['Blaulicht', 'Polizei, Feuerwehr, Unfall: Blaulicht Merzenich aktuell', 'Polizeieinsätze, Unfälle, Brände und Sperrungen in Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald: Meldungen von Polizei Düren und Feuerwehr, mit Quelle.'],
        'sport' => ['Sport', 'Sport in Merzenich: Fußball, Tischtennis und Ergebnisse', 'Fußball in der Kreisliga, Tischtennis, Schießsport, Turniere und Ergebnisse der Vereine aus allen Ortsteilen.'],
        // „gemeinde merzenich“ (73 Impressionen), „amtsblatt merzenich“, „bürgermeister merzenich“, „gemeinderat“.
        'rathaus' => ['Rathaus & Politik', 'Gemeinde Merzenich: Rathaus, Gemeinderat und Amtsblatt', 'Was Gemeinderat, Ausschüsse und Rathaus Merzenich entscheiden: Beschlüsse, Amtsblatt, Bauvorhaben, Abfall, Steuern und Bürgerbeteiligung, mit Quelle.'],
        'leben' => ['Leben', 'Leben in der Gemeinde Merzenich', 'Feste, Kultur, Kirche, Schule, Freizeit und Alltag in Merzenich und seinen Ortsteilen.'],
        'wirtschaft' => ['Wirtschaft', 'Wirtschaft, Handel und Strukturwandel in Merzenich', 'Betriebe, Handwerk, Gewerbegebiete, Förderprogramme wie LEADER und der Strukturwandel im Rheinischen Revier rund um Merzenich.'],
        'menschen' => ['Menschen', 'Menschen aus Merzenich', 'Jubiläen, Hochzeiten, Ehrungen, Nachrufe und Porträts: die Menschen hinter den Meldungen.'],
        'vereine' => ['Vereine', 'Vereine in der Gemeinde Merzenich', 'Wer in Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald aktiv ist: Schützen, Sport, Karneval, Feuerwehr, Kirche und Ehrenamt mit Ansprechpartnern und offiziellen Seiten.'],
        'tipp' => ['Tipp', 'Tipps aus Merzenich', 'Tipp: klar gekennzeichnete bezahlte und gesponserte Platzierungen von Vereinen, Unternehmen und Partnern aus Merzenich und der Region.'],
        'nachrichten' => ['Nachrichten', 'Nachrichten Merzenich aktuell: alle Meldungen, neueste zuerst', 'Alle Meldungen aus Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald im Kreis Düren, die neueste zuerst: Blaulicht, Rathaus, Sport, Vereine und Leben.'],
        // „veranstaltungen merzenich heute“, „was ist heute in merzenich los“, „merzenich wochenende“.
        'termine' => ['Termine', 'Veranstaltungen Merzenich: Termine heute und am Wochenende', 'Was in Merzenich los ist: Veranstaltungen heute und am Wochenende in Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald, von Karneval bis Ratssitzung.'],
        'unternehmen' => ['Unternehmen', 'Unternehmen in Merzenich', 'Unternehmen in Merzenich: Wirtschaftsmeldungen der Redaktion und die Kanäle der Unternehmen in und um Merzenich, Unternehmensbeiträge als Anzeige gekennzeichnet.'],
    ];
}

/** Anzeigen- und Branchenlisten (1.22.0): eigene Titel und Beschreibungen statt „Immobilien in Merzenich“ mit 60 Zeichen. */
function ma_seo_listen(): array {
    return [
        'ma_property' => ['Immobilien', 'Immobilien in Merzenich: Häuser, Wohnungen, Grundstücke', 'Häuser, Wohnungen und Grundstücke zum Kauf oder zur Miete in Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald, mit Quelle und Prüfdatum.'],
        'ma_job' => ['Jobs', 'Jobs und Ausbildung in Merzenich', 'Stellenangebote, Ausbildungsplätze und Minijobs von Arbeitgebern in der Gemeinde Merzenich, mit Quelle, Prüfdatum und direktem Link zur Bewerbung.'],
        'ma_obituary' => ['Traueranzeigen', 'Traueranzeigen aus der Gemeinde Merzenich', 'Traueranzeigen, Danksagungen und Jahrgedächtnisse aus Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald. Anzeigen aufgeben ist online möglich.'],
        'ma_family_notice' => ['Familienanzeigen', 'Familienanzeigen aus der Gemeinde Merzenich', 'Geburten, Hochzeiten, Jubiläen und Glückwünsche aus Merzenich und den Ortsteilen. Familienanzeigen lassen sich online aufgeben, die Redaktion prüft vorab.'],
        'ma_business' => ['Lokale Betriebe', 'Branchenbuch: Betriebe aus der Gemeinde Merzenich', 'Branchenbuch für Merzenich und Ortsteile: Handwerk, Handel, Gastronomie und Dienstleister mit Adresse, Öffnungszeiten und Kontakt. Eintrag nur mit Einwilligung.'],
    ];
}

/** Feste Beschreibungen für Seiten, deren Text mit einem Formular oder einer Liste beginnt. */
function ma_seo_seitentexte(): array {
    return [
        'service' => 'Notrufe, Notdienste, Apotheken, Rathaus und wichtige Telefonnummern für die Gemeinde Merzenich auf einen Blick, mit Öffnungszeiten und Links.',
        'diskussion' => 'Diskutieren Sie mit: Kommentare der Leserinnen und Leser zu Meldungen aus Merzenich, moderiert nach den Kommentarrichtlinien der Redaktion.',
        'archiv' => 'Archiv von Merzenich Aktuell: alle Meldungen aus Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald nach Monat und Ressort.',
        'impressum' => 'Impressum von Merzenich Aktuell, der Lokalzeitung online für die Gemeinde Merzenich: Anbieterin KBS Consulting (Pvt) Ltd, Kontakt und Verantwortliche.',
        'heute' => 'Termine von heute und den nächsten sieben Tagen in Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald, dazu die neuesten Meldungen.',
        // 1.42.0: „düren aktuell“, „niederzier aktuell“, „kreis düren aktuell“ (Google-Vorschläge 02.11.2026).
        'umgebung' => 'Nachrichten aus Düren, Niederzier, Nörvenich, Elsdorf, Kerpen und dem Kreis Düren: Polizei, Verkehr, Rathaus und Termine, mit Link zur Originalquelle.',
        'abfall' => 'Abfall in Merzenich: Abfuhrkalender 2026, Sperrmüll online anmelden, Elektroschrott, Schadstoffe in Rurbenden, Tonne tauschen. Mit Nummern und Quelle.',
        'strukturwandel' => 'Morschenich, Bürgewald und Tagebau Hambach: Umsiedlung ab 2015, Erhalt 2020, 57 Mio. Euro Förderung, Ort der Zukunft. Zeitachse mit Quellen.',
        'merzenich-in-zahlen' => 'Merzenich in Zahlen: 10.509 Einwohner, 37,92 km², fünf Ortsteile, Bürgermeister Georg Gelhausen, 26 Sitze im Gemeinderat. Mit Stand und amtlicher Quelle.',
    ];
}

/**
 * Titel für Google, wo er vom sichtbaren Seitentitel abweicht (1.27.0): /heute/
 * heißt auf der Seite „Heute in Merzenich“, in den Suchergebnissen steht die
 * Frage, die Google selbst unter „Weitere Fragen“ zeigt.
 */
function ma_seo_seitentitel(): array {
    return ['heute' => 'Was ist heute in Merzenich los?', 'umgebung' => 'Düren, Niederzier, Kreis Düren aktuell: Nachrichten aus der Umgebung', 'merzenich-in-zahlen' => 'Merzenich in Zahlen: Einwohner, Fläche, Bürgermeister, Gemeinderat', 'abfall' => 'Abfall Merzenich: Abfuhrkalender 2026, Sperrmüll, Schadstoffe', 'strukturwandel' => 'Bürgewald, Morschenich, Tagebau Hambach: Strukturwandel in Merzenich'];
}

/** Zu kurze Beschreibung (unter 110 Zeichen) mit Angaben davor und einem Satz dahinter auffüllen. */
function ma_seo_auffuellen(string $text, string $vorne, string $hinten): string {
    $text = ma_seo_kuerzen($text);
    if (mb_strlen($text) >= 110) return $text;
    if ($text !== '' && !preg_match('/[.!?…]$/u', $text)) $text .= '.';
    return ma_seo_kuerzen(trim(($vorne !== '' ? $vorne . ': ' : '') . $text . ' ' . $hinten));
}

/** Kategorien, die unter /<slug>/ laufen (Blättern, Feed, Umleitung von /category/<slug>/). */
function ma_seo_ressort_kategorien(): array {
    return ['blaulicht', 'sport', 'rathaus', 'leben', 'wirtschaft', 'menschen', 'vereine'];
}

/** Statische Adressen, die WordPress anders führt (301). */
function ma_seo_umleitungen(): array {
    return [
        '/autor/redaktion/' => '/redaktion/',
        '/termine/melden/' => '/termin-melden/',
        '/feed.xml' => '/feed/',
        '/atom.xml' => '/feed/atom/',
        '/suche/' => '/?s=',
        // Fußlinks der statischen Seite, die es hier als eigene Seite nicht gibt (04.10.2026).
        '/vereine/eintragen/' => '/meldung-senden/',
        '/betriebe/eintragen/' => '/anzeigen/aufgeben/?art=Werbung&format=Unternehmenskanal',
    ];
}

/* ------------------------------------------------------------ Helfer (ohne WordPress testbar) */

/** Text auf eine Description kürzen: ohne Tags und Shortcodes, eine Zeile, am Wortende abgeschnitten. */
function ma_seo_kuerzen(string $text, int $max = 160): string {
    $text = preg_replace('/\[[^\]]*\]/', ' ', $text) ?? $text;
    $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = trim((string) preg_replace('/\s+/u', ' ', $text));
    if (mb_strlen($text) <= $max) return $text;
    $kurz = mb_substr($text, 0, $max - 1);
    $pos = mb_strrpos($kurz, ' ');
    if ($pos !== false && $pos > $max / 2) $kurz = mb_substr($kurz, 0, $pos);
    return rtrim($kurz, " ,;:–-") . '…';
}

/** Koordinaten der Ortsmitte Merzenich aus den Wetter-Einstellungen (Plugin-Option, vom Betreiber änderbar). */
function ma_seo_mitte(): array {
    $s = function_exists('get_option') ? (array) get_option('ma_weather_settings', []) : [];
    $lat = (float) ($s['latitude'] ?? 50.8317);
    $lon = (float) ($s['longitude'] ?? 6.5361);
    return [round($lat, 4), round($lon, 4)];
}

/** Nur vollständige Web-Adressen (Schema, Host mit Punkt) gelten als Profil. */
function ma_seo_url_gueltig(string $u): bool {
    return (bool) preg_match('~^https?://[^/\s]+\.[a-z0-9-]{2,}(/|$)~i', $u);
}

/** Robots-Zeile: indexierbar oder nicht. */
function ma_seo_robots_wert(bool $index): string {
    return $index ? 'index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1' : 'noindex,follow';
}

/** ISO-8601-Zeit mit Zeitzone der Installation. */
function ma_seo_zeit(int $ts): string {
    return function_exists('wp_date') ? (string) wp_date('c', $ts) : date('c', $ts);
}

/**
 * Google-Bestätigungsdatei (Search Console, Methode „HTML-Datei“, 02.10.2026):
 * Google verlangt /google<16 Hex>.html mit genau dem Inhalt
 * „google-site-verification: google<16 Hex>.html“. Der Name steht in der
 * Option ma_seo_google_datei; ausgeliefert wird per Rewrite (ma_seo=googledatei),
 * nichts muss auf den Server kopiert werden.
 */
function ma_seo_google_datei_name(string $eingabe): string {
    $eingabe = trim($eingabe);
    return preg_match('/(google[a-f0-9]{16})(?:\.html)?$/i', $eingabe, $m) ? strtolower($m[1]) : '';
}
function ma_seo_google_datei_inhalt(string $name): string { return 'google-site-verification: ' . $name . '.html'; }

/** Themenseiten erst ab so vielen Meldungen in Google (1.26.0: 58 von 150 Themen hatten nur eine). */
const MA_SEO_THEMA_MIN = 3;
function ma_seo_thema_indexierbar(int $anzahl): bool { return $anzahl >= MA_SEO_THEMA_MIN; }

/**
 * Autor einer Meldung als schema.org-Objekt (pure Funktion): Person mit
 * Autorenseite und Funktion, Organisation (Partner) oder die Redaktion.
 * $a wie ma_autor_anzeige(): art, name, funktion, url.
 */
function ma_seo_autor_schema(array $a, string $home): array {
    $art = (string) ($a['art'] ?? 'redaktion');
    if ($art === 'person') return ['@type' => 'Person', 'name' => (string) $a['name'], 'url' => (string) $a['url'], 'jobTitle' => (string) ($a['funktion'] ?? ''), 'worksFor' => ['@id' => $home . '#organization']];
    if ($art === 'organisation') return ['@type' => 'Organization', 'name' => (string) $a['name'], 'url' => (string) $a['url']];
    return ['@type' => 'Organization', 'name' => 'Redaktion Merzenich Aktuell', 'url' => $home . 'redaktion/'];
}

/**
 * Zeilen für robots.txt: Suchseiten und Formular-Rückmeldungen nicht crawlen, News-Sitemap nennen.
 * 1.38.0: eigene Gruppe für KI- und Such-Crawler (MA_SEO_KI_CRAWLER) mit ausdrücklichem Allow. Ein
 * Crawler mit eigener Gruppe liest die *-Gruppe nicht mehr, deshalb stehen die Sperren dort noch einmal.
 */
function ma_seo_robots_txt(string $vorhanden, string $home): string {
    $sperren = "Disallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\nDisallow: /?s=\nDisallow: /*?s=\nDisallow: /*?gesendet=\n";
    $zeilen = rtrim($vorhanden) . "\nDisallow: /?s=\nDisallow: /*?s=\nDisallow: /*?gesendet=\n";
    if (!str_contains($zeilen, 'User-agent: GPTBot')) {
        $zeilen .= "\n# KI- und Suchdienste dürfen lesen und zitieren (mit Quelle merzenich-aktuell.de)\n";
        foreach (MA_SEO_KI_CRAWLER as $bot) $zeilen .= "User-agent: {$bot}\n";
        $zeilen .= "Allow: /\n" . $sperren;
    }
    if (!str_contains($zeilen, 'news-sitemap.xml')) $zeilen .= "\nSitemap: {$home}news-sitemap.xml\n";
    return $zeilen;
}

/**
 * News-Sitemap (Google News): Meldungen der letzten zwei Tage. $eintraege: [['url','titel','zeit'(ISO),'bild'?], …].
 * 1.38.0: Hauptbild als image:image, wenn die Meldung ein eigenes Bild mit geklärten Rechten hat.
 */
function ma_seo_news_sitemap_xml(array $eintraege): string {
    $x = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\" xmlns:news=\"http://www.google.com/schemas/sitemap-news/0.9\" xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\">\n";
    foreach ($eintraege as $e) {
        $x .= '<url><loc>' . htmlspecialchars($e['url'], ENT_XML1) . '</loc><news:news><news:publication><news:name>' . MA_SEO_MARKE . '</news:name><news:language>de</news:language></news:publication>'
            . '<news:publication_date>' . htmlspecialchars($e['zeit'], ENT_XML1) . '</news:publication_date><news:title>' . htmlspecialchars($e['titel'], ENT_XML1) . '</news:title></news:news>'
            . (!empty($e['bild']) ? '<image:image><image:loc>' . htmlspecialchars((string) $e['bild'], ENT_XML1) . '</image:loc></image:image>' : '') . '</url>' . "\n";
    }
    return $x . "</urlset>\n";
}

/* ------------------------------------------------------------ Strukturierte Daten (JSON-LD, reine Funktion) */

/**
 * Graph aus dem Seitenkontext. $k: typ, titel, beschreibung, url, bild
 * (url,w,h,alt), krumen [[name,url|null]], liste [[url,name]], ort (slug),
 * veroeffentlicht/geaendert (ISO), ressort (Label), tags [], woerter,
 * quelle (URL), termin [...], verein [...], gesponsert, seitenart.
 * $o: home, logo, bild (Standardbild), sameas [], mitte [lat,lon].
 */
function ma_seo_graph(array $k, array $o): array {
    $home = $o['home'];
    $org = [
        '@type' => 'NewsMediaOrganization', '@id' => $home . '#organization', 'name' => MA_SEO_MARKE, 'alternateName' => MA_SEO_UNTERTITEL, 'url' => $home,
        'logo' => ['@type' => 'ImageObject', 'url' => $o['logo'], 'width' => 1295, 'height' => 664], 'image' => $o['bild'],
        'description' => 'Nachrichten aus Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald',
        'parentOrganization' => ['@type' => 'Organization', 'name' => 'KBS Consulting (Pvt) Ltd', 'email' => 'redaktion@merzenich-aktuell.de',
            'address' => ['@type' => 'PostalAddress', 'streetAddress' => '11 2nd Cross St', 'addressLocality' => 'Jaffna', 'addressCountry' => 'LK']],
        'email' => 'redaktion@merzenich-aktuell.de',
        'areaServed' => ['@type' => 'AdministrativeArea', 'name' => MA_SEO_GEBIET],
        'publishingPrinciples' => $home . 'grundsaetze/', 'correctionsPolicy' => $home . 'korrekturen/', 'ethicsPolicy' => $home . 'grundsaetze/#ethik',
        'actionableFeedbackPolicy' => $home . 'meldung-senden/', 'masthead' => $home . 'ueber-uns/', 'ownershipFundingInfo' => $home . 'ueber-uns/#finanzierung', 'diversityPolicy' => $home . 'grundsaetze/#vielfalt',
    ];
    if (!empty($o['sameas'])) $org['sameAs'] = array_values($o['sameas']);
    $web = ['@type' => 'WebSite', '@id' => $home . '#website', 'name' => MA_SEO_MARKE, 'alternateName' => MA_SEO_NAMEN, 'url' => $home, 'inLanguage' => 'de-DE', 'publisher' => ['@id' => $home . '#organization'],
        'potentialAction' => ['@type' => 'SearchAction', 'target' => ['@type' => 'EntryPoint', 'urlTemplate' => $home . '?s={search_term_string}'], 'query-input' => 'required name=search_term_string']];
    $graph = [$org, $web];
    $orte = ma_seo_orte();
    $ort = $orte[$k['ort'] ?? 'merzenich'] ?? $orte['merzenich'];
    $adresse = ['@type' => 'PostalAddress', 'addressLocality' => 'Merzenich', 'postalCode' => MA_SEO_PLZ, 'addressRegion' => 'NRW', 'addressCountry' => 'DE'];
    $platz = function (string $slug) use ($orte, $home, $adresse, $o): array {
        $d = $orte[$slug];
        $p = ['@type' => 'Place', '@id' => $home . 'ort/' . $slug . '/#place', 'name' => $d['name'], 'url' => $home . 'ort/' . $slug . '/', 'address' => $adresse, 'containedInPlace' => ['@type' => 'AdministrativeArea', 'name' => 'Gemeinde Merzenich']];
        if ($s = ma_seo_ort_sameas($d)) $p['sameAs'] = $s;
        if ($slug === 'merzenich' && !empty($o['mitte'])) $p['geo'] = ['@type' => 'GeoCoordinates', 'latitude' => $o['mitte'][0], 'longitude' => $o['mitte'][1]];
        elseif (isset($d['lat'])) $p['geo'] = ['@type' => 'GeoCoordinates', 'latitude' => $d['lat'], 'longitude' => $d['lon']];
        return $p;
    };
    $bildobjekt = fn(array $b): array => array_filter(['@type' => 'ImageObject', 'url' => $b['url'], 'width' => $b['w'] ?? null, 'height' => $b['h'] ?? null, 'caption' => $k['bild']['alt'] ?? null]);
    $bild = !empty($k['bild']['url']) ? $bildobjekt($k['bild']) : null;
    // Artikel und Termine: mit Zuschnitten alle drei Seitenverhältnisse (Google-Empfehlung), sonst das eine Bild.
    $bilder = $bild ? (!empty($k['bild']['varianten']) ? array_map($bildobjekt, $k['bild']['varianten']) : [$bild]) : [];
    $url = $k['url'] ?? $home;
    switch ($k['typ']) {
        case 'start':
            $graph[] = ['@type' => 'WebPage', '@id' => $url . '#webpage', 'url' => $url, 'name' => MA_SEO_MARKE . ' · ' . MA_SEO_UNTERTITEL, 'description' => $k['beschreibung'], 'isPartOf' => ['@id' => $home . '#website'], 'about' => ['@id' => $home . '#organization'], 'inLanguage' => 'de-DE', 'primaryImageOfPage' => $bild];
            $graph[] = $platz('merzenich');
            break;
        case 'artikel':
            $a = ['@type' => 'NewsArticle', '@id' => $url . '#article', 'mainEntityOfPage' => ['@type' => 'WebPage', '@id' => $url], 'headline' => $k['titel'], 'description' => $k['beschreibung'],
                'datePublished' => $k['veroeffentlicht'], 'dateModified' => $k['geaendert'] ?: $k['veroeffentlicht'],
                'author' => [ma_seo_autor_schema($k['autor'] ?? [], $home)], 'publisher' => ['@id' => $home . '#organization'],
                'isAccessibleForFree' => true, 'inLanguage' => 'de-DE', 'articleSection' => $k['ressort'] ?? '',
                'contentLocation' => ['@type' => 'Place', 'name' => $ort['name'], 'address' => $adresse], 'about' => ['@id' => $home . 'ort/' . ($k['ort'] ?? 'merzenich') . '/#place'],
                'speakable' => ['@type' => 'SpeakableSpecification', 'cssSelector' => ['.article-head h1', '.article-head .dek']]];
            if ($bilder) $a['image'] = $bilder;
            if (!empty($k['tags'])) $a['keywords'] = implode(', ', $k['tags']);
            if (!empty($k['woerter'])) $a['wordCount'] = (int) $k['woerter'];
            if (!empty($k['quelle'])) { $a['citation'] = [$k['quelle']]; $a['isBasedOn'] = [$k['quelle']]; }
            // Bezahlter Beitrag: Auftraggeber als Sponsor und Absender, nicht die Redaktion (wie die Byline, 1.22.0).
            if (!empty($k['gesponsert'])) { $a['sponsor'] = ['@type' => 'Organization', 'name' => $k['gesponsert']]; $a['author'] = [$a['sponsor']]; }
            $graph[] = $a;
            $graph[] = $platz($k['ort'] ?? 'merzenich');
            break;
        case 'autor':
            $graph[] = ['@type' => 'ProfilePage', '@id' => $url . '#webpage', 'url' => $url, 'name' => $k['titel'], 'description' => $k['beschreibung'], 'isPartOf' => ['@id' => $home . '#website'], 'inLanguage' => 'de-DE',
                'mainEntity' => ma_seo_autor_schema($k['autor'] ?? [], $home)];
            break;
        case 'termin':
            $t = $k['termin'] ?? [];
            $e = ['@type' => 'Event', '@id' => $url . '#event', 'name' => $k['titel'], 'url' => $url, 'description' => $k['beschreibung'], 'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode', 'inLanguage' => 'de-DE'];
            // Vergangene Termine bleiben erreichbar (Archiv), tragen aber keinen Status „geplant“.
            if (empty($t['vorbei'])) $e['eventStatus'] = 'https://schema.org/EventScheduled';
            if (!empty($t['start'])) $e['startDate'] = $t['start'];
            // Ohne bekanntes Ende endet der Termin am selben Tag (Search Console 04.10.2026: endDate empfohlen).
            if (!empty($t['ende'])) $e['endDate'] = $t['ende'];
            elseif (!empty($t['start'])) $e['endDate'] = substr((string) $t['start'], 0, 10);
            // Termine außerhalb der Gemeinde (Kreishaus Düren, Niederzier …) tragen nicht die Merzenicher Anschrift (Prüfung 21.11.2026).
            if (!empty($t['ort'])) $e['location'] = ma_ort_auswaerts((string) $t['ort']) ? ['@type' => 'Place', 'name' => $t['ort'], 'address' => (string) $t['ort']] : ['@type' => 'Place', 'name' => $t['ort'], 'address' => $adresse];
            if (!empty($t['veranstalter'])) {
                $e['organizer'] = ['@type' => 'Organization', 'name' => $t['veranstalter']];
                $vu = ma_seo_veranstalter_url((string) $t['veranstalter']);
                if ($vu !== '') $e['organizer']['url'] = $vu;
            }
            $angebot = ma_seo_angebot((string) ($t['preis'] ?? ''), $url);
            if ($angebot) { $e['offers'] = $angebot; if ((string) $angebot['price'] === '0') $e['isAccessibleForFree'] = true; }
            if ($bilder) $e['image'] = $bilder;
            $graph[] = $e;
            break;
        case 'verein':
            $v = $k['verein'] ?? [];
            $c = ['@type' => !empty($v['sportarten']) ? 'SportsClub' : 'Organization', '@id' => $url . '#organization', 'name' => $k['titel'], 'url' => $url, 'description' => $k['beschreibung'], 'location' => ['@type' => 'Place', 'name' => $ort['name'], 'address' => $adresse]];
            if (!empty($v['adresse'])) $c['address'] = ['@type' => 'PostalAddress', 'streetAddress' => $v['adresse'], 'addressLocality' => 'Merzenich', 'postalCode' => MA_SEO_PLZ, 'addressCountry' => 'DE'];
            if (!empty($v['website'])) $c['sameAs'] = [$v['website']];
            if (!empty($v['gegruendet']) && preg_match('/^\d{4}$/', (string) $v['gegruendet'])) $c['foundingDate'] = (string) $v['gegruendet'];
            if (!empty($v['sportarten'])) $c['sport'] = $v['sportarten'];
            if (!empty($v['logo'])) $c['logo'] = $v['logo'];
            $graph[] = $c;
            break;
        case 'ort':
            $p = $platz($k['ort'] ?? 'merzenich'); $p['description'] = $ort['beschreibung'];
            $graph[] = ['@type' => 'CollectionPage', '@id' => $url . '#webpage', 'name' => $k['titel'], 'url' => $url, 'description' => $k['beschreibung'], 'isPartOf' => ['@id' => $home . '#website'], 'about' => ['@id' => $p['@id']], 'inLanguage' => 'de-DE', 'mainEntity' => ma_seo_itemlist($k['liste'] ?? [])];
            $graph[] = $p;
            break;
        case 'ressort': case 'thema': case 'liste':
            $graph[] = ['@type' => 'CollectionPage', '@id' => $url . '#webpage', 'name' => $k['titel'], 'url' => $url, 'description' => $k['beschreibung'], 'isPartOf' => ['@id' => $home . '#website'], 'inLanguage' => 'de-DE', 'mainEntity' => ma_seo_itemlist($k['liste'] ?? [])];
            break;
        case 'seite': case 'eintrag':
            $s = ['@type' => $k['seitenart'] ?? 'WebPage', '@id' => $url . '#webpage', 'url' => $url, 'name' => $k['titel'], 'description' => $k['beschreibung'], 'isPartOf' => ['@id' => $home . '#website'], 'inLanguage' => 'de-DE', 'dateModified' => $k['geaendert'] ?? null];
            // Faktenseiten mit Fragen als Überschrift (1.48.0): FAQPage, damit KI-Suchen Frage und Antwort zuordnen.
            if (!empty($k['faq'])) {
                $s['@type'] = 'FAQPage';
                $s['mainEntity'] = array_map(fn($f) => ['@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f[1]]], $k['faq']);
            }
            $graph[] = $s;
            break;
    }
    if (!empty($k['krumen']) && count($k['krumen']) > 1) {
        $graph[] = ['@type' => 'BreadcrumbList', 'itemListElement' => array_values(array_map(fn($kr, $i) => array_filter(['@type' => 'ListItem', 'position' => $i + 1, 'name' => $kr[0], 'item' => $kr[1] ?? null]), $k['krumen'], array_keys($k['krumen'])))];
    }
    $graph = array_map(fn($e) => array_filter($e, fn($v) => $v !== null && $v !== '' && $v !== []), $graph);
    return ['@context' => 'https://schema.org', '@graph' => $graph];
}

/** Faktenseiten, deren Fragen als FAQPage ausgezeichnet werden (1.48.0). */
function ma_seo_faq_seiten(): array {
    return ['merzenich-in-zahlen', 'abfall', 'strukturwandel'];
}

/**
 * Fragen und Antworten aus Seiten-HTML: jede h2, die auf „?“ endet, mit dem Klartext bis zur
 * nächsten h2 als Antwort (höchstens 600 Zeichen). Reine Funktion, getestet in seo-test.php.
 */
function ma_seo_faq_aus_html(string $html): array {
    $faq = [];
    $teile = preg_split('~<h2\b[^>]*>~i', $html);
    array_shift($teile);
    foreach ($teile as $teil) {
        [$frage, $rest] = array_pad(preg_split('~</h2>~i', $teil, 2), 2, '');
        $frage = trim(html_entity_decode(strip_tags($frage), ENT_QUOTES, 'UTF-8'));
        if (!str_ends_with($frage, '?')) continue;
        $antwort = ma_seo_klartext($rest, 600);
        if ($antwort !== '') $faq[] = [$frage, $antwort];
    }
    return $faq;
}

function ma_seo_itemlist(array $liste): array {
    return ['@type' => 'ItemList', 'itemListElement' => array_values(array_map(fn($e, $i) => ['@type' => 'ListItem', 'position' => $i + 1, 'url' => $e[0], 'name' => $e[1]], $liste, array_keys($liste)))];
}

/**
 * llms.txt: Überblick für KI-Suchen aus Ressorts, Orten, Seiten und Anbieterin. $seiten: [[name, url, beschreibung]].
 * 1.38.0: Abschnitt „Aktuell“ (Heute, Termine, Kalender, KI-Redaktion) und $neueste: [[titel, url, datum (TT.MM.JJJJ)]], höchstens 10.
 */
function ma_seo_llms_txt(string $home, array $seiten, array $neueste = []): string {
    $t = "# " . MA_SEO_MARKE . "\n\n> " . MA_SEO_BESCHREIBUNG_LANG . "\n\n";
    $t .= "Anbieterin: KBS Consulting (Pvt) Ltd, 11 2nd Cross St, Jaffna, Sri Lanka, redaktion@merzenich-aktuell.de. Jede Meldung nennt ihre Originalquelle, ihren Datenstand und den Bildtyp; Fehler werden im Artikel mit Datum korrigiert.\n\n";
    $t .= "## Aktuell\n\n- [Heute in Merzenich]({$home}heute/): Was heute in der Gemeinde ansteht und neu ist.\n- [Termine]({$home}termine/): Veranstaltungen, Sitzungen und Feste aus allen Ortsteilen.\n- [Terminkalender (ICS)]({$home}termine/kalender.ics): alle Termine zum Abonnieren.\n- [KI-Redaktion]({$home}ki-redaktion/): Wie Meldungen mit KI recherchiert, geprüft und gekennzeichnet werden.\n- [Nachrichten aus der Umgebung]({$home}umgebung/): Düren, Niederzier, Nörvenich, Elsdorf, Kerpen und Kreis Düren, letzte 30 Tage.\n";
    if ($neueste) {
        $t .= "\n## Neueste Meldungen\n\n";
        foreach (array_slice($neueste, 0, 10) as [$titel, $url, $datum]) $t .= "- [{$titel}]({$url})" . ($datum !== '' ? " ({$datum})" : '') . "\n";
    }
    $t .= "\n## Ressorts\n\n";
    foreach (ma_seo_ressorte() as $slug => [$name, $titel, $desc]) $t .= "- [{$name}]({$home}{$slug}/): {$desc}\n";
    $t .= "\n## Orte der Gemeinde Merzenich\n\n";
    foreach (ma_seo_orte() as $slug => $d) $t .= "- [{$d['name']}]({$home}ort/{$slug}/): {$d['beschreibung']}\n";
    if ($seiten) { $t .= "\n## Über die Redaktion\n\n"; foreach ($seiten as [$name, $url, $desc]) $t .= "- [{$name}]({$url})" . ($desc !== '' ? ": {$desc}" : '') . "\n"; }
    $t .= "\n## Feeds und Sitemaps\n\n- [RSS]({$home}feed/)\n- [Sitemap]({$home}wp-sitemap.xml)\n- [News-Sitemap]({$home}news-sitemap.xml)\n- [Volltext für KI-Systeme]({$home}llms-full.txt)\n";
    return $t;
}

/**
 * llms-full.txt (1.44.0, SEO-GEO-BERICHT 03.11.2026 Befund 9): Volltext der Orte, Redaktions- und
 * Faktenseiten und der neuesten Meldungen, damit KI-Suchen Merzenich Aktuell zitieren können.
 * $abschnitte: ['Orte' => [[titel, url, text], …], 'Seiten' => …, 'Neueste Meldungen' => …] (reine Funktion).
 */
function ma_seo_llms_full_txt(string $home, array $abschnitte): string {
    $t = '# ' . MA_SEO_MARKE . " – Volltext\n\n> " . MA_SEO_BESCHREIBUNG_LANG . "\n\nKurzfassung mit allen Links: {$home}llms.txt. Jede Meldung nennt ihre Originalquelle; zitieren bitte mit Link auf die jeweilige Seite.\n";
    foreach ($abschnitte as $name => $eintraege) {
        $eintraege = array_values(array_filter((array) $eintraege, fn($e) => is_array($e) && trim((string) ($e[2] ?? '')) !== ''));
        if (!$eintraege) continue;
        $t .= "\n## {$name}\n";
        foreach ($eintraege as [$titel, $url, $text]) $t .= "\n### {$titel}\n\nAdresse: {$url}\n\n" . trim(preg_replace("/\n{3,}/", "\n\n", (string) $text)) . "\n";
    }
    return $t;
}

/** Seitentext ohne HTML und Shortcodes, höchstens $max Zeichen (am Satzende gekürzt). */
function ma_seo_klartext(string $html, int $max = 6000): string {
    $t = function_exists('strip_shortcodes') ? strip_shortcodes($html) : preg_replace('/\[[^\]]*\]/', '', $html);
    $t = preg_replace('#</(p|li|h[1-6]|tr)>#i', "\n", (string) $t);
    $t = html_entity_decode(trim(preg_replace("/[ \t]+/", ' ', strip_tags((string) $t))), ENT_QUOTES, 'UTF-8');
    $t = preg_replace("/\n\s*\n+/", "\n\n", preg_replace("/ *\n */", "\n", $t));
    if (mb_strlen($t) <= $max) return $t;
    $t = mb_substr($t, 0, $max);
    $ende = max(mb_strrpos($t, '. ') ?: 0, mb_strrpos($t, "\n") ?: 0);
    return rtrim($ende > $max / 2 ? mb_substr($t, 0, $ende + 1) : $t) . ' …';
}

/* ------------------------------------------------------------ Kontext der aktuellen Seite */

/** Bildtyp aus der Dateiendung für og:image:type (WhatsApp und Co. lesen ihn mit), leer bei Unbekanntem. */
function ma_seo_bildtyp(string $url): string {
    $endung = strtolower(pathinfo((string) parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
    return ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif'][$endung] ?? '';
}

/** Standardbild (1200×630) und Logo liegen im Theme unter static/assets/img (Adresse /assets/…). */
function ma_seo_standardbild(): array {
    return ['url' => home_url('/assets/img/og-default.jpg'), 'w' => 1200, 'h' => 630, 'alt' => MA_SEO_MARKE];
}

/**
 * Beitragsbild für Vorschau (WhatsApp, Facebook) und JSON-LD: genau das Bild, das die Seite selbst zeigt
 * (Vorgabe Betreiber 27.11.2026: jeder geteilte Beitrag mit seinem Bild). Ohne Beitragsbild das freigegebene
 * Firmenlogo eines Unternehmensbeitrags (ma21_bild_firmenlogo, wie auf der Seite), sonst das Standardbild.
 * Bis 1.50.7 fiel die Vorschau ohne Rechte-Haken auf das Standardbild zurück, obwohl die Seite das Bild zeigte.
 */
function ma_seo_bild($post): array {
    $post = get_post($post);
    if (!$post) return ma_seo_standardbild();
    $id = (int) get_post_thumbnail_id($post);
    if (!$id && function_exists('ma21_bild_firmenlogo')) $id = (int) (ma21_bild_firmenlogo($post)['id'] ?? 0);
    if (!$id) return ma_seo_standardbild();
    // Google Discover verlangt Bilder ab 1200 px Breite: die größte verfügbare Größe nehmen.
    $src = null;
    foreach (['1536x1536', 'full', 'large'] as $g) { $s = wp_get_attachment_image_src($id, $g); if ($s && (int) $s[1] >= 1200) { $src = $s; break; } if (!$src && $s) $src = $s; }
    if (!$src) return ma_seo_standardbild();
    $alt = (string) get_post_meta($id, '_wp_attachment_image_alt', true);
    $bild = ['url' => $src[0], 'w' => (int) $src[1], 'h' => (int) $src[2], 'alt' => $alt !== '' ? $alt : get_the_title($post)];
    // Zuschnitte 16:9, 4:3, 1:1 (teilen-bilder.php): Vorschau mit 16:9, JSON-LD mit allen dreien.
    $z = function_exists('ma_seo_zuschnitte') ? ma_seo_zuschnitte($id) : [];
    if ($z) $bild = array_merge($bild, $z['16x9'] ?? [], ['varianten' => array_values($z)]);
    return $bild;
}

function ma_seo_ort_von($post): string {
    $t = get_the_terms($post, 'ma_location');
    if (is_array($t)) foreach ($t as $term) if (isset(ma_seo_orte()[$term->slug])) return $term->slug;
    return 'merzenich';
}

function ma_seo_ressort_von(WP_Post $p): array {
    $r = ma_seo_ressorte();
    foreach (get_the_category($p->ID) as $c) if (isset($r[$c->slug])) return [$c->slug, $r[$c->slug][0]];
    $c = get_the_category($p->ID)[0] ?? null;
    return $c ? [$c->slug, $c->name] : ['nachrichten', 'Nachrichten'];
}

/** Adresse der aktuellen Liste mit Seitenzahl. */
function ma_seo_liste_url(string $basis): string {
    $seite = max(1, (int) get_query_var('paged'));
    return $seite > 1 ? trailingslashit($basis) . 'page/' . $seite . '/' : trailingslashit($basis);
}

function ma_seo_liste(): array {
    global $wp_query;
    if (!$wp_query || is_paged()) return [];
    $liste = [];
    foreach (array_slice((array) $wp_query->posts, 0, 20) as $p) if ($p instanceof WP_Post) $liste[] = [get_permalink($p), html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8')];
    return $liste;
}

function ma_seo_kontext(): array {
    static $k = null;
    if ($k !== null) return $k;
    $home = home_url('/');
    $r = ma_seo_ressorte();
    $k = ['typ' => 'liste', 'titel' => '', 'beschreibung' => '', 'url' => '', 'index' => true, 'og' => 'website', 'krumen' => [['Start', $home]], 'ort' => 'merzenich', 'bild' => ma_seo_standardbild(), 'liste' => [], 'tags' => [], 'veroeffentlicht' => '', 'geaendert' => '', 'ressort' => ''];
    $o = get_queried_object();
    if (is_front_page()) {
        $k = array_merge($k, ['typ' => 'start', 'titel' => MA_SEO_STARTTITEL, 'beschreibung' => MA_SEO_BESCHREIBUNG, 'url' => $home, 'krumen' => []]);
    } elseif (is_singular('post') && $o instanceof WP_Post) {
        [$rs, $rl] = ma_seo_ressort_von($o);
        $ort = ma_seo_ort_von($o);
        $text = trim($o->post_excerpt) !== '' ? $o->post_excerpt : $o->post_content;
        $krumen = [['Start', $home], [$rl, isset($r[$rs]) ? $home . $rs . '/' : $home . 'nachrichten/']];
        if ($ort !== 'merzenich') $krumen[] = [ma_seo_orte()[$ort]['name'], $home . 'ort/' . $ort . '/'];
        $krumen[] = [html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), null];
        $tags = array_map(fn($t) => $t->name, (array) (get_the_tags($o->ID) ?: []));
        if ($ort !== 'merzenich') $tags[] = ma_seo_orte()[$ort]['name'];
        // Redaktionell gepflegte SEO-Angaben (Kasten „Redaktion & Quelle“) gehen vor; sonst Überschrift und Anriss.
        $seoTitel = trim((string) get_post_meta($o->ID, 'ma_seo_titel', true));
        $seoText = trim((string) get_post_meta($o->ID, 'ma_seo_beschreibung', true));
        $aktualisiert = (string) get_post_meta($o->ID, 'ma_aktualisiert', true);
        $k = array_merge($k, ['typ' => 'artikel', 'titel' => $seoTitel !== '' ? $seoTitel : html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), 'beschreibung' => ma_seo_kuerzen($seoText !== '' ? $seoText : $text), 'url' => get_permalink($o), 'og' => 'article', 'krumen' => $krumen, 'ort' => $ort,
            'bild' => ma_seo_bild($o), 'tags' => $tags, 'ressort' => $rl, 'veroeffentlicht' => get_post_time('c', false, $o), 'geaendert' => $aktualisiert !== '' ? (string) mysql2date('c', $aktualisiert, false) : get_post_modified_time('c', false, $o),
            'woerter' => str_word_count(strip_tags($o->post_excerpt . ' ' . $o->post_content)), 'quelle' => (string) get_post_meta($o->ID, 'ma_source_url', true),
            'gesponsert' => function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($o) ? ((string) get_post_meta($o->ID, 'ma_gesponsert_von', true) ?: 'Gesponsert') : '',
            'autor' => function_exists('ma_autor_von') ? ma_autor_von($o) : []]);
    } elseif (is_singular('ma_event') && $o instanceof WP_Post) {
        $start = function_exists('ma_event_timestamp') ? ma_event_timestamp($o->ID, 'start') : 0;
        $ende = function_exists('ma_event_timestamp') ? ma_event_timestamp($o->ID, 'end') : 0;
        $platz = (string) get_post_meta($o->ID, 'ma_event_place', true);
        $text = trim($o->post_excerpt) !== '' ? $o->post_excerpt : ($o->post_content ?: ('Termin' . ($start ? ' am ' . wp_date('d.m.Y', $start) : '') . ($platz ? ' in ' . $platz : '') . ', Gemeinde Merzenich.'));
        $wann = $start ? 'Am ' . wp_date('d.m.Y', $start) . (wp_date('H:i', $start) !== '00:00' ? ', ' . wp_date('H:i', $start) . ' Uhr' : '') : '';
        $vorne = implode(', ', array_filter([$wann, $platz]));
        $k = array_merge($k, ['typ' => 'termin', 'titel' => html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), 'beschreibung' => ma_seo_auffuellen($text, $vorne, 'Termin in der Gemeinde Merzenich, mit Kalendereintrag auf Merzenich Aktuell.'), 'url' => get_permalink($o), 'og' => 'article', 'ort' => ma_seo_ort_von($o), 'bild' => ma_seo_bild($o),
            'krumen' => [['Start', $home], ['Termine', $home . 'termine/'], [html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), null]], 'geaendert' => get_post_modified_time('c', false, $o),
            'termin' => ['start' => $start ? ma_seo_zeit($start) : '', 'ende' => $ende && $ende !== $start ? ma_seo_zeit($ende) : '', 'vorbei' => function_exists('ma_event_vorbei') && ma_event_vorbei($o->ID), 'ort' => $platz, 'veranstalter' => (string) get_post_meta($o->ID, 'ma_event_organizer', true), 'preis' => (string) get_post_meta($o->ID, 'ma_event_price', true)]]);
    } elseif (is_singular('ma_club') && $o instanceof WP_Post) {
        $logo = (string) get_post_meta($o->ID, 'ma_club_logo', true);
        $k = array_merge($k, ['typ' => 'verein', 'titel' => html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), 'beschreibung' => ma_seo_auffuellen(trim($o->post_excerpt) !== '' ? $o->post_excerpt : ($o->post_content ?: get_the_title($o) . ': Verein in der Gemeinde Merzenich.'), '', 'Verein aus ' . ma_seo_orte()[ma_seo_ort_von($o)]['name'] . ' (Gemeinde Merzenich) mit Meldungen, Terminen und Kontakt auf Merzenich Aktuell.'), 'url' => get_permalink($o), 'ort' => ma_seo_ort_von($o), 'bild' => ma_seo_bild($o),
            'krumen' => [['Start', $home], ['Vereine', $home . 'vereine/'], [html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), null]], 'geaendert' => get_post_modified_time('c', false, $o),
            'verein' => ['adresse' => (string) get_post_meta($o->ID, 'ma_club_adresse', true), 'website' => (string) get_post_meta($o->ID, 'ma_club_website', true), 'gegruendet' => (string) get_post_meta($o->ID, 'ma_club_gegruendet', true), 'sportarten' => (string) get_post_meta($o->ID, 'ma_club_sportarten', true), 'logo' => $logo !== '' && str_starts_with($logo, 'http') ? $logo : '']]);
    } elseif (is_singular() && $o instanceof WP_Post) {
        $arten = ['ueber-uns' => 'AboutPage', 'kontakt' => 'ContactPage', 'impressum' => 'AboutPage', 'datenschutz' => 'WebPage', 'suche' => 'SearchResultsPage'];
        $krumen = [['Start', $home]];
        if ($o->post_parent) $krumen[] = [html_entity_decode(get_the_title($o->post_parent), ENT_QUOTES, 'UTF-8'), get_permalink($o->post_parent)];
        $krumen[] = [html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), null];
        $k = array_merge($k, ['typ' => $o->post_type === 'page' ? 'seite' : 'eintrag', 'titel' => $o->post_type === 'page' && isset(ma_seo_seitentitel()[$o->post_name]) ? ma_seo_seitentitel()[$o->post_name] : html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8'), 'beschreibung' => $o->post_type === 'page' && isset(ma_seo_seitentexte()[$o->post_name]) ? ma_seo_seitentexte()[$o->post_name] : ma_seo_kuerzen(trim($o->post_excerpt) !== '' ? $o->post_excerpt : $o->post_content), 'url' => get_permalink($o),
            'krumen' => $krumen, 'bild' => ma_seo_bild($o), 'geaendert' => get_post_modified_time('c', false, $o), 'seitenart' => $arten[$o->post_name] ?? 'WebPage',
            'faq' => $o->post_type === 'page' && in_array($o->post_name, ma_seo_faq_seiten(), true) ? ma_seo_faq_aus_html((string) $o->post_content) : [], 'index' => !in_array($o->post_type, ['ma_obituary', 'ma_family_notice'], true)
                // Übernommene Stellen und Immobilien (Kopien der Portale, 1.26.0) nicht als eigene Inhalte werten.
                && (string) get_post_meta($o->ID, 'ma_markt_id', true) === '']);
    } elseif (is_category() && $o instanceof WP_Term) {
        $d = $r[$o->slug] ?? [$o->name, $o->name . ' in Merzenich', $o->description ?: 'Meldungen aus dem Ressort ' . $o->name . ' auf Merzenich Aktuell.'];
        $k = array_merge($k, ['typ' => 'ressort', 'titel' => $d[1], 'beschreibung' => $d[2], 'url' => ma_seo_liste_url(get_term_link($o)), 'krumen' => [['Start', $home], [$d[0], null]], 'liste' => ma_seo_liste()]);
    } elseif (get_query_var('ma_alle')) {
        $k = array_merge($k, ['typ' => 'liste', 'titel' => $r['nachrichten'][1], 'beschreibung' => $r['nachrichten'][2], 'url' => ma_seo_liste_url($home . 'nachrichten/'), 'krumen' => [['Start', $home], ['Nachrichten', null]], 'liste' => ma_seo_liste()]);
    } elseif (get_query_var('ma_unternehmen')) {
        $k = array_merge($k, ['typ' => 'liste', 'titel' => $r['unternehmen'][1], 'beschreibung' => $r['unternehmen'][2], 'url' => $home . 'unternehmen/', 'krumen' => [['Start', $home], ['Unternehmen', null]], 'liste' => ma_seo_liste()]);
    } elseif (is_tax('ma_location') && $o instanceof WP_Term) {
        $d = ma_seo_orte()[$o->slug] ?? ['name' => $o->name, 'beschreibung' => $o->description ?: 'Meldungen aus ' . $o->name . '.'];
        $k = array_merge($k, ['typ' => 'ort', 'ort' => isset(ma_seo_orte()[$o->slug]) ? $o->slug : 'merzenich', 'titel' => $d['titel'] ?? $d['name'] . ': Nachrichten aus dem Ortsteil der Gemeinde Merzenich', 'beschreibung' => ma_seo_kuerzen($d['seo'] ?? ($o->description ?: $d['beschreibung'])), 'url' => ma_seo_liste_url(get_term_link($o)), 'krumen' => [['Start', $home], [$d['name'], null]], 'liste' => ma_seo_liste()]);
    } elseif (is_tag() && $o instanceof WP_Term) {
        $k = array_merge($k, ['typ' => 'thema', 'titel' => $o->name . ': Meldungen aus Merzenich', 'beschreibung' => ma_seo_kuerzen($o->description ?: 'Alle Meldungen von Merzenich Aktuell zum Thema ' . $o->name . ' aus Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald.'), 'url' => ma_seo_liste_url(get_term_link($o)), 'krumen' => [['Start', $home], ['Thema', $home . 'thema/'], [$o->name, null]], 'liste' => ma_seo_liste(),
            // Dünne Themenseiten (weniger als MA_SEO_THEMA_MIN Meldungen) nicht indexieren; Leser erreichen sie weiter.
            'index' => ma_seo_thema_indexierbar((int) $o->count)]);
    } elseif (is_post_type_archive()) {
        $typ = (string) get_query_var('post_type'); if (is_array(get_query_var('post_type'))) $typ = (string) (get_query_var('post_type')[0] ?? '');
        $slug = ['ma_event' => 'termine', 'ma_tip' => 'tipp', 'ma_club' => 'vereine'][$typ] ?? '';
        $obj = get_post_type_object($typ);
        $d = $r[$slug] ?? ma_seo_listen()[$typ] ?? [$obj->labels->name ?? 'Liste', ($obj->labels->name ?? 'Liste') . ' in Merzenich', ($obj->labels->name ?? 'Einträge') . ' aus der Gemeinde Merzenich auf Merzenich Aktuell.'];
        $k = array_merge($k, ['typ' => 'liste', 'titel' => $d[1], 'beschreibung' => $d[2], 'url' => ma_seo_liste_url(get_post_type_archive_link($typ) ?: $home), 'krumen' => [['Start', $home], [$d[0], null]], 'liste' => ma_seo_liste()]);
    } elseif ((string) get_query_var('ma_autor') !== '' && function_exists('ma_autor_konto') && ($ku = ma_autor_konto((string) get_query_var('ma_autor')))) {
        $au = ma_autor_anzeige($ku);
        $k = array_merge($k, ['typ' => 'autor', 'titel' => $au['name'] . ' · ' . $au['funktion'], 'autor' => $au,
            'beschreibung' => ma_seo_kuerzen($au['bio'] !== '' ? $au['bio'] : 'Meldungen von ' . $au['name'] . ' auf Merzenich Aktuell, der Lokalzeitung für die Gemeinde Merzenich.'),
            'url' => ma_seo_liste_url($au['url']), 'krumen' => [['Start', $home], ['Redaktion', $home . 'redaktion/'], [$au['name'], null]], 'liste' => ma_seo_liste()]);
    } elseif (is_search()) {
        $k = array_merge($k, ['typ' => 'suche', 'titel' => get_search_query() === '' ? 'Suche' : 'Suche: „' . get_search_query() . '“', 'beschreibung' => 'Suche auf Merzenich Aktuell.', 'url' => '', 'index' => false, 'krumen' => []]);
    } elseif (is_404()) {
        $k = array_merge($k, ['typ' => '404', 'titel' => 'Seite nicht gefunden', 'beschreibung' => 'Diese Seite gibt es auf Merzenich Aktuell nicht.', 'url' => '', 'index' => false, 'krumen' => []]);
    } else {
        // Datums-, Autoren- und sonstige Archive: lesbar, aber nicht indexierbar.
        $k = array_merge($k, ['typ' => 'liste', 'titel' => html_entity_decode(wp_strip_all_tags(get_the_archive_title()), ENT_QUOTES, 'UTF-8'), 'beschreibung' => 'Meldungen auf Merzenich Aktuell.', 'url' => '', 'index' => false, 'krumen' => []]);
    }
    // Jede geteilte Seite mit Bild (Vorgabe Betreiber 27.11.2026): Seiten ohne eigenes Bild nehmen ein passendes.
    if (($k['bild']['url'] ?? '') === ma_seo_standardbild()['url']) $k['bild'] = ma_seo_ersatzbild($k, $o);
    // Seiten des Themes ohne eigenen WordPress-Inhalt (Unternehmenskanäle, 1.28.0) setzen Titel, Adresse und Index selbst.
    $k = (array) apply_filters('ma_seo_kontext', $k);
    return $k;
}

/** Erstes Bild (ma_seo_bild) aus einer Liste von Beiträgen, null ohne Treffer. */
function ma_seo_bild_aus(array $posts): ?array {
    $std = ma_seo_standardbild()['url'];
    foreach ($posts as $p) { $b = ma_seo_bild($p); if (($b['url'] ?? '') !== $std) return $b; }
    return null;
}

/** Neueste veröffentlichte Meldungen mit Beitragsbild, optional eingegrenzt (tax_query, meta). */
function ma_seo_neueste_mit_bild(array $args = []): array {
    return get_posts(array_merge(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 6, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true,
        'meta_query' => [['key' => '_thumbnail_id', 'compare' => 'EXISTS']]], $args));
}

/**
 * Vorschaubild für Seiten ohne eigenes Bild (27.11.2026):
 * - Verein: Vereinslogo, sonst Bild der neuesten Meldung des Vereins, sonst des Ortsteils.
 * - Ressort, Thema, Ortsteil, Listen: Bild der neuesten Meldung auf der Seite bzw. in Rubrik, Thema, Ortsteil.
 * - Startseite und alle übrigen Seiten: Bild des Aufmachers der Startseite, sonst der neuesten Meldung mit Bild.
 * Nur wenn es nirgends ein Bild gibt, bleibt das Standardbild.
 */
function ma_seo_ersatzbild(array $k, $o): array {
    $b = null;
    if (($k['typ'] ?? '') === 'verein' && $o instanceof WP_Post) {
        $logo = (string) get_post_meta($o->ID, 'ma_club_logo', true);
        // Gespeicherte Logos können relativ sein („/assets/uploads/…“); og:image braucht die volle Adresse.
        if ($logo !== '' && str_starts_with($logo, '/') && !str_starts_with($logo, '//')) $logo = home_url($logo);
        if ($logo !== '') {
            $aid = function_exists('attachment_url_to_postid') ? (int) attachment_url_to_postid($logo) : 0;
            $src = $aid ? wp_get_attachment_image_src($aid, 'full') : false;
            $b = ['url' => $logo, 'w' => $src ? (int) $src[1] : 0, 'h' => $src ? (int) $src[2] : 0, 'alt' => 'Logo ' . html_entity_decode(get_the_title($o), ENT_QUOTES, 'UTF-8')];
        }
        $kurz = (string) get_post_meta($o->ID, 'ma_verein_kurz', true);
        if (!$b && $kurz !== '' && function_exists('ma_verein_beitraege')) $b = ma_seo_bild_aus(ma_verein_beitraege($kurz, 6));
        if (!$b) { $t = get_the_terms($o->ID, 'ma_location'); if (is_array($t) && $t) $b = ma_seo_bild_aus(ma_seo_neueste_mit_bild(['tax_query' => [['taxonomy' => 'ma_location', 'field' => 'term_id', 'terms' => $t[0]->term_id]]])); }
    }
    if (!$b) { global $wp_query; if ($wp_query && !empty($wp_query->posts) && !is_singular()) $b = ma_seo_bild_aus(array_slice(array_filter((array) $wp_query->posts, fn($p) => $p instanceof WP_Post), 0, 10)); }
    if (!$b && $o instanceof WP_Term) {
        $b = ma_seo_bild_aus(ma_seo_neueste_mit_bild(['tax_query' => [['taxonomy' => $o->taxonomy, 'field' => 'term_id', 'terms' => $o->term_id]]]));
    }
    // Ressortseiten als Seite (z. B. /blaulicht/) oder Ressort-Kategorie: neueste Meldung des Ressorts.
    $ressort = $o instanceof WP_Post && $o->post_type === 'page' ? $o->post_name : (string) (get_query_var('category_name') ?: '');
    if (!$b && $ressort !== '' && isset(ma_seo_ressorte()[$ressort]) && get_category_by_slug($ressort)) $b = ma_seo_bild_aus(ma_seo_neueste_mit_bild(['category_name' => $ressort]));
    if (!$b && function_exists('ma_layout_get')) {
        $auf = (int) (ma_layout_get('startseite')['slots']['aufmacher']['post'] ?? 0);
        if ($auf && get_post_status($auf) === 'publish') $b = ma_seo_bild_aus([$auf]);
    }
    if (!$b) $b = ma_seo_bild_aus(ma_seo_neueste_mit_bild());
    return $b ?: ma_seo_standardbild();
}

/* ------------------------------------------------------------ Kopfausgabe */

add_filter('document_title_separator', fn() => '|');
add_filter('document_title_parts', function (array $teile): array {
    if (is_feed()) return $teile;
    $k = ma_seo_kontext();
    if ($k['typ'] === 'start') return ['title' => $k['titel']];
    $teile['title'] = $k['titel'];
    $teile['site'] = MA_SEO_MARKE;
    unset($teile['tagline']);
    return $teile;
});

/* Eigene Ausgabe statt der Kernfunktionen: Canonical (auch für Listen), kein Shortlink, keine Generator- und Editor-Hinweise. */
add_action('init', function (): void {
    remove_action('wp_head', 'rel_canonical');
    remove_action('wp_head', 'wp_shortlink_wp_head', 10);
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'rsd_link');
    // Robots kommt aus ma_seo_head (Index-Regel je Seite); der Kern gab daneben
    // eine zweite Angabe aus (16.10.2026).
    remove_action('wp_head', 'wp_robots', 1);
});

function ma_seo_head(): void {
    $k = ma_seo_kontext();
    $home = home_url('/');
    $e = fn($s) => esc_attr(html_entity_decode((string) $s, ENT_QUOTES, 'UTF-8'));
    $z = '';
    if ($k['beschreibung'] !== '') $z .= '<meta name="description" content="' . $e($k['beschreibung']) . '">' . "\n";
    $z .= '<meta name="robots" content="' . ma_seo_robots_wert($k['index'] && get_option('blog_public')) . '">' . "\n";
    if ($k['url'] !== '') $z .= '<link rel="canonical" href="' . esc_url($k['url']) . '">' . "\n";
    foreach (['google' => 'google-site-verification', 'bing' => 'msvalidate.01'] as $opt => $name) {
        $code = trim((string) get_option('ma_seo_' . $opt, ''));
        if ($code !== '') $z .= '<meta name="' . $name . '" content="' . $e($code) . '">' . "\n";
    }
    if ($k['index']) {
        [$lat, $lon] = ma_seo_mitte();
        $ort = ma_seo_orte()[$k['ort']] ?? ma_seo_orte()['merzenich'];
        $z .= '<meta name="geo.region" content="DE-NW"><meta name="geo.placename" content="' . $e($ort['name'] . ($k['ort'] !== 'merzenich' ? ', Merzenich' : '')) . '">';
        if ($k['ort'] === 'merzenich') $z .= '<meta name="geo.position" content="' . $lat . ';' . $lon . '"><meta name="ICBM" content="' . $lat . ', ' . $lon . '">';
        elseif (isset($ort['lat'])) $z .= '<meta name="geo.position" content="' . $ort['lat'] . ';' . $ort['lon'] . '"><meta name="ICBM" content="' . $ort['lat'] . ', ' . $ort['lon'] . '">';
        $z .= "\n";
    }
    $titel = $k['typ'] === 'start' ? MA_SEO_MARKE : $k['titel'];
    $z .= '<meta property="og:type" content="' . $e($k['og']) . '"><meta property="og:site_name" content="' . MA_SEO_MARKE . '"><meta property="og:locale" content="de_DE">' . "\n";
    $z .= '<meta property="og:title" content="' . $e($titel) . '">' . "\n";
    if ($k['beschreibung'] !== '') $z .= '<meta property="og:description" content="' . $e($k['beschreibung']) . '">' . "\n";
    if ($k['url'] !== '') $z .= '<meta property="og:url" content="' . esc_url($k['url']) . '">' . "\n";
    $b = $k['bild'];
    $typ = ma_seo_bildtyp((string) $b['url']);
    $z .= '<meta property="og:image" content="' . esc_url($b['url']) . '">' . (str_starts_with((string) $b['url'], 'https://') ? '<meta property="og:image:secure_url" content="' . esc_url($b['url']) . '">' : '') . ($typ !== '' ? '<meta property="og:image:type" content="' . $typ . '">' : '') . ($b['w'] ? '<meta property="og:image:width" content="' . (int) $b['w'] . '"><meta property="og:image:height" content="' . (int) $b['h'] . '">' : '') . '<meta property="og:image:alt" content="' . $e($b['alt']) . '">' . "\n";
    if ($k['og'] === 'article') {
        if ($k['veroeffentlicht']) $z .= '<meta property="article:published_time" content="' . $e($k['veroeffentlicht']) . '">';
        if ($k['geaendert']) $z .= '<meta property="article:modified_time" content="' . $e($k['geaendert']) . '">';
        if ($k['ressort']) $z .= '<meta property="article:section" content="' . $e($k['ressort']) . '">';
        foreach ($k['tags'] as $t) $z .= '<meta property="article:tag" content="' . $e($t) . '">';
        if ($k['tags']) $z .= '<meta name="news_keywords" content="' . $e(implode(', ', $k['tags'])) . '">';
        $z .= "\n";
    }
    $z .= '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="' . $e($titel) . '">' . ($k['beschreibung'] !== '' ? '<meta name="twitter:description" content="' . $e($k['beschreibung']) . '">' : '') . '<meta name="twitter:image" content="' . esc_url($b['url']) . '">' . "\n";
    if ($k['typ'] !== '404') {
        $sameas = ma_seo_sameas();
        $graph = ma_seo_graph($k, ['home' => $home, 'logo' => home_url('/assets/marke/logo-04.png'), 'bild' => ma_seo_standardbild()['url'], 'sameas' => $sameas, 'mitte' => ma_seo_mitte()]);
        $z .= '<script type="application/ld+json">' . wp_json_encode($graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
    echo $z;
}
add_action('wp_head', 'ma_seo_head', 1);

/* ------------------------------------------------------------ Adressen: Ressorts kurz, Blättern, Feeds, Umleitungen */

add_filter('term_link', function (string $url, $term, string $tax): string {
    if ($tax === 'category' && $term instanceof WP_Term && in_array($term->slug, ma_seo_ressort_kategorien(), true)) return home_url('/' . $term->slug . '/');
    return $url;
}, 10, 3);

add_action('init', function (): void {
    $slugs = implode('|', ma_seo_ressort_kategorien());
    add_rewrite_rule("^({$slugs})/?$", 'index.php?category_name=$matches[1]', 'top');
    add_rewrite_rule("^({$slugs})/page/([0-9]+)/?$", 'index.php?category_name=$matches[1]&paged=$matches[2]', 'top');
    add_rewrite_rule("^({$slugs})/feed/(feed|rdf|rss|rss2|atom)/?$", 'index.php?category_name=$matches[1]&feed=$matches[2]', 'top');
    add_rewrite_rule("^({$slugs})/(feed|rdf|rss|rss2|atom)/?$", 'index.php?category_name=$matches[1]&feed=$matches[2]', 'top');
    add_rewrite_rule('^news-sitemap\.xml$', 'index.php?ma_seo=news', 'top');
    add_rewrite_rule('^llms\.txt$', 'index.php?ma_seo=llms', 'top');
    add_rewrite_rule('^llms-full\.txt$', 'index.php?ma_seo=llmsvoll', 'top');
    add_rewrite_rule('^suche/?$', 'index.php?ma_seo=suche', 'top');
    add_rewrite_rule('^([a-f0-9]{32})\.txt$', 'index.php?ma_seo=indexnow&ma_key=$matches[1]', 'top');
    add_rewrite_rule('^(google[a-f0-9]{16})\.html$', 'index.php?ma_seo=googledatei&ma_key=$matches[1]', 'top');
}, 5);
add_filter('query_vars', function (array $v): array { $v[] = 'ma_seo'; $v[] = 'ma_key'; return $v; });
add_filter('redirect_canonical', fn($ziel) => get_query_var('ma_seo') ? false : $ziel);

/* Benutzerliste der REST-Schnittstelle nur für Angemeldete (1.21.0): /wp-json/wp/v2/users
   verriet Besuchern den Anmeldenamen „admin“. Der Editor (angemeldet) braucht sie weiter. */
add_filter('rest_endpoints', function (array $e): array {
    if (is_user_logged_in()) return $e;
    foreach (array_keys($e) as $route) if (str_starts_with($route, '/wp/v2/users')) unset($e[$route]);
    return $e;
});

/* Nach einem Plugin-Update die Regeln einmal neu schreiben (Theme macht dasselbe für seine Adressen). */
add_action('init', function (): void {
    if (get_option('ma_seo_regeln') === MA_CORE_VERSION . '-3') return;
    flush_rewrite_rules(false);
    update_option('ma_seo_regeln', MA_CORE_VERSION . '-3', false);
}, 99);

add_action('template_redirect', function (): void {
    $pfad = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?? '');
    $pfadN = '/' . trim(strtolower($pfad), '/') . '/';
    // Statische Adressen (Fußzeile, Artikel) auf die WordPress-Adresse.
    $um = ma_seo_umleitungen();
    if (isset($um[$pfadN]) || isset($um[rtrim($pfadN, '/')])) {
        $ziel = $um[$pfadN] ?? $um[rtrim($pfadN, '/')];
        if ($ziel === '/?s=') $ziel .= rawurlencode(sanitize_text_field(wp_unslash($_GET['q'] ?? $_GET['s'] ?? '')));
        wp_safe_redirect(home_url($ziel), 301); exit;
    }
    if (get_query_var('ma_seo') === 'suche') { wp_safe_redirect(home_url('/?s=' . rawurlencode(sanitize_text_field(wp_unslash($_GET['q'] ?? $_GET['s'] ?? '')))), 301); exit; }
    // /category/<ressort>/… → /<ressort>/…
    if (preg_match('~^/category/(' . implode('|', ma_seo_ressort_kategorien()) . ')(/.*)?$~', $pfad, $m)) {
        wp_safe_redirect(home_url('/' . $m[1] . ($m[2] ?? '/')), 301); exit;
    }
    // WordPress-Autorenarchive zeigen Anmeldenamen; die Autorenseiten liegen unter /autor/<name>/ (autoren.php).
    if (is_author() && (string) get_query_var('ma_autor') === '') { wp_safe_redirect(home_url('/redaktion/'), 301); exit; }
    // Anhangsseiten: zum Beitrag, sonst zur Datei.
    if (is_attachment()) {
        $a = get_queried_object();
        $ziel = $a instanceof WP_Post && $a->post_parent && get_post_status($a->post_parent) === 'publish' ? get_permalink($a->post_parent) : ($a instanceof WP_Post ? wp_get_attachment_url($a->ID) : home_url('/'));
        if ($ziel) { wp_safe_redirect($ziel, 301); exit; }
    }
    $was = get_query_var('ma_seo');
    if ($was === 'news') {
        nocache_headers(); header('Content-Type: application/xml; charset=utf-8'); header('Cache-Control: public, max-age=600');
        echo ma_seo_news_sitemap_xml(ma_seo_news_eintraege()); exit;
    }
    if ($was === 'indexnow') {
        if ((string) get_query_var('ma_key') !== ma_indexnow_key()) { status_header(404); exit; }
        header('Content-Type: text/plain; charset=utf-8'); echo ma_indexnow_key(); exit;
    }
    if ($was === 'googledatei') {
        $name = ma_seo_google_datei_name((string) get_option('ma_seo_google_datei', ''));
        if ($name === '' || (string) get_query_var('ma_key') !== $name) { status_header(404); exit; }
        header('Content-Type: text/html; charset=utf-8'); echo ma_seo_google_datei_inhalt($name); exit;
    }
    if ($was === 'llms') {
        header('Content-Type: text/plain; charset=utf-8'); header('Cache-Control: public, max-age=3600');
        $seiten = [];
        foreach (['ueber-uns' => 'Über uns', 'redaktion' => 'Redaktion', 'grundsaetze' => 'Publizistische Grundsätze', 'korrekturen' => 'Korrekturen', 'kontakt' => 'Kontakt', 'service' => 'Service', 'impressum' => 'Impressum', 'datenschutz' => 'Datenschutz'] as $slug => $name) {
            $p = get_page_by_path($slug, OBJECT, 'page');
            if ($p instanceof WP_Post && $p->post_status === 'publish') $seiten[] = [$name, get_permalink($p), ma_seo_kuerzen($p->post_excerpt, 120)];
        }
        echo ma_seo_llms_txt(home_url('/'), $seiten, ma_seo_llms_neueste()); exit;
    }
    if ($was === 'llmsvoll') {
        header('Content-Type: text/plain; charset=utf-8'); header('Cache-Control: public, max-age=3600');
        $home = home_url('/');
        $orte = [];
        foreach (ma_seo_orte() as $slug => $d) {
            $e = ma_seo_ort_einleitungen()[$slug] ?? null;
            $text = $e ? implode("\n\n", $e['absaetze']) . "\nQuelle: " . implode(', ', array_map(fn($q) => $q[1], $e['quellen'])) : $d['beschreibung'] . ' ' . ($d['seo'] ?? '');
            $orte[] = [$d['name'], $home . 'ort/' . $slug . '/', $text . (!empty($d['wikidata']) ? "\nWikidata: https://www.wikidata.org/wiki/{$d['wikidata']}" : '')];
        }
        // Faktenseiten (Plan 3.2) erscheinen, sobald sie veröffentlicht sind; vorher fehlen sie einfach.
        $seiten = [];
        foreach (['merzenich-in-zahlen', 'strukturwandel', 'abfall', 'notdienste', 'ueber-uns', 'grundsaetze', 'korrekturen', 'ki-redaktion', 'service', 'impressum'] as $slug) {
            $p = get_page_by_path($slug, OBJECT, 'page');
            if ($p instanceof WP_Post && $p->post_status === 'publish') $seiten[] = [html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'), get_permalink($p), ma_seo_klartext(trim($p->post_excerpt . "\n\n" . $p->post_content))];
        }
        $meldungen = [];
        foreach (get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 25, 'orderby' => 'date', 'order' => 'DESC']) as $p) {
            if (function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($p)) continue;
            $quelle = (string) get_post_meta($p->ID, 'ma_source_url', true);
            $meldungen[] = [html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8') . ' (' . get_post_time('d.m.Y', false, $p) . ')', get_permalink($p), ma_seo_klartext(trim($p->post_excerpt . "\n\n" . $p->post_content), 1200) . ($quelle !== '' ? "\nQuelle: {$quelle}" : '')];
            if (count($meldungen) >= 15) break;
        }
        echo ma_seo_llms_full_txt($home, ['Orte der Gemeinde Merzenich' => $orte, 'Seiten' => $seiten, 'Neueste Meldungen' => $meldungen]); exit;
    }
}, 1);

/** Einträge der News-Sitemap: veröffentlichte Meldungen der letzten 48 Stunden, keine gesponserten. */
function ma_seo_news_eintraege(): array {
    $posts = get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1000, 'date_query' => [['after' => '48 hours ago']], 'orderby' => 'date', 'order' => 'DESC']);
    $aus = [];
    foreach ($posts as $p) {
        if (function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($p)) continue;
        // Nur ein eigenes Bild mit geklärten Rechten, nicht das Standardbild (1.38.0).
        $bild = ma_seo_bild($p);
        $aus[] = ['url' => get_permalink($p), 'titel' => html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'), 'zeit' => get_post_time('c', false, $p),
            'bild' => ($bild['url'] ?? '') !== ma_seo_standardbild()['url'] ? (string) ($bild['url'] ?? '') : ''];
    }
    return $aus;
}

/** Die zehn neuesten veröffentlichten Meldungen für llms.txt (ohne gesponserte): [[titel, url, TT.MM.JJJJ]]. */
function ma_seo_llms_neueste(): array {
    $aus = [];
    foreach (get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 20, 'orderby' => 'date', 'order' => 'DESC']) as $p) {
        if (function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($p)) continue;
        $aus[] = [html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'), get_permalink($p), get_post_time('d.m.Y', false, $p)];
        if (count($aus) >= 10) break;
    }
    return $aus;
}

/* ------------------------------------------------------------ Sitemap und robots.txt */

add_filter('wp_sitemaps_add_provider', fn($provider, string $name) => $name === 'users' ? false : $provider, 10, 2);
// Dünne Themen und übernommene Marktanzeigen nicht in die Sitemap (1.26.0), passend zu noindex.
add_filter('wp_sitemaps_taxonomies_query_args', function (array $args, string $tax): array {
    if ($tax !== 'post_tag') return $args;
    $duenn = get_terms(['taxonomy' => 'post_tag', 'hide_empty' => false, 'fields' => 'ids', 'number' => 0]);
    $duenn = array_values(array_filter((array) $duenn, fn($id) => !ma_seo_thema_indexierbar((int) (get_term((int) $id, 'post_tag')->count ?? 0))));
    if ($duenn) $args['exclude'] = array_merge((array) ($args['exclude'] ?? []), $duenn);
    return $args;
}, 10, 2);
add_filter('wp_sitemaps_posts_query_args', function (array $args, string $typ): array {
    if (!in_array($typ, ['ma_job', 'ma_property'], true)) return $args;
    $args['meta_query'] = [['key' => 'ma_markt_id', 'compare' => 'NOT EXISTS']];
    return $args;
}, 10, 2);
add_filter('wp_sitemaps_post_types', fn(array $t) => array_diff_key($t, array_flip(['ma_obituary', 'ma_family_notice', 'attachment'])));
add_filter('wp_sitemaps_taxonomies', fn(array $t) => array_diff_key($t, array_flip(['ma_family_type', 'ma_source_status', 'post_format'])));
add_filter('robots_txt', fn(string $out, bool $public) => $public ? ma_seo_robots_txt($out, home_url('/')) : $out, 10, 2);

/*
 * Übersichtsseiten ohne eigenen Beitrag (1.27.0): /nachrichten/ und
 * /unternehmen/ (Routen des Themes) und /termine/ (Archiv der Termine) standen
 * in keiner Sitemap. Eigene Sitemap „bereiche“, lastmod = letzte Änderung der
 * passenden Inhalte. Seiten wie /heute/ stehen als WordPress-Seite schon in
 * der Seiten-Sitemap.
 */
function ma_seo_bereiche_liste(string $home, array $zeiten): array {
    $liste = [];
    foreach (['nachrichten', 'termine', 'unternehmen'] as $b) {
        $e = ['loc' => $home . $b . '/'];
        if (!empty($zeiten[$b])) $e['lastmod'] = (string) $zeiten[$b];
        $liste[] = $e;
    }
    return $liste;
}
function ma_seo_bereiche_zeit(string $typ): string {
    $s = (string) get_lastpostmodified('blog', $typ);
    if ($s === '') return '';
    try { return (new DateTimeImmutable($s, wp_timezone()))->format('c'); } catch (Exception $e) { return ''; }
}
add_action('init', function (): void {
    if (!class_exists('WP_Sitemaps_Provider') || !function_exists('wp_register_sitemap_provider')) return;
    if (!class_exists('MA_Sitemap_Bereiche')) {
        class MA_Sitemap_Bereiche extends WP_Sitemaps_Provider {
            public function __construct() { $this->name = 'bereiche'; $this->object_type = 'bereich'; }
            public function get_url_list($page_num, $object_subtype = '') {
                return ma_seo_bereiche_liste(home_url('/'), ['nachrichten' => ma_seo_bereiche_zeit('post'), 'termine' => ma_seo_bereiche_zeit('ma_event'), 'unternehmen' => ma_seo_bereiche_zeit('ma_business')]);
            }
            public function get_max_num_pages($object_subtype = '') { return 1; }
        }
    }
    wp_register_sitemap_provider('bereiche', new MA_Sitemap_Bereiche());
}, 20);

/* Ortsteile: Beschreibung am Begriff, wenn noch keine eingetragen ist (Text der statischen Ortsseiten). Nie überschreiben. */
function ma_seo_orte_beschreiben(): void {
    if (get_option('ma_seo_orte_114') === '1') return;
    foreach (ma_seo_orte() as $slug => $d) {
        $t = get_term_by('slug', $slug, 'ma_location');
        if ($t instanceof WP_Term && trim((string) $t->description) === '') wp_update_term($t->term_id, 'ma_location', ['description' => $d['beschreibung']]);
    }
    update_option('ma_seo_orte_114', '1', false);
}
add_action('admin_init', 'ma_seo_orte_beschreiben');

/* Ressort „Menschen“: die Navigation verlinkt /menschen/, die Kategorie fehlte auf der Installation (404). Einmalig anlegen. */
function ma_seo_menschen_anlegen(): void {
    if (get_option('ma_seo_menschen_115') === '1') return;
    if (!term_exists('menschen', 'category')) wp_insert_term('Menschen', 'category', ['slug' => 'menschen', 'description' => ma_seo_ressorte()['menschen'][2]]);
    update_option('ma_seo_menschen_115', '1', false);
}
add_action('admin_init', 'ma_seo_menschen_anlegen');

/* ------------------------------------------------------------ IndexNow (Bing, DuckDuckGo, Ecosia, Yandex; Google nimmt es nicht an) */

/** Schlüssel (32 Hex), einmal erzeugt; die Schlüsseldatei liegt unter /{key}.txt (Rewrite ma_seo=indexnow). */
function ma_indexnow_key(): string {
    $k = (string) get_option('ma_indexnow_key', '');
    if (!preg_match('/^[a-f0-9]{32}$/', $k)) { $k = bin2hex(random_bytes(16)); update_option('ma_indexnow_key', $k, false); }
    return $k;
}

/** Nutzlast für api.indexnow.org (reine Funktion). */
function ma_indexnow_nutzlast(string $host, string $key, array $urls): array {
    $urls = array_values(array_unique(array_filter(array_map('strval', $urls), fn($u) => str_starts_with($u, 'https://' . $host . '/') || str_starts_with($u, 'http://' . $host . '/'))));
    return ['host' => $host, 'key' => $key, 'keyLocation' => 'https://' . $host . '/' . $key . '.txt', 'urlList' => array_slice($urls, 0, 10000)];
}

/** Adressen sammeln und am Ende der Anfrage einmal melden (nicht in der Testinstanz ohne öffentlichen Host). */
function ma_indexnow_merken(string $url): void {
    static $gemerkt = [];
    if ($url === '' || isset($gemerkt[$url])) return;
    $gemerkt[$url] = true;
    $GLOBALS['ma_indexnow_urls'][] = $url;
    if (!has_action('shutdown', 'ma_indexnow_senden')) add_action('shutdown', 'ma_indexnow_senden');
}

function ma_indexnow_senden(): void {
    $urls = (array) ($GLOBALS['ma_indexnow_urls'] ?? []);
    if (!$urls) return;
    $host = (string) parse_url(home_url('/'), PHP_URL_HOST);
    $nutzlast = ma_indexnow_nutzlast($host, ma_indexnow_key(), $urls);
    if (!$nutzlast['urlList'] || in_array($host, ['localhost', '127.0.0.1'], true) || str_ends_with($host, '.local')) return;
    $antwort = wp_remote_post('https://api.indexnow.org/indexnow', ['timeout' => 5, 'headers' => ['Content-Type' => 'application/json; charset=utf-8'], 'body' => wp_json_encode($nutzlast)]);
    $status = is_wp_error($antwort) ? $antwort->get_error_message() : (string) wp_remote_retrieve_response_code($antwort);
    update_option('ma_indexnow_letzter', ['zeit' => time(), 'anzahl' => count($nutzlast['urlList']), 'status' => $status, 'url' => $nutzlast['urlList'][0]], false);
}

/** Veröffentlichte Meldungen, Seiten, Termine und Vereinsprofile melden: beim Veröffentlichen und bei jeder Änderung. */
add_action('transition_post_status', function (string $neu, string $alt, WP_Post $p): void {
    if (!in_array($p->post_type, ['post', 'page', 'ma_event', 'ma_club'], true)) return;
    if ($neu === 'publish' || $alt === 'publish') ma_indexnow_merken((string) get_permalink($p));
    if ($neu === 'publish' && $alt !== 'publish') ma_indexnow_merken(home_url('/'));
}, 10, 3);
add_action('post_updated', function (int $id, WP_Post $nach): void {
    if ($nach->post_status === 'publish' && in_array($nach->post_type, ['post', 'page', 'ma_event', 'ma_club'], true)) ma_indexnow_merken((string) get_permalink($nach));
}, 10, 2);

/* ------------------------------------------------------------ Backend: Merzenich Aktuell → SEO */

/**
 * Website eines Veranstalters, wenn sie bekannt ist: Gemeinde, Kreis oder ein
 * Verein aus dem Vereinsverzeichnis (Name gleich oder enthalten, ohne „e.V.“).
 * Sonst leer; nichts wird geraten.
 */
function ma_seo_veranstalter_url(string $name): string {
    $norm = fn(string $x): string => trim(preg_replace('/\s+/', ' ', preg_replace('/\be\.? ?v\.?\b|[^\p{L}\p{N} ]/iu', ' ', mb_strtolower($x))));
    $n = $norm($name);
    if ($n === '') return '';
    $fest = ['gemeinde merzenich' => 'https://www.gemeinde-merzenich.de/', 'kreis düren' => 'https://www.kreis-dueren.de/', 'kreis dueren' => 'https://www.kreis-dueren.de/', 'feuerwehr merzenich' => 'https://www.feuerwehr-merzenich.de/'];
    foreach ($fest as $k => $u) if ($n === $k || str_starts_with($n, $k . ' ')) return $u;
    if (!function_exists('ma_vereinsverzeichnis')) return '';
    foreach (ma_vereinsverzeichnis() as $v) {
        $w = (string) ($v['website'] ?? '');
        if ($w === '' || !preg_match('#^https?://#', $w)) continue;
        $vn = $norm((string) ($v['name'] ?? ''));
        if ($vn === '') continue;
        // Enthalten nur als ganze Wörter und ab 8 Zeichen, damit „Chor“ nicht auf „Chorfest“ passt.
        $ganz = fn(string $lang, string $kurz): bool => mb_strlen($kurz) >= 8 && preg_match('/(^| )' . preg_quote($kurz, '/') . '( |$)/u', $lang) === 1;
        if ($vn === $n || $ganz($vn, $n) || $ganz($n, $vn)) return $w;
    }
    return '';
}

/** Angebot aus dem Preisfeld: „frei/kostenlos/0 €“ oder eine Zahl mit Euro; sonst keins. */
function ma_seo_angebot(string $preis, string $url): array {
    $p = trim($preis);
    if ($p === '') return [];
    if (preg_match('/^(kostenlos|kostenfrei|frei|eintritt frei|gratis|0 ?(€|euro))/iu', $p)) $betrag = '0';
    elseif (preg_match('/(\d+(?:[.,]\d{1,2})?)\s*(€|euro)/iu', $p, $m)) $betrag = str_replace(',', '.', $m[1]);
    else return [];
    return ['@type' => 'Offer', 'price' => $betrag, 'priceCurrency' => 'EUR', 'url' => $url, 'availability' => 'https://schema.org/InStock'];
}

/**
 * Offizielle Profile (sameAs): Option aus SEO & Geo, ohne Vorgabe. Das
 * Instagram-Profil (04.10.2026) ist seit 07.10.2026 deaktiviert und wird
 * einmalig aus einer gespeicherten Liste entfernt; danach entscheidet nur das Feld.
 */
function ma_seo_sameas(): array {
    $o = get_option('ma_seo_sameas', []);
    return array_values(array_filter(array_map('trim', (array) $o), 'ma_seo_url_gueltig'));
}

add_action('init', function (): void {
    if (get_option('ma_seo_sameas_ohne_instagram')) return;
    $o = get_option('ma_seo_sameas', null);
    if (is_array($o)) update_option('ma_seo_sameas', array_values(array_filter($o, fn($u): bool => stripos((string) $u, 'instagram.com/merzenichaktuell') === false)));
    update_option('ma_seo_sameas_ohne_instagram', 1, false);
});

add_action('admin_menu', function (): void {
    add_submenu_page('merzenich-aktuell', 'SEO & Geo', 'SEO & Geo', 'manage_options', 'ma-seo', 'ma_seo_seite_admin');
}, 31);

add_action('admin_post_ma_seo_speichern', function (): void {
    if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.', 403);
    check_admin_referer('ma_seo_speichern');
    $urls = array_values(array_filter(array_map(fn($u) => esc_url_raw(trim($u)), explode("\n", (string) wp_unslash($_POST['sameas'] ?? ''))), 'ma_seo_url_gueltig'));
    update_option('ma_seo_sameas', $urls, false);
    update_option('ma_seo_google', sanitize_text_field(wp_unslash($_POST['google'] ?? '')), false);
    update_option('ma_seo_google_datei', ma_seo_google_datei_name(sanitize_text_field(wp_unslash($_POST['google_datei'] ?? ''))), false);
    update_option('ma_seo_bing', sanitize_text_field(wp_unslash($_POST['bing'] ?? '')), false);
    wp_safe_redirect(admin_url('admin.php?page=ma-seo&gespeichert=1')); exit;
});

function ma_seo_seite_admin(): void {
    if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    $home = home_url('/');
    echo '<div class="wrap"><h1>SEO &amp; Geo</h1>';
    if (isset($_GET['gespeichert'])) echo '<div class="notice notice-success is-dismissible"><p>Gespeichert.</p></div>';
    echo '<p>Das Plugin gibt auf jeder Seite Titel, Description, Canonical, Open Graph, Geo-Angaben und strukturierte Daten aus; Sitemaps und robots.txt sind eingerichtet. Diese Angaben kann nur der Betreiber liefern:</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="ma_seo_speichern">'; wp_nonce_field('ma_seo_speichern');
    echo '<table class="form-table"><tr><th><label for="sameas">Offizielle Profile (sameAs)</label></th><td><textarea id="sameas" name="sameas" rows="4" class="large-text" placeholder="https://www.facebook.com/…&#10;https://www.instagram.com/…&#10;https://whatsapp.com/channel/…">' . esc_textarea(implode("\n", ma_seo_sameas())) . '</textarea><p class="description">Eine Adresse je Zeile: Facebook, Instagram, WhatsApp-Kanal, YouTube. Erscheint in den strukturierten Daten der Organisation.</p></td></tr>';
    echo '<tr><th><label for="google">Google Search Console</label></th><td><input id="google" name="google" class="regular-text" value="' . esc_attr((string) get_option('ma_seo_google', '')) . '"><p class="description">Inhalt des HTML-Tags <code>google-site-verification</code> (nur der Code).</p></td></tr>';
    $gd = ma_seo_google_datei_name((string) get_option('ma_seo_google_datei', ''));
    echo '<tr><th><label for="google_datei">Google-Bestätigungsdatei</label></th><td><input id="google_datei" name="google_datei" class="regular-text" value="' . esc_attr($gd) . '" placeholder="google0123456789abcdef"><p class="description">Methode „HTML-Datei“ der Search Console: Dateiname ohne .html eintragen; die Datei liefert das Plugin dann unter ' . ($gd !== '' ? '<a href="' . esc_url($home . $gd . '.html') . '" target="_blank"><code>/' . esc_html($gd) . '.html</code></a>' : '<code>/google….html</code>') . ' aus.</p></td></tr>';
    echo '<tr><th><label for="bing">Bing Webmaster Tools</label></th><td><input id="bing" name="bing" class="regular-text" value="' . esc_attr((string) get_option('ma_seo_bing', '')) . '"><p class="description">Inhalt des Tags <code>msvalidate.01</code>.</p></td></tr></table>';
    submit_button('Speichern'); echo '</form>';
    [$lat, $lon] = ma_seo_mitte();
    echo '<h2>Prüfen</h2><ul>';
    foreach (['wp-sitemap.xml' => 'Sitemap (Meldungen, Seiten, Termine, Vereine, Ressorts, Orte, Themen)', 'news-sitemap.xml' => 'News-Sitemap (Meldungen der letzten 48 Stunden)', 'robots.txt' => 'robots.txt', 'llms.txt' => 'llms.txt für KI-Suchen', 'feed/' => 'RSS-Feed'] as $pfad => $name) {
        echo '<li><a href="' . esc_url($home . $pfad) . '" target="_blank">' . esc_html($name) . '</a> <code>/' . esc_html($pfad) . '</code></li>';
    }
    echo '</ul><p>Strukturierte Daten einer Meldung prüfen: <a href="https://search.google.com/test/rich-results" target="_blank">Google Rich-Results-Test</a> oder <a href="https://validator.schema.org/" target="_blank">validator.schema.org</a> mit der Adresse der Meldung.</p>';
    echo '<p>Ortsmitte Merzenich für Geo-Angaben: ' . esc_html($lat . ', ' . $lon) . ' (aus den Wetter-Einstellungen). Ortsteil-Koordinaten für Golzheim und Girbelsrath stammen aus GeoNames; für Morschenich und Bürgewald werden keine ausgegeben, weil dort keine verlässliche Quelle vorliegt.</p>';
    $letzter = (array) get_option('ma_indexnow_letzter', []);
    echo '<h2>IndexNow (Bing, DuckDuckGo, Ecosia)</h2><p>Jede Veröffentlichung und Änderung wird automatisch gemeldet. Schlüsseldatei: <a href="' . esc_url($home . ma_indexnow_key() . '.txt') . '" target="_blank"><code>/' . esc_html(ma_indexnow_key()) . '.txt</code></a>. '
        . ($letzter ? 'Letzte Meldung: ' . esc_html(wp_date('d.m.Y H:i', (int) $letzter['zeit'])) . ', ' . (int) $letzter['anzahl'] . ' Adresse(n), Antwort ' . esc_html((string) $letzter['status']) . ' (200 und 202 heißen angenommen).' : 'Noch keine Meldung verschickt.') . ' Google nimmt IndexNow nicht an; dort gilt die Search Console.</p>';
    $ws = (array) get_option('ma_websub_letzter', []);
    echo '<h2>Google News, Discover, Microsoft Start, Apple News</h2>';
    echo '<p>Technisch ist alles vorbereitet: Feed mit Bildern und Bildnachweis (<a href="' . esc_url($home . 'feed/') . '" target="_blank"><code>/feed/</code></a>), News-Sitemap, strukturierte Daten, Vorschaubilder ab 1200 px, IndexNow. Jede Veröffentlichung meldet den Feed außerdem an den WebSub-Hub (' . esc_html(MA_WEBSUB_HUB) . '), damit Feed-Dienste sofort nachladen. '
        . ($ws ? 'Letzte Hub-Meldung: ' . esc_html(wp_date('d.m.Y H:i', (int) $ws['zeit'])) . ', ' . (int) $ws['anzahl'] . ' Feed(s), Antwort ' . esc_html((string) $ws['status']) . ' (204 heißt angenommen).' : 'Noch keine Hub-Meldung verschickt.') . '</p>';
    echo '<p>Die Aufnahme selbst kann nur der Betreiber beantragen; danach läuft alles automatisch:</p><ol>'
        . '<li><strong>Google News:</strong> <a href="https://publishercenter.google.com/" target="_blank">Publisher Center</a> → Publikation „Merzenich Aktuell“ anlegen, Website ' . esc_html($home) . ' bestätigen (geht über die Search Console), unter „Inhalte“ den Feed <code>' . esc_html($home . 'feed/') . '</code> eintragen, Logo hochladen, Prüfung beantragen. Google Discover (die Nachrichten im Chrome-Startbildschirm und in der Google-App) braucht keine Anmeldung, nur die Indexierung und große Bilder.</li>'
        . '<li><strong>Microsoft Start / Edge-Startseite / Bing News:</strong> <a href="https://partnerhub.microsoftstart.com/" target="_blank">Microsoft Start Partner Hub</a>, Feed <code>' . esc_html($home . 'feed/') . '</code> angeben; IndexNow ist schon aktiv.</li>'
        . '<li><strong>Apple News:</strong> <a href="https://www.icloud.com/newspublisher/" target="_blank">Apple News Publisher</a> mit Apple-ID, Kanal mit demselben Feed anlegen.</li>'
        . '<li><strong>Benachrichtigungen für Leser:</strong> siehe Abschnitt „Push-Benachrichtigungen“ unten; keine Anmeldung bei einem Dienst nötig.</li></ol>';
    if (function_exists('ma_push_moeglich')) {
        $pl = (array) get_option('ma_push_letzter', []);
        echo '<h2>Push-Benachrichtigungen (Web Push, ohne Fremddienst)</h2>';
        if (!ma_push_moeglich()) echo '<p><strong>Nicht verfügbar:</strong> diese PHP-Installation hat kein OpenSSL mit P-256/AES-GCM oder kein hash_hkdf. Leser bekommen weiter die Hinweise bei offener Seite (/api/latest.json).</p>';
        else echo '<p>Leser, die „Live-Meldungen“ erlauben und Benachrichtigungen zulassen, bekommen jede neu veröffentlichte Meldung aufs Handy oder den Rechner, auch bei geschlossenem Browser. Verschlüsselt und signiert mit dem Schlüssel dieser Seite; es gibt keinen Testversand an Leser.</p>'
            . '<p>Abonnenten: <strong>' . (int) ma_push_abonnenten() . '</strong> · Öffentlicher Schlüssel: <code>' . esc_html(substr(ma_push_oeffentlich(), 0, 16)) . '…</code> · Service Worker: <a href="' . esc_url($home . 'sw.js') . '" target="_blank"><code>/sw.js</code></a><br>'
            . ($pl ? 'Letzter Versand: ' . esc_html(wp_date('d.m.Y H:i', (int) $pl['zeit'])) . ' · „' . esc_html((string) $pl['titel']) . '“ · gesendet ' . (int) $pl['gesendet'] . ', gelöscht ' . (int) $pl['geloescht'] . ', Fehler ' . (int) $pl['fehler'] : 'Noch kein Versand (löst die erste Veröffentlichung einer Meldung aus).') . '</p>';
    }
    echo '<h2>Nach dem Einspielen</h2><ol><li>Search Console: Property für ' . esc_html($home) . ' anlegen, Code oben eintragen, dann <code>wp-sitemap.xml</code> und <code>news-sitemap.xml</code> einreichen.</li><li>Google Publisher Center: Publikation „Merzenich Aktuell“ mit der Startseite anlegen (nur der Betreiber kann das).</li><li>Offizielle Profile oben eintragen, sobald sie bestehen.</li></ol></div>';
}
