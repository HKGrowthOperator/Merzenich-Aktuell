<?php
if (!defined('ABSPATH')) { exit; }

function ma_register_editorial_hooks(): void {
    add_action('add_meta_boxes', 'ma_editorial_boxes');
    add_action('save_post', 'ma_save_editorial_meta');
    add_filter('wp_insert_post_data','ma_publication_gate',20,2);
}

/** Inhalte mit Bild brauchen Bildherkunft - nicht nur Beitraege. */
const MA_IMAGE_PROVENANCE_TYPES = ['ma_property','ma_job','ma_event','ma_club','ma_business','ma_family_notice','ma_tip'];

function ma_editorial_boxes(): void {
    add_meta_box('ma_editorial','Redaktion & Quelle','ma_editorial_box','post','normal','high');
    add_meta_box('ma_ai','KI & redaktionelle Transparenz','ma_ai_box','post','side','default');

    // Bisher gab es Bildcredit, Lizenz und Rechtefreigabe nur am Beitrag. Eine
    // Immobilie oder eine Stelle konnte damit ein Bild tragen, zu dem nirgends
    // stand, woher es kommt. Dieselben Feldnamen, nur an mehr Inhaltsarten.
    // Traueranzeigen bleiben aussen vor, sie zeigen bewusst kein Bild.
    foreach (MA_IMAGE_PROVENANCE_TYPES as $typ) {
        add_meta_box('ma_image_provenance','Bildherkunft','ma_image_provenance_box',$typ,'side','default');
    }
}

/**
 * Welches Beitragsbild zeigte der Kasten beim Laden? (17.10.2026) Setzt das Plugin beim
 * Veröffentlichen ein Poolfoto, gehören die Bildangaben im Kasten noch zum Stand davor (meist:
 * kein Bild; der Block-Editor lädt den Kasten nicht neu). ma_save_editorial_meta legt sie dann
 * in die Sicherung des Poolfotos, statt dessen Nachweis zu überschreiben.
 */
const MA_EDITORIAL_BILDFELDER = ['ma_image_credit', 'ma_image_license', 'ma_image_original_url', 'ma_image_type', 'ma_image_rights_verified'];
function ma_bildfelder_geladen_feld(): void {
    echo '<input type="hidden" name="ma_bildfelder_bild" value="' . (int) get_post_thumbnail_id((int) get_the_ID()) . '">';
}

/** Auswahlfeld fuer ma_image_type. */
function ma_image_type_field(): void {
    ma_bildfelder_geladen_feld();
    $wert=(string)get_post_meta(get_the_ID(),'ma_image_type',true);
    echo '<p><label><strong>Bildtyp</strong><br><select style="width:100%" name="ma_image_type">';
    echo '<option value="">— nicht gesetzt —</option>';
    foreach (MA_IMAGE_TYPES as $k=>$label) {
        echo '<option value="'.esc_attr($k).'" '.selected($wert,$k,false).'>'.esc_html($label).'</option>';
    }
    echo '</select></label><br><span class="description">Ohne geprüfte Bildrechte oder eingetragene Lizenz zeigt die Seite das Bild nicht; die Meldung erscheint dann ohne Bild.</span></p>';
    if (function_exists('ma_partner_rights_field')) ma_partner_rights_field((int)get_the_ID());
}

function ma_image_provenance_box(): void {
    wp_nonce_field('ma_editorial_save','ma_editorial_nonce');
    ma_image_type_field();
    ma_field('Bildcredit','ma_image_credit');
    ma_field('Bildlizenz / Freigabe','ma_image_license');
    ma_field('Original-Bild-URL','ma_image_original_url','url');
    ma_check('Bildrechte geprüft','ma_image_rights_verified');
}

function ma_field(string $label,string $name,string $type='text',string $description=''): void {
    $value=(string)get_post_meta(get_the_ID(),$name,true);
    if ($type==='datetime-local' && preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/',$value)) $value=str_replace(' ','T',substr($value,0,16));
    $v=esc_attr($value);
    echo '<p><label><strong>'.esc_html($label).'</strong><br><input style="width:100%" type="'.esc_attr($type).'" name="'.esc_attr($name).'" value="'.$v.'"></label>';
    if($description!=='') echo '<br><span class="description">'.esc_html($description).'</span>';
    echo '</p>';
}

function ma_check(string $label,string $name): void {
    $partner = function_exists('ma_current_partner_policy') ? ma_current_partner_policy() : null;
    if ($partner && in_array($name, ['ma_source_verified','ma_date_verified','ma_place_verified','ma_image_rights_verified','ma_human_reviewed','ma_top_pinned'], true)) {
        echo '<p><strong>'.esc_html($label).':</strong> <span class="description">wird von der Redaktion geprüft</span></p>';
        return;
    }
    $v=(string)get_post_meta(get_the_ID(),$name,true);
    echo '<p><label><input type="checkbox" name="'.esc_attr($name).'" value="1" '.checked($v,'1',false).'> '.esc_html($label).'</label></p>';
}

function ma_editorial_box(): void {
    wp_nonce_field('ma_editorial_save','ma_editorial_nonce');
    $partner = function_exists('ma_current_partner_policy') ? ma_current_partner_policy() : null;
    // Beitragsdaten (03.10.2026, KBS-Artikelvorlage): Quelle getrennt von der eigenen Veröffentlichung.
    echo '<h4 style="margin:4px 0 0">Quelle</h4>';
    ma_field('Quelle (Herausgeber, Stelle)','ma_source_publisher','text','z. B. Freiwillige Feuerwehr Merzenich, Gemeinde Merzenich, Kreispolizeibehörde Düren');
    ma_field('Quellen-URL (Originalquelle)','ma_source_url','url');
    ma_field('Quelldatum (ursprüngliche Information)','ma_source_published_at','datetime-local');
    ma_field('Quelle zuletzt geprüft','ma_source_checked_at','datetime-local');
    if (!$partner) {
        echo '<h4 style="margin:14px 0 0">Beitrag</h4>';
        ma_field('Dachzeile (Kicker)','ma_kicker','text','Kurze Zeile über der Überschrift. Leer = Name der Rubrik.');
        ma_field('Organisation (einreichende Stelle)','ma_organisation','text','Bei Einreichungen über einen Partnerzugang automatisch gesetzt.');
        ma_field('Aktualisiert am (öffentlich angezeigt)','ma_aktualisiert','datetime-local','Nur bei einer inhaltlichen Aktualisierung setzen. Erscheint auf der Meldung als „Aktualisiert“.');
        ma_field('Hervorhebung bis','ma_top_until','datetime-local','Ein fester Platz (Aufmacher, Bühne, Rubrikfläche; Box „Startseite“) endet zu diesem Zeitpunkt automatisch. Leer = bis die Redaktion ihn ändert.');
        echo '<h4 style="margin:14px 0 0">Suchmaschinen</h4>';
        ma_field('SEO-Titel','ma_seo_titel','text','Leer = Überschrift. Höchstens etwa 60 Zeichen.');
        $b=(string)get_post_meta(get_the_ID(),'ma_seo_beschreibung',true);
        echo '<p><label><strong>SEO-Beschreibung</strong><br><textarea style="width:100%" rows="2" maxlength="300" name="ma_seo_beschreibung">'.esc_textarea($b).'</textarea></label><br><span class="description">Leer = Anriss. Etwa 150 Zeichen.</span></p>';
    } elseif (($org = (string) get_post_meta(get_the_ID(), 'ma_organisation', true)) !== '') {
        echo '<p><strong>Organisation:</strong> '.esc_html($org).'</p>';
    }
    echo '<h4 style="margin:14px 0 0">Bild und Prüfung</h4>';
    ma_image_type_field();
    ma_field('Bildcredit','ma_image_credit');
    ma_field('Bildlizenz / Freigabe','ma_image_license');
    ma_field('Original-Bild-URL','ma_image_original_url','url');
    ma_check('Quelle geprüft','ma_source_verified');
    ma_check('Datum geprüft','ma_date_verified');
    ma_check('Ort geprüft','ma_place_verified');
    ma_check('Bildrechte geprüft','ma_image_rights_verified');
    ma_check('Redaktionelle Prüfung abgeschlossen','ma_human_reviewed');
}

function ma_ai_box(): void {
    ma_check('KI wurde eingesetzt','ma_ai_used');
    ma_field('Art der KI-Nutzung','ma_ai_use_type');
    ma_check('KI-generiertes Bild','ma_ai_generated_image');
    ma_check('KI-manipuliertes Bild','ma_ai_manipulated_image');
    ma_field('Geprüft von','ma_reviewed_by');
    ma_field('Geprüft am','ma_reviewed_at','datetime-local');
    ma_field('Redaktionelle Verantwortung','ma_editorial_responsibility');
}

function ma_editorial_datetime_value($value): string {
    $value=is_string($value)?wp_unslash($value):'';
    if ($value==='') return '';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/',$value)) return '';
    return str_replace('T',' ',$value).':00';
}

function ma_save_editorial_meta(int $post_id): void {
    // Die Bildherkunft wird jetzt auch an Immobilien, Stellen, Terminen,
    // Vereinen und Betrieben gepflegt. Ohne diese Zeile speicherte die neue
    // Metabox stillschweigend nichts - der haeufigste Fehler beim Ausweiten
    // einer Metabox auf weitere Inhaltsarten.
    $typ = get_post_type($post_id);
    if ($typ !== 'post' && !in_array($typ, MA_IMAGE_PROVENANCE_TYPES, true)) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (!isset($_POST['ma_editorial_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ma_editorial_nonce'])),'ma_editorial_save')) return;
    if (!current_user_can('edit_post',$post_id)) return;

    // Steht das automatisch vergebene Poolfoto:
    // - Zeigte der Kasten beim Laden ein anderes Bild (meist noch keins), gehören seine Bildangaben zum Stand vor dem
    //   Poolfoto: Sie kommen in dessen Sicherung (_ma_bildpool_vorher) und gelten, sobald das eigentliche Bild kommt.
    // - Zeigte er das Poolfoto und ändert die Redaktion eine Angabe, gilt das Bild als ihres (kein automatischer Tausch).
    // - Zeigte er ein Poolfoto, das inzwischen ersetzt ist (vom Plugin neu verteilt oder von der Redaktion durch ein
    //   eigenes Bild), sind Werte, die genau den Angaben jenes Poolfotos entsprechen, veraltet: weder an den Inhalt
    //   noch in die Sicherung. Bewusst geänderte Felder zählen.
    $geladenBild = isset($_POST['ma_bildfelder_bild']) ? (int) $_POST['ma_bildfelder_bild'] : null;
    $jetztBild = (int) get_post_thumbnail_id((int) $post_id);
    $poolBild = $geladenBild !== null && function_exists('ma_bildpool_auto_aktuell') && ma_bildpool_auto_aktuell((int) $post_id);
    $altesPoolfoto = $geladenBild !== null && $geladenBild > 0 && $geladenBild !== $jetztBild && defined('MA_BILDPOOL_TAX') && has_term('', MA_BILDPOOL_TAX, $geladenBild);
    $poolWerte = $altesPoolfoto ? ['ma_image_credit' => (string) get_post_meta($geladenBild, 'ma_image_credit', true), 'ma_image_license' => (string) get_post_meta($geladenBild, 'ma_image_license', true),
        'ma_image_original_url' => (string) get_post_meta($geladenBild, 'ma_image_original_url', true), 'ma_image_type' => 'symbol', 'ma_image_rights_verified' => '1'] : [];
    $anderesBild = $poolBild && !$altesPoolfoto && $geladenBild !== $jetztBild;
    $sicherung = $anderesBild ? get_post_meta((int) $post_id, '_ma_bildpool_vorher', true) : null;
    if ($anderesBild && !is_array($sicherung)) $sicherung = [];
    $bildGeaendert = false;
    // true: Feld ist erledigt (veraltet oder in der Sicherung), nicht am Inhalt schreiben.
    $unveraendert = function (string $k, string $neu) use ($post_id, $poolBild, $anderesBild, $altesPoolfoto, $poolWerte, &$sicherung, &$bildGeaendert): bool {
        if (!in_array($k, MA_EDITORIAL_BILDFELDER, true)) return false;
        if ($altesPoolfoto) { if ($neu === $poolWerte[$k]) return true; $bildGeaendert = true; return false; }
        if (!$poolBild) return false;
        if ($anderesBild) { $sicherung[$k] = $neu; return true; }
        $alt = (string) get_post_meta((int) $post_id, $k, true);
        if ($k === 'ma_image_rights_verified') $alt = $alt === '1' ? '1' : '0';
        if ($alt !== $neu) $bildGeaendert = true;
        return false;
    };
    $text=['ma_source_publisher','ma_image_credit','ma_image_license','ma_ai_use_type','ma_reviewed_by','ma_editorial_responsibility','ma_kicker','ma_organisation','ma_seo_titel'];
    // Bildtyp ist eine feste Auswahl. Alles ausserhalb der Liste wird verworfen,
    // damit der Resolver sich auf den Wert verlassen kann.
    $bildtyp = isset($_POST['ma_image_type']) ? sanitize_key(wp_unslash($_POST['ma_image_type'])) : '';
    if (isset($_POST['ma_image_type']) && $unveraendert('ma_image_type', $bildtyp)) {}
    elseif ($bildtyp !== '' && isset(MA_IMAGE_TYPES[$bildtyp])) update_post_meta($post_id,'ma_image_type',$bildtyp);
    elseif (isset($_POST['ma_image_type'])) delete_post_meta($post_id,'ma_image_type');
    $url=['ma_source_url','ma_image_original_url'];
    $datetime=['ma_source_published_at','ma_source_checked_at','ma_top_until','ma_reviewed_at','ma_aktualisiert'];
    $number=['ma_editorial_priority'];
    $checks=['ma_source_verified','ma_date_verified','ma_place_verified','ma_image_rights_verified','ma_human_reviewed','ma_ai_used','ma_ai_generated_image','ma_ai_manipulated_image'];

    // Nur Felder, die das Formular mitschickt (03.10.2026): ein Feld, das der
    // Kasten nicht zeigt (Partner, ältere Felder), wird nicht gelöscht oder genullt.
    foreach($text as $k){if(!isset($_POST[$k]))continue;$v=sanitize_text_field(wp_unslash($_POST[$k]));if($unveraendert($k,$v))continue;$v===''?delete_post_meta($post_id,$k):update_post_meta($post_id,$k,$v);}
    if(isset($_POST['ma_seo_beschreibung'])){$v=sanitize_textarea_field(wp_unslash($_POST['ma_seo_beschreibung']));$v===''?delete_post_meta($post_id,'ma_seo_beschreibung'):update_post_meta($post_id,'ma_seo_beschreibung',$v);}
    foreach($url as $k){if(!isset($_POST[$k]))continue;$v=esc_url_raw(wp_unslash($_POST[$k]));if($unveraendert($k,$v))continue;$v===''?delete_post_meta($post_id,$k):update_post_meta($post_id,$k,$v);}
    foreach($datetime as $k){if(!isset($_POST[$k]))continue;$v=ma_editorial_datetime_value($_POST[$k]);$v===''?delete_post_meta($post_id,$k):update_post_meta($post_id,$k,$v);}
    foreach($number as $k){if(!isset($_POST[$k]))continue;$v=max(0,min(100,(int)$_POST[$k]));update_post_meta($post_id,$k,(string)$v);}
    $partner = function_exists('ma_current_partner_policy') ? ma_current_partner_policy() : null;
    foreach($checks as $k) {
        // Nur Felder anfassen, die das abgeschickte Formular auch kennt. Die
        // Service-Metabox zeigt allein die Bildrechte; wuerde man hier pauschal
        // auf '0' setzen, loeschte das Speichern einer Immobilie die
        // redaktionellen Freigaben eines Beitrags-Workflows mit.
        if ($typ !== 'post' && $k !== 'ma_image_rights_verified') continue;
        if ($partner && in_array($k, ['ma_source_verified','ma_date_verified','ma_place_verified','ma_image_rights_verified','ma_human_reviewed'], true)) {
            delete_post_meta($post_id,$k);
            continue;
        }
        if ($k === 'ma_image_rights_verified' && $unveraendert($k, isset($_POST[$k]) ? '1' : '0')) continue;
        update_post_meta($post_id,$k,isset($_POST[$k])?'1':'0');
    }
    if ($anderesBild) update_post_meta((int) $post_id, '_ma_bildpool_vorher', $sicherung);
    // Hat die Redaktion Bildangaben des Poolfotos bewusst geändert, gilt das Bild als ihres: kein automatischer Tausch mehr.
    elseif ($poolBild && $bildGeaendert && function_exists('ma_bildpool_merkmal_loeschen')) ma_bildpool_merkmal_loeschen((int) $post_id);
}

function ma_publication_gate(array $data,array $postarr): array {
    // Auch eine geplante Veröffentlichung (future) braucht alle Freigaben.
    if (($data['post_type']??'')!=='post' || !in_array(($data['post_status']??''),['publish','future'],true)) return $data;
    $post_id=(int)($postarr['ID']??0);
    if(!$post_id) return $data;

    $required=['ma_source_verified','ma_date_verified','ma_place_verified','ma_human_reviewed'];
    foreach($required as $key){
        $submitted=isset($_POST[$key]);
        $stored=get_post_meta($post_id,$key,true)==='1';
        if(!$submitted && !$stored){$data['post_status']='draft';return $data;}
    }

    if(has_post_thumbnail($post_id)){
        $rights_submitted=isset($_POST['ma_image_rights_verified']);
        $rights_stored=get_post_meta($post_id,'ma_image_rights_verified',true)==='1';
        if(!$rights_submitted && !$rights_stored) $data['post_status']='draft';
    }
    return $data;
}
