<?php
if (!defined('ABSPATH')) { exit; }

function ma_register_admin_hooks(): void {
    add_action('admin_menu', function () {
        add_menu_page('Merzenich Aktuell','Merzenich Aktuell','manage_options','merzenich-aktuell','ma_dashboard','dashicons-admin-site-alt3',3);
        add_submenu_page('merzenich-aktuell','Wetter','Wetter','manage_options','ma-weather','ma_weather_settings_page');
        // Werbeplätze stehen beim Menü „Werbung“ (Werbemittel), nicht doppelt unter Merzenich Aktuell.
        add_submenu_page('edit.php?post_type=ma_ad','Werbeplätze','Werbeplätze','manage_options','ma-ads','ma_ads_settings_page');
        // Sport und Abgleich auch für Redakteure (1.26.2); Einstellungen bleiben Administratoren vorbehalten.
        add_submenu_page('merzenich-aktuell','Sport','Sport','edit_others_posts','ma-sport','ma_sport_settings_page');
    });
}

function ma_dashboard(): void {
    // Aufmacher wie auf der Startseite (Layout-Karte, fest oder automatisch); die alte 7-Tage-Regel nur als Rückfall.
    $belegung = (array) apply_filters('ma_layout_belegung', [], 'startseite');
    $hero = !empty($belegung['aufmacher']['post']) ? get_post((int) $belegung['aufmacher']['post']) : (function_exists('ma_theme_hero_post') ? ma_theme_hero_post() : null);
    if (!$hero) {
        $latest = new WP_Query(['post_type'=>'post','post_status'=>'publish','posts_per_page'=>1,'orderby'=>'date','order'=>'DESC']);
        $hero = $latest->posts[0] ?? null;
    }
    $old = $hero ? (time() - get_post_time('U', true, $hero)) > 7 * DAY_IN_SECONDS : false;
    $events = ma_upcoming_events(6);
    $weather = ma_get_weather();
    $pending_comments = (int)get_comments(['status'=>'hold','count'=>true]);
    $partner_q = new WP_Query([
        'post_type'=>['post','ma_property','ma_business','ma_tip','ma_ad'],
        'post_status'=>'pending','posts_per_page'=>1,'fields'=>'ids',
        'meta_query'=>[['key'=>'_ma_partner_submission','value'=>'1']],
    ]);
    $pending_partner = (int)$partner_q->found_posts;

    // Redaktions-E-Mail (1.21.0): Empfänger für Formulare, Partner-Anträge und Partner-Hinweise; leer = Admin-E-Mail.
    if (isset($_POST['ma_redaktion_mail_speichern']) && check_admin_referer('ma_redaktion_mail')) {
        $mail = sanitize_email(wp_unslash((string)($_POST['ma_editorial_email'] ?? '')));
        if ($mail === '') { delete_option('ma_editorial_email'); echo '<div class="notice notice-success"><p>Redaktions-E-Mail entfernt; es gilt die Admin-E-Mail.</p></div>'; }
        elseif (is_email($mail)) { update_option('ma_editorial_email', $mail, false); echo '<div class="notice notice-success"><p>Redaktions-E-Mail gespeichert.</p></div>'; }
        else echo '<div class="notice notice-error"><p>Das ist keine gültige E-Mail-Adresse.</p></div>';
    }
    $abgleich = (string)get_option('ma_abgleich_geprueft', '');
    echo '<div class="wrap"><h1>Merzenich Aktuell – Aktualitätscheck</h1><table class="widefat striped"><tbody>';
    echo '<tr><th>Letzter Abgleich</th><td>'.esc_html($abgleich !== '' ? mysql2date('d.m.Y, H:i', $abgleich).' Uhr' : 'noch nicht gelaufen').'</td></tr>';
    echo '<tr><th>Aktueller Aufmacher</th><td>'.($hero ? esc_html(get_the_title($hero)) : 'Kein veröffentlichter Beitrag').' · <a href="'.esc_url(admin_url('admin.php?page=ma-startseite')).'">Startseite anordnen</a></td></tr>';
    echo '<tr><th>Aufmacher älter als 7 Tage</th><td>'.($old?'<strong style="color:#b71920">JA – prüfen</strong>':'Nein').'</td></tr>';
    echo '<tr><th>Kommende Events</th><td>'.count($events).'</td></tr>';
    echo '<tr><th>Wetter</th><td>'.($weather?'OK · '.esc_html($weather['updated_at']??''):'Kein valider Datenstand – Frontend blendet Modul aus').'</td></tr>';
    echo '<tr><th>Beiträge ohne Bild</th><td>'.esc_html((string)ma_count_posts_without_thumbnail()).'</td></tr>';
    echo '<tr><th>Ungeprüfte Entwürfe</th><td>'.esc_html((string)ma_count_unreviewed()).' · <a href="'.esc_url(admin_url('admin.php?page=ma-freigaben')).'">Freigaben</a></td></tr>';
    echo '<tr><th>Partner-Einreichungen</th><td><strong>'.esc_html((string)$pending_partner).'</strong> · <a href="'.esc_url(admin_url('admin.php?page=ma-freigaben')).'">prüfen</a></td></tr>';
    // Mailversand (1.23.0): ohne Postfach landen Formular-Mails oft im Spam.
    if (function_exists('ma_mail_status_text')) { $m = ma_mail_einstellungen(); echo '<tr><th>Mailversand</th><td>'.(ma_mail_bereit($m) ? '' : '<strong style="color:#b71920">').esc_html(ma_mail_status_text($m)).(ma_mail_bereit($m) ? '' : '</strong>').' · <a href="'.esc_url(admin_url('admin.php?page=ma-mailversand')).'">einrichten</a></td></tr>'; }
    echo '<tr><th>Kommentare zur Freigabe</th><td><strong>'.esc_html((string)$pending_comments).'</strong> · <a href="'.esc_url(admin_url('edit-comments.php?page=ma-kommentar-freigabe')).'">Sammelfreigabe</a></td></tr>';
    echo '</tbody></table>';
    echo '<h2>Redaktions-E-Mail</h2><form method="post">';
    wp_nonce_field('ma_redaktion_mail');
    echo '<p>An diese Adresse gehen Einsendungen der Formulare, Partner-Anträge und Hinweise auf Beiträge von Partnern. Leer gilt die Admin-E-Mail (<code>'.esc_html((string)get_option('admin_email')).'</code>). Alles landet zusätzlich im <a href="'.esc_url(admin_url('edit.php?post_type=ma_eingang')).'">Eingang</a>.</p>';
    echo '<p><input type="email" class="regular-text" name="ma_editorial_email" value="'.esc_attr((string)get_option('ma_editorial_email', '')).'" placeholder="redaktion@merzenich-aktuell.de"> <button class="button button-primary" name="ma_redaktion_mail_speichern" value="1">Speichern</button></p></form></div>';
}

function ma_count_posts_without_thumbnail(): int {
    global $wpdb;
    return (int)$wpdb->get_var("SELECT COUNT(p.ID) FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} m ON p.ID=m.post_id AND m.meta_key='_thumbnail_id' WHERE p.post_type='post' AND p.post_status='publish' AND m.meta_id IS NULL");
}

function ma_count_unreviewed(): int {
    $q = new WP_Query([
        'post_type'=>'post',
        'post_status'=>'draft',
        'posts_per_page'=>1,
        'fields'=>'ids',
        'meta_query'=>[
            'relation'=>'OR',
            ['key'=>'ma_human_reviewed','compare'=>'NOT EXISTS'],
            ['key'=>'ma_human_reviewed','value'=>'1','compare'=>'!='],
        ],
    ]);
    return (int)$q->found_posts;
}

function ma_weather_settings_page(): void {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['ma_weather_save']) && check_admin_referer('ma_weather_save')) {
        update_option('ma_weather_settings',[
            'enabled'=>isset($_POST['enabled'])?1:0,
            'latitude'=>sanitize_text_field(wp_unslash($_POST['latitude']??'')),
            'longitude'=>sanitize_text_field(wp_unslash($_POST['longitude']??'')),
            'cache_minutes'=>max(10,min(30,(int)($_POST['cache_minutes']??10))),
        ]);
        delete_transient('ma_weather_current_v2');
        echo '<div class="notice notice-success"><p>Gespeichert.</p></div>';
    }
    $s=wp_parse_args((array)get_option('ma_weather_settings',[]),['enabled'=>1,'latitude'=>'50.8317','longitude'=>'6.5361','cache_minutes'=>10]);
    echo '<div class="wrap"><h1>Wetter</h1><form method="post">'; wp_nonce_field('ma_weather_save');
    echo '<p><label><input type="checkbox" name="enabled" '.checked($s['enabled'],1,false).'> Wetter aktiv</label></p><p>Breite <input name="latitude" value="'.esc_attr($s['latitude']).'"> Länge <input name="longitude" value="'.esc_attr($s['longitude']).'"></p><p>Cache (10–30 Min.) <input type="number" min="10" max="30" name="cache_minutes" value="'.esc_attr($s['cache_minutes']).'"></p><p><button class="button button-primary" name="ma_weather_save">Speichern</button></p></form></div>';
}

function ma_ads_settings_page(): void {
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['ma_ads_save']) && check_admin_referer('ma_ads_save')) {
        update_option('ma_ads_enabled',isset($_POST['global'])?1:0);
        $slots=[];
        foreach(ma_ad_slots() as $s) $slots[$s]=isset($_POST['slot'][$s])?1:0;
        update_option('ma_ad_slots',$slots);
        echo '<div class="notice notice-success"><p>Gespeichert.</p></div>';
    }
    $enabled=(int)get_option('ma_ads_enabled',0);
    $slots=(array)get_option('ma_ad_slots',[]);
    echo '<div class="wrap"><h1>Werbeplätze</h1><p>Werbemittel unter <strong>Werbung → Werbemittel hinzufügen</strong> anlegen (Titel, Platz, Laufzeit, Bild auf einem Bildschirm). Eine Anzeige läuft, wenn sie veröffentlicht ist, „Schaltung aktiv“ gesetzt ist, Werbung global an ist und ihr Platz hier eingeschaltet ist. Solange auf einem Platz keine echte Anzeige läuft, zeigt die Seite dort die gekennzeichnete Musteranzeige.</p><form method="post">';
    wp_nonce_field('ma_ads_save');
    echo '<p><label><input type="checkbox" name="global" '.checked($enabled,1,false).'> Werbung global AN</label></p>';
    echo '<p class="description">Mehrere laufende Anzeigen auf demselben Platz wechseln sich ab (Rotation). Die Werbebänder 1 bis 6 stehen auf der Startseite zwischen den Meldungsblöcken. Kontingente der Unternehmen: am jeweiligen Benutzerprofil.</p>';
    foreach(ma_ad_slots() as $s) echo '<p><label><input type="checkbox" name="slot['.esc_attr($s).']" '.checked($slots[$s]??0,1,false).'> '.esc_html(ma_ad_slot_label($s)).' <code>'.esc_html($s).'</code></label></p>';
    echo '<p><button class="button button-primary" name="ma_ads_save">Speichern</button></p></form></div>';
}

function ma_sport_match_from_request(string $prefix, bool $with_score=false): array {
    $home = sanitize_text_field(wp_unslash($_POST[$prefix.'_home'] ?? ''));
    $away = sanitize_text_field(wp_unslash($_POST[$prefix.'_away'] ?? ''));
    $date = sanitize_text_field(wp_unslash($_POST[$prefix.'_date'] ?? ''));
    $score = $with_score ? sanitize_text_field(wp_unslash($_POST[$prefix.'_score'] ?? '')) : '';
    $report = $with_score ? esc_url_raw(wp_unslash($_POST[$prefix.'_report'] ?? '')) : '';

    if ($home === '' && $away === '' && $date === '' && $score === '') return [];

    $match = ['home'=>$home,'away'=>$away,'date'=>$date];
    if ($with_score) $match['score']=$score;
    if ($report !== '') $match['report']=$report;
    return $match;
}

function ma_sport_table_from_request(): array {
    $teams = isset($_POST['table_team']) && is_array($_POST['table_team']) ? $_POST['table_team'] : [];
    $ranks = isset($_POST['table_rank']) && is_array($_POST['table_rank']) ? $_POST['table_rank'] : [];
    $played = isset($_POST['table_played']) && is_array($_POST['table_played']) ? $_POST['table_played'] : [];
    $points = isset($_POST['table_points']) && is_array($_POST['table_points']) ? $_POST['table_points'] : [];
    $goals = isset($_POST['table_goals']) && is_array($_POST['table_goals']) ? $_POST['table_goals'] : [];
    $spalte = static fn(string $k): array => isset($_POST[$k]) && is_array($_POST[$k]) ? $_POST[$k] : [];
    [$wins, $draws, $losses] = [$spalte('table_wins'), $spalte('table_draws'), $spalte('table_losses')];
    $table = [];

    for ($i=0; $i<16; $i++) {
        $team = sanitize_text_field(wp_unslash($teams[$i] ?? ''));
        if ($team === '') continue;
        $table[] = [
            'rank'=>sanitize_text_field(wp_unslash($ranks[$i] ?? '')),
            'team'=>$team,
            'played'=>sanitize_text_field(wp_unslash($played[$i] ?? '')),
            'wins'=>sanitize_text_field(wp_unslash($wins[$i] ?? '')),
            'draws'=>sanitize_text_field(wp_unslash($draws[$i] ?? '')),
            'losses'=>sanitize_text_field(wp_unslash($losses[$i] ?? '')),
            'points'=>sanitize_text_field(wp_unslash($points[$i] ?? '')),
            'goals'=>sanitize_text_field(wp_unslash($goals[$i] ?? '')),
        ];
    }
    return $table;
}

function ma_sport_settings_page(): void {
    if (!current_user_can('edit_others_posts')) return;

    if (isset($_POST['ma_sport_import']) && check_admin_referer('ma_sport_save')) {
        $ergebnis = ma_sport_import_from_json((string)wp_unslash($_POST['sport_json'] ?? ''));
        if (is_wp_error($ergebnis)) {
            echo '<div class="notice notice-error"><p>Import fehlgeschlagen: '.esc_html($ergebnis->get_error_message()).'</p></div>';
        } else {
            update_option('ma_sport_data',$ergebnis);
            echo '<div class="notice notice-success"><p>Datenstand aus JSON übernommen ('.esc_html($ergebnis['checked_at']).'). Unten prüfen und bei Bedarf korrigieren.</p></div>';
        }
    }

    if (isset($_POST['ma_sport_save']) && check_admin_referer('ma_sport_save')) {
        $data = [
            'checked_at'=>sanitize_text_field(wp_unslash($_POST['checked_at'] ?? '')),
            'source_url'=>esc_url_raw(wp_unslash($_POST['source_url'] ?? '')),
            'last_match'=>ma_sport_match_from_request('last_match', true),
            'pending_match'=>ma_sport_match_from_request('pending_match', false),
            'next_match'=>ma_sport_match_from_request('next_match', false),
            'table'=>ma_sport_table_from_request(),
        ];
        update_option('ma_sport_data',$data);
        echo '<div class="notice notice-success"><p>Sportdaten gespeichert.</p></div>';
    }

    $d = ma_sport_data();
    $last = (array)($d['last_match'] ?? []);
    $pending = (array)($d['pending_match'] ?? []);
    $next = (array)($d['next_match'] ?? []);
    $table = array_values((array)($d['table'] ?? []));

    echo '<div class="wrap"><h1>Sport</h1><p>Ergebnis, offenes Spiel, nächstes Spiel und Tabelle des SC Merzenich werden hier gepflegt. Was hier steht, zeigen die Sportseite und das Sportmodul. Nach jedem Spieltag kurz eintragen, die Quelle ist <a href="https://www.fussball.de/" target="_blank" rel="noopener">FUSSBALL.DE</a>.</p>';
    $offen = ma_sport_ueberfaellig();
    if ($offen !== '') echo '<div class="notice notice-warning inline"><p>' . esc_html($offen) . '</p></div>';
    echo '<form method="post">';
    wp_nonce_field('ma_sport_save');

    echo '<h2>Aus JSON übernehmen</h2><p>Ein Datenpaket (JSON) von HK Growth Operator hier einfügen. Ergebnis, offenes Spiel, nächstes Spiel und Tabelle werden daraus gefüllt; ein unbestätigtes Ergebnis landet als offenes Spiel.</p>';
    echo '<textarea name="sport_json" rows="6" style="width:100%;max-width:900px;font-family:monospace" placeholder=\'{"generated":"…","sourceUrl":"…","lastMatch":{…},"nextMatch":{…},"table":[…]}\'></textarea>';
    echo '<p><button class="button" name="ma_sport_import">Aus JSON übernehmen</button></p>';

    echo '<h2>Gemeinsamer Datenstand</h2><table class="form-table"><tr><th><label for="checked_at">Datenstand</label></th><td><input class="regular-text" id="checked_at" name="checked_at" value="'.esc_attr((string)($d['checked_at'] ?? '')).'" placeholder="16.09.2026 · 11:30 Uhr"></td></tr><tr><th><label for="source_url">Quelle</label></th><td><input class="regular-text" type="url" id="source_url" name="source_url" value="'.esc_attr((string)($d['source_url'] ?? '')).'" placeholder="https://..."></td></tr></table>';

    $sections = [
        'last_match'=>['Letztes bestätigtes Spiel',$last,true],
        'pending_match'=>['Noch nicht bestätigtes Spiel',$pending,false],
        'next_match'=>['Nächstes Spiel',$next,false],
    ];

    foreach ($sections as $prefix=>$config) {
        [$label,$match,$with_score] = $config;
        echo '<h2>'.esc_html($label).'</h2><table class="form-table">';
        echo '<tr><th>Heim</th><td><input class="regular-text" name="'.esc_attr($prefix).'_home" value="'.esc_attr((string)($match['home'] ?? '')).'"></td></tr>';
        if ($with_score) echo '<tr><th>Ergebnis</th><td><input class="regular-text" name="'.esc_attr($prefix).'_score" value="'.esc_attr((string)($match['score'] ?? '')).'" placeholder="2 : 1"></td></tr>';
        echo '<tr><th>Gast</th><td><input class="regular-text" name="'.esc_attr($prefix).'_away" value="'.esc_attr((string)($match['away'] ?? '')).'"></td></tr>';
        echo '<tr><th>Datum / Uhrzeit</th><td><input class="regular-text" name="'.esc_attr($prefix).'_date" value="'.esc_attr((string)($match['date'] ?? '')).'" placeholder="18.09.2026 · 19:30 Uhr"></td></tr>';
        if ($with_score) echo '<tr><th>Spielbericht (Link)</th><td><input class="regular-text" type="url" name="'.esc_attr($prefix).'_report" value="'.esc_attr((string)($match['report'] ?? '')).'" placeholder="https://www.fussball.de/…"></td></tr>';
        echo '</table>';
    }

    echo '<h2>Tabelle</h2><p>Nur Zeilen mit Mannschaft werden gespeichert.</p><div style="overflow:auto"><table class="widefat striped" style="max-width:900px"><thead><tr><th style="width:70px">Pl.</th><th>Mannschaft</th><th style="width:70px">Sp.</th><th style="width:60px">S</th><th style="width:60px">U</th><th style="width:60px">N</th><th style="width:70px">Pkt.</th><th style="width:110px">Tore</th></tr></thead><tbody>';
    for ($i=0; $i<16; $i++) {
        $row = (array)($table[$i] ?? []);
        echo '<tr>';
        echo '<td><input style="width:55px" name="table_rank['.$i.']" value="'.esc_attr((string)($row['rank'] ?? '')).'"></td>';
        echo '<td><input style="width:100%" name="table_team['.$i.']" value="'.esc_attr((string)($row['team'] ?? '')).'"></td>';
        echo '<td><input style="width:55px" name="table_played['.$i.']" value="'.esc_attr((string)($row['played'] ?? '')).'"></td>';
        foreach (['wins', 'draws', 'losses'] as $k) echo '<td><input style="width:45px" name="table_'.$k.'['.$i.']" value="'.esc_attr((string)($row[$k] ?? '')).'"></td>';
        echo '<td><input style="width:65px" name="table_points['.$i.']" value="'.esc_attr((string)($row['points'] ?? '')).'"></td>';
        echo '<td><input style="width:100px" name="table_goals['.$i.']" value="'.esc_attr((string)($row['goals'] ?? '')).'" placeholder="12:8"></td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';

    echo '<p style="margin-top:20px"><button class="button button-primary" name="ma_sport_save">Sportdaten speichern</button></p></form></div>';
}
