<?php
/**
 * Firmen-Entwürfe (16.10.2026, Auftrag Betreiber; seit 24.10.2026 Almera Clean,
 * KBS Management, Merzlicht und AJ Sports statt Bäckerei Wirtz, Hasberg und
 * Porschen Media): Unternehmen aus data/firmen-entwuerfe.json als Entwurf im
 * vorhandenen System.
 *
 * - Unternehmensprofil (ma_business) mit Stammdaten, Quelle und Stand. Ohne
 *   Einwilligung bleibt es Entwurf (Sperre in business.php); die Redaktion setzt
 *   den Haken erst, wenn das Unternehmen zugestimmt hat. Jedes Profil aus der
 *   Datei ist ein Unternehmenskanal (ma_business_kanal), auch ohne Beitrag.
 *   „nur_name“: Profil nur mit dem Namen (keine Adresse, kein Logo, kein
 *   Beitrag), bis der Betreiber Angaben schickt; nichts wird dazu erfunden.
 * - Ein Werbebeitrag je Unternehmen, gesponsert und verknüpft mit dem Profil
 *   (ma_business_id), nicht auf der Startseite, als Entwurf. Kennzeichnung nach
 *   „art“: test (kostenfreier Testeintrag, testeintrag.php), anzeige oder
 *   eigen (in eigener Sache, für die Herausgeberin KBS).
 * - Logos: Quelle und Rechtestand stehen am Profil (ma_business_logo_quelle,
 *   ma_business_logo_rechte = offen, bis die Logo-Freigabe eingetragen ist);
 *   bis dahin zeigt die Seite das Kürzel der Firma.
 * - Werbebanner („anzeigen“ mit Foto und Video aus data/banner/): entstehen mit der
 *   Einwilligung als laufende Anzeigen (ma_ad) auf allen sichtbaren Werbeplätzen
 *   (ma_firmen_banner_plaetze()), mit Knopf zum Firmenkanal, ohne Ende.
 *
 * Merzenich Aktuell → Firmen-Entwürfe legt fehlende Entwürfe an. Vorhandene Profile
 * und Beiträge (auch im Papierkorb) werden nie überschrieben oder doppelt angelegt.
 *
 * Zusage eintragen (20.10.2026): je Betrieb Einwilligung und Logo-Freigabe getrennt,
 * jeweils mit Nachweis (wer, wann, woher). Mit der Logo-Freigabe kommt das Logo
 * aus data/logos/ einmal in die Mediathek und wird Beitragsbild des Profils; mit
 * der Einwilligung wird das Profil veröffentlicht (die Sperre in business.php
 * bleibt die Prüfung). Den Werbebeitrag gibt die Redaktion danach wie jeden
 * Beitrag in den Freigaben frei: Er liegt dort nach der Einwilligung zur Prüfung
 * (Prüfhäkchen, Sperre in freigabe.php). Zusatzbeiträge bleiben Entwurf.
 *
 * Werbung (28.10.2026 abends): für alle fünf je zwei Motive („anzeigen“: Foto, „zeile“
 * oben, Überschrift, Satz, Knopf, Video-Schleife aus docs/anzeigen/bauen.mjs).
 * „Fehlende Entwürfe anlegen“ und „Zusage eintragen“ legen neue Motive an und ziehen
 * geänderte nach, außer eine Anzeige wurde im Backend bearbeitet.
 * „werbung.max“ ist das Kontingent eines Zugangs (5 für alle); es wird beim
 * Verknüpfen eines Zugangs mit dem Profil gesetzt.
 *
 * Firma zurückziehen (24.10.2026): Profil, Beiträge und Werbebanner eines
 * früheren Betriebs („frueher“ in der Datei) werden Entwurf; nichts wird
 * gelöscht, Logos bleiben in der Mediathek.
 */
if (!defined('ABSPATH')) { exit; }

function ma_firmen_entwuerfe_daten(): array {
    $d = json_decode((string) @file_get_contents(MA_CORE_PATH . 'data/firmen-entwuerfe.json'), true);
    return is_array($d) ? $d : ['firmen' => []];
}

/** Kennzeichnung des Werbebeitrags: test (Standard), anzeige oder eigen. */
function ma_firmen_art(array $f): string {
    $a = (string) ($f['art'] ?? 'test');
    return in_array($a, ['test', 'anzeige', 'eigen'], true) ? $a : 'test';
}

/**
 * Werbeplätze der Banner: alle Plätze, die die Seite zeigt (sechs Startseiten-Bänder,
 * Servicespalte und Bühne der Startseite, unter Artikeln, Sport- und Unternehmensspalte).
 * Wo eine echte Anzeige läuft, verschwindet die Musteranzeige.
 */
function ma_firmen_banner_plaetze(): array {
    return ['homepage_band_1', 'homepage_band_2', 'homepage_band_3', 'homepage_band_4', 'homepage_band_5', 'homepage_band_6', 'homepage_sidebar_top', 'homepage_buehne', 'article_inline_1', 'sport_sidebar', 'business_sidebar'];
}

/** Beitragstext: Absätze (einfaches HTML aus der Datei) und der Knopf zur Website des Unternehmens. */
function ma_firmen_beitrag_html(array $b): string {
    $h = '';
    foreach ((array) ($b['absaetze'] ?? []) as $a) $h .= '<p>' . wp_kses((string) $a, ['strong' => [], 'em' => []]) . "</p>\n";
    $k = (array) ($b['knopf'] ?? []);
    if (!empty($k['ziel']) && !empty($k['text'])) $h .= '<p class="cta-row"><a class="btn" href="' . esc_url((string) $k['ziel']) . '" target="_blank" rel="noopener sponsored">' . esc_html((string) $k['text']) . ' ↗</a></p>' . "\n";
    return $h;
}

/** Vorhandener Inhalt mit diesem Slug in jedem Status (auch In Prüfung, Abgelehnt, Archiv, Papierkorb), sonst 0. */
function ma_firmen_vorhanden(string $typ, string $slug): int {
    // Ohne Slug nie suchen: WordPress ignoriert ein leeres „name“ und liefert sonst den neuesten Inhalt.
    if ($slug === '') return 0;
    $q = get_posts(['post_type' => $typ, 'name' => $slug, 'post_status' => array_values(array_diff(get_post_stati(), ['auto-draft', 'inherit'])), 'posts_per_page' => 1, 'fields' => 'ids']);
    if ($q) return (int) $q[0];
    // Im Papierkorb trägt der Slug den Zusatz __trashed.
    $q = get_posts(['post_type' => $typ, 'name' => $slug . '__trashed', 'post_status' => 'trash', 'posts_per_page' => 1, 'fields' => 'ids']);
    return $q ? (int) $q[0] : 0;
}

/** Legt fehlende Entwürfe an. Ergebnis: Zeilen für die Rückmeldung. */
function ma_firmen_entwuerfe_anlegen(): array {
    $daten = ma_firmen_entwuerfe_daten();
    $stand = (string) ($daten['stand'] ?? '');
    $log = [];
    foreach ((array) ($daten['firmen'] ?? []) as $f) {
        $p = (array) ($f['profil'] ?? []); $b = (array) ($f['beitrag'] ?? []);
        if (empty($p['slug']) || empty($p['titel'])) continue;
        $pid = ma_firmen_vorhanden('ma_business', (string) $p['slug']);
        if (!$pid) {
            $logo = (array) ($p['logo'] ?? []);
            $r = wp_insert_post(wp_slash([
                'post_type' => 'ma_business', 'post_status' => 'draft', 'post_title' => (string) $p['titel'], 'post_name' => (string) $p['slug'],
                'post_excerpt' => (string) ($p['kurz'] ?? ''), 'post_content' => '<p>' . esc_html((string) ($p['text'] ?? '')) . '</p>',
                'meta_input' => array_filter([
                    'ma_business_branche' => (string) ($p['branche'] ?? ''), 'ma_business_adresse' => (string) ($p['adresse'] ?? ''),
                    'ma_business_telefon' => (string) ($p['telefon'] ?? ''), 'ma_business_email' => (string) ($p['email'] ?? ''),
                    'ma_business_website' => (string) ($p['website'] ?? ''), 'ma_business_oeffnungszeiten' => (string) ($p['oeffnungszeiten'] ?? ''),
                    'ma_business_ortsteil' => (string) ($p['ortsteil'] ?? ''), 'ma_business_quelle' => (string) ($p['quelle'] ?? ''), 'ma_business_stand' => $stand,
                    'ma_business_firmenname' => (string) ($p['firmenname'] ?? ''),
                    'ma_business_logo_quelle' => (string) ($logo['quelle'] ?? ''), 'ma_business_logo_rechte' => $logo ? (string) ($logo['rechte'] ?? 'offen') : '', 'ma_business_logo_alt' => (string) ($logo['alt'] ?? ''),
                    'ma_business_karte_knopf' => (string) ($p['karte']['knopf'] ?? ''), 'ma_business_karte_ziel' => (string) ($p['karte']['ziel'] ?? ''),
                    'ma_business_ort' => (string) ($p['ort'] ?? ''), 'ma_business_kanal' => '1',
                    'ma_business_nur_name' => !empty($f['nur_name']) ? '1' : '', 'ma_business_herausgeberin' => !empty($f['herausgeberin']) ? '1' : '',
                ], fn($v) => $v !== ''),
            ]), true);
            if (is_wp_error($r) || !$r) { $log[] = $p['titel'] . ': Profil nicht angelegt' . (is_wp_error($r) ? ' (' . $r->get_error_message() . ')' : ''); continue; }
            $pid = (int) $r;
            $log[] = $p['titel'] . ': Profil als Entwurf angelegt';
            if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen($pid, 'Entwurf angelegt', 'Aus data/firmen-entwuerfe.json (Stand ' . $stand . '). Veröffentlichung erst mit Einwilligung des Unternehmens' . (!empty($p['logo']) ? '; Logo-Rechte offen.' : '.'));
        } else $log[] = $p['titel'] . ': Profil schon vorhanden (' . get_post_status($pid) . ')';

        // Werbebeitrag und (20.10.2026) die Zusatzbeiträge, alle als Entwurf.
        $art = ma_firmen_art($f);
        foreach (array_merge([$b], (array) ($f['zusatz'] ?? [])) as $nr => $b) {
            if (empty($b['slug']) || empty($b['titel'])) continue;
            if ($bid = ma_firmen_vorhanden('post', (string) $b['slug'])) { $log[] = $p['titel'] . ': Beitrag schon vorhanden (' . get_post_status($bid) . ')'; continue; }
            $kat = get_category_by_slug('wirtschaft');
            $r = wp_insert_post(wp_slash([
                'post_type' => 'post', 'post_status' => 'draft', 'post_title' => (string) $b['titel'], 'post_name' => (string) $b['slug'],
                'post_excerpt' => (string) ($b['anriss'] ?? ''), 'post_content' => ma_firmen_beitrag_html($b),
                'post_category' => $kat ? [(int) $kat->term_id] : [],
                'meta_input' => [
                    'ma_gesponsert' => '1', 'ma_gesponsert_art' => $art, 'ma_gesponsert_von' => (string) ($p['firmenname'] ?? '') ?: (string) $p['titel'],
                    'ma_business_id' => (string) $pid, 'ma_seo_titel' => (string) ($b['seo_titel'] ?? ''), 'ma_seo_beschreibung' => (string) ($b['seo_beschreibung'] ?? ''),
                    'ma_source_url' => (string) ($b['quelle'] ?? '') ?: (string) ($p['website'] ?? ''), 'ma_source_publisher' => (string) ($p['firmenname'] ?? '') ?: (string) $p['titel'],
                    'ma_startseite_freigabe' => 'nein',
                ],
            ]), true);
            if (is_wp_error($r) || !$r) { $log[] = $p['titel'] . ': Beitrag nicht angelegt' . (is_wp_error($r) ? ' (' . $r->get_error_message() . ')' : ''); continue; }
            $bid = (int) $r;
            if (!empty($p['ortsteil']) && taxonomy_exists('ma_location')) wp_set_object_terms($bid, (string) $p['ortsteil'], 'ma_location', false);
            $wie = ['test' => 'kostenfreier Testeintrag', 'anzeige' => 'Anzeige', 'eigen' => 'Anzeige in eigener Sache'][$art];
            $log[] = $p['titel'] . ': Beitrag als Entwurf angelegt (' . $wie . ')';
            if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen($bid, 'Entwurf angelegt', 'Werbebeitrag (' . $wie . ') aus data/firmen-entwuerfe.json. Erst veröffentlichen, wenn das Unternehmen Text und Schaltung bestätigt hat.');
        }
        // Kontingent der schon verknüpften Zugänge nachziehen (z. B. 0 → 5 seit 1.36.0).
        if (function_exists('get_users')) foreach (get_users(['meta_key' => 'ma_business_id', 'meta_value' => (string) $pid, 'fields' => 'ID']) as $uid)
            if (($k = ma_firmen_kontingent_setzen((int) $uid, $pid, true)) !== null) $log[] = $p['titel'] . ': Werbekontingent des Zugangs auf ' . $k . ' gesetzt.';
        // Werbebanner: neue Motive anlegen, geänderte nachziehen, nur mit wirksamer Einwilligung (veröffentlichtes Profil).
        if (get_post_status($pid) === 'publish' && (string) get_post_meta($pid, 'ma_business_consent', true) === '1') $log = array_merge($log, ma_firmen_banner_anlegen($f, $pid));
    }
    return $log;
}

/** Daten eines Betriebs aus der Datei nach Profil-Slug, sonst null. */
function ma_firmen_eintrag(string $slug): ?array {
    foreach ((array) (ma_firmen_entwuerfe_daten()['firmen'] ?? []) as $f) if ((string) ($f['profil']['slug'] ?? '') === $slug) return $f;
    return null;
}

/** Plugin-Daten im Repository (Stand von main), Quelle für Dateien, die nicht im Paket liegen. */
if (!defined('MA_FIRMEN_REPO_DATEN')) define('MA_FIRMEN_REPO_DATEN', 'https://raw.githubusercontent.com/HKGrowthOperator/Merzenich-Aktuell/main/wordpress/plugin/merzenich-aktuell-core/data/');

/**
 * Pfad einer Datei aus data/<ordner>/ (28.10.2026, Plugin 1.36.1): zuerst im Plugin,
 * sonst die einmal aus dem Repository geholte Kopie unter uploads/ma-firmen/. Die
 * Anzeigenvideos liegen nicht im Paket, weil der Server Uploads über 8 MB ablehnt.
 * Die Kopie wird nach einem Tag neu geholt (neu gebaute Videos gleichen Namens);
 * antwortet GitHub nicht, gilt die letzte Kopie. Leer, wenn es die Datei nirgends gibt.
 */
function ma_firmen_datei(string $ordner, string $datei): string {
    $datei = basename($datei);
    if ($datei === '' || !preg_match('/^[\w.-]+\.(jpe?g|png|webp|mp4|webm)$/i', $datei) || !preg_match('/^\w+$/', $ordner)) return '';
    $pfad = MA_CORE_PATH . 'data/' . $ordner . '/' . $datei;
    if (is_file($pfad)) return $pfad;
    $kopie = trailingslashit((string) wp_upload_dir(null, false)['basedir']) . 'ma-firmen/' . $ordner . '/' . $datei;
    clearstatcache(true, $kopie);
    if (is_file($kopie) && filemtime($kopie) > time() - DAY_IN_SECONDS) return $kopie;
    $sperre = 'ma_firmen_fehlt_' . md5($ordner . '/' . $datei);
    if (get_transient($sperre)) return is_file($kopie) ? $kopie : '';
    $r = wp_remote_get(MA_FIRMEN_REPO_DATEN . $ordner . '/' . rawurlencode($datei), ['timeout' => 30]);
    $body = !is_wp_error($r) && (int) wp_remote_retrieve_response_code($r) === 200 ? (string) wp_remote_retrieve_body($r) : '';
    if ($body === '' || strlen($body) > 8 * MB_IN_BYTES || !wp_mkdir_p(dirname($kopie)) || file_put_contents($kopie, $body) === false) {
        set_transient($sperre, 1, HOUR_IN_SECONDS);
        return is_file($kopie) ? $kopie : '';
    }
    return $kopie;
}

/**
 * Datei aus data/<ordner>/<datei> (Plugin, sonst Repository, siehe ma_firmen_datei)
 * einmal in die Mediathek übernehmen; ein zweiter Aufruf findet das Medium über
 * $merkmal wieder. Gibt die Medien-ID zurück, 0 bei Fehler ($fehler nennt den Grund).
 */
function ma_firmen_medium(string $ordner, string $datei, string $merkmal, int $pid, string $alt, string $credit, string $quelle, string &$fehler = '', bool $inhalt = false): int {
    $datei = basename($datei);
    $pfad = $datei !== '' ? ma_firmen_datei($ordner, $datei) : '';
    if ($pfad === '') { $fehler = 'Datei fehlt im Plugin und im Repository'; return 0; }
    // $inhalt: Merkmal mit Prüfsumme der Datei, damit eine neu gebaute Datei gleichen Namens neu übernommen wird.
    $wert = $inhalt ? $datei . '#' . substr((string) md5_file($pfad), 0, 12) : $datei;
    $da = get_posts(['post_type' => 'attachment', 'post_status' => 'inherit', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => $merkmal, 'meta_value' => $wert]);
    if ($da) return (int) $da[0];
    if (!function_exists('media_handle_sideload')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }
    $tmp = wp_tempnam($datei);
    if (!$tmp || !copy($pfad, $tmp)) { $fehler = 'Datei nicht lesbar'; return 0; }
    $id = media_handle_sideload(['name' => $datei, 'tmp_name' => $tmp], $pid, $alt);
    if (is_wp_error($id)) { @unlink($tmp); $fehler = $id->get_error_message(); return 0; }
    $id = (int) $id;
    update_post_meta($id, $merkmal, $wert);
    update_post_meta($id, '_wp_attachment_image_alt', $alt);
    update_post_meta($id, 'ma_image_credit', $credit);
    if ($quelle !== '') update_post_meta($id, 'ma_image_original_url', $quelle);
    update_post_meta($id, 'ma_image_rights_verified', '1');
    return $id;
}

/** Logo aus data/logos/ (Medien-ID, 0 bei Fehler). */
function ma_firmen_logo_medium(array $p, int $pid, string &$fehler = ''): int {
    $logo = (array) ($p['logo'] ?? []);
    $id = ma_firmen_medium('logos', (string) ($logo['datei'] ?? ''), 'ma_firmen_logo_datei', $pid, (string) ($logo['alt'] ?? ''),
        'Logo: ' . (string) ($p['titel'] ?? '') . ', Nutzung mit Freigabe des Unternehmens', (string) ($logo['quelle'] ?? ''), $fehler);
    if (!$id && $fehler === 'Datei fehlt im Plugin') $fehler = 'Logo-Datei fehlt im Plugin';
    return $id;
}

/** Anzeigen eines Unternehmens aus der Datei: „anzeigen“ (Liste, seit 28.10.2026), sonst das frühere einzelne „anzeige“. */
function ma_firmen_anzeigen(array $f): array {
    $l = array_values(array_filter((array) ($f['anzeigen'] ?? []), fn($a) => is_array($a) && !empty($a['titel'])));
    if (!$l && !empty($f['anzeige']['titel'])) $l = [(array) $f['anzeige']];
    return $l;
}

/** Fester Schlüssel eines Motivs: „id“, sonst der Name der Bilddatei ohne Endung (almera-clean-1), sonst die Nummer. */
function ma_firmen_anzeige_schluessel(array $a, int $n): string {
    $k = sanitize_title((string) ($a['id'] ?? '') ?: (string) preg_replace('/\.[a-z0-9]+$/i', '', basename((string) ($a['bild'] ?? ''))));
    return $k !== '' ? $k : (string) $n;
}

/**
 * Vorhandenes Werbebanner eines Motivs (jeder Status, auch Papierkorb), sonst 0.
 * Markierung ma_firmen_banner = <slug>:<schlüssel>; früher <slug>:<nummer> bzw. <slug> (einzelnes Banner, = Nummer 1).
 */
function ma_firmen_banner_vorhanden(string $slug, int $n = 1, string $schluessel = ''): int {
    $werte = array_values(array_filter([$schluessel !== '' ? $slug . ':' . $schluessel : '', $slug . ':' . $n, $n === 1 ? $slug : '']));
    $q = get_posts(['post_type' => 'ma_ad', 'post_status' => array_values(array_diff(get_post_stati(), ['auto-draft', 'inherit'])), 'numberposts' => 1, 'fields' => 'ids',
        'meta_query' => [['key' => 'ma_firmen_banner', 'value' => $werte, 'compare' => 'IN']]]);
    return $q ? (int) $q[0] : 0;
}

/** Endgültig gelöschte Firmenbanner merken, damit „Fehlende Entwürfe anlegen“ sie nicht neu anlegt. */
function ma_firmen_banner_geloescht_merken(int $id): void {
    if (get_post_type($id) !== 'ma_ad') return;
    $marke = (string) get_post_meta($id, 'ma_firmen_banner', true);
    if ($marke === '') return;
    $l = (array) get_option('ma_firmen_banner_geloescht', []);
    if (!in_array($marke, $l, true)) { $l[] = $marke; update_option('ma_firmen_banner_geloescht', array_values($l), false); }
}
add_action('before_delete_post', 'ma_firmen_banner_geloescht_merken');

/** Bildnachweis des Banners: aus der Datei (Foto mit Lizenz), sonst eigene Gestaltung. */
function ma_firmen_banner_nachweis(array $a, string $name): string {
    return trim((string) ($a['nachweis'] ?? '')) ?: 'Werbebanner ' . $name . ', gestaltet von Merzenich Aktuell';
}

/**
 * Werbekontingent eines Zugangs aus „werbung.max“ der Datei (28.10.2026): bis zu 5
 * Anzeigen auf allen Werbeplätzen, bei 0 keine. Firmen ohne Eintrag
 * in der Datei behalten die Voreinstellung. Gibt das gesetzte Kontingent zurück, sonst null.
 */
function ma_firmen_kontingent_setzen(int $uid, int $bid, bool $nurErhoehen = false): ?int {
    $f = ma_firmen_eintrag((string) get_post_field('post_name', $bid));
    if (!$f || !isset($f['werbung']['max'])) return null;
    $max = max(0, min(defined('MA_AD_QUOTA_LIMIT') ? MA_AD_QUOTA_LIMIT : 20, (int) $f['werbung']['max']));
    // Beim Nachziehen (Fehlende Entwürfe anlegen) nie ein von Hand höher gesetztes Kontingent senken.
    if ($nurErhoehen && get_user_meta($uid, 'ma_ad_quota_max', true) !== '' && (int) get_user_meta($uid, 'ma_ad_quota_max', true) >= $max) return null;
    update_user_meta($uid, 'ma_ad_quota_max', (string) $max);
    update_user_meta($uid, 'ma_ad_quota_slots', $max ? implode(',', ma_firmen_banner_plaetze()) : '-');
    return $max;
}

/**
 * Werbebanner aus „anzeigen“ anlegen und aktuell halten (28.10.2026): je Motiv eine
 * laufende Anzeige (ma_ad) auf allen Plätzen aus ma_firmen_banner_plaetze(), ohne
 * Ende, mit Foto und Video-Schleife aus data/banner/, Knopf zum Firmenkanal (oder
 * „ziel“), verknüpft mit dem Profil. Ändert sich ein Motiv in der Datei („stand“
 * oder Inhalt), zieht es die Anzeige nach, außer jemand hat sie im Backend bearbeitet.
 * Ergebnis: Zeilen für die Rückmeldung (leer ohne Anzeigen in der Datei).
 */
function ma_firmen_banner_anlegen(array $f, int $pid): array {
    $p = (array) ($f['profil'] ?? []);
    $slug = (string) ($p['slug'] ?? ''); $name = (string) ($p['titel'] ?? $slug);
    $log = []; $eigene = [];
    if ($slug === '') return $log;
    $geloescht = (array) get_option('ma_firmen_banner_geloescht', []);
    $datei = fn(string $d): string => $d !== '' ? ma_firmen_datei('banner', $d) : '';
    foreach (ma_firmen_anzeigen($f) as $i => $a) {
        $n = $i + 1;
        $schluessel = ma_firmen_anzeige_schluessel($a, $n);
        $wer = $name . ', Anzeige ' . $n;
        // WebM-Fassung daneben (gleicher Name), für Browser ohne H.264.
        $webm = !empty($a['video']) ? (string) preg_replace('/\.mp4$/', '.webm', basename((string) $a['video'])) : '';
        if ($webm === basename((string) ($a['video'] ?? '')) || $datei($webm) === '') $webm = '';
        // Prüfsumme über den Eintrag und den Inhalt von Bild, Video und WebM: neu gebaute oder nachgelieferte Dateien zählen als Änderung.
        $pruef = md5((string) wp_json_encode($a) . '|' . implode('|', array_map(fn($d) => ($p = $datei($d)) !== '' ? (string) md5_file($p) : '', [(string) ($a['bild'] ?? ''), (string) ($a['video'] ?? ''), $webm])));
        $da = ma_firmen_banner_vorhanden($slug, $n, $schluessel);
        if ($da) $eigene[] = $da;
        if ($da && get_post_status($da) === 'trash') { $log[] = $wer . ': liegt im Papierkorb, nichts geändert.'; continue; }
        if (!$da && array_intersect([$slug . ':' . $schluessel, $slug . ':' . $n], $geloescht)) { $log[] = $wer . ': wurde gelöscht, nicht neu angelegt.'; continue; }
        if ($da) {
            $altPruef = (string) get_post_meta($da, '_ma_firmen_banner_pruef', true);
            // Handänderung: seit dem letzten Schreiben geändert; bei Bannern ohne Prüfsumme (vor 1.36.0) jede Änderung nach dem Anlegen.
            $vonHand = $altPruef !== ''
                ? (string) get_post_meta($da, '_ma_firmen_banner_geschrieben', true) !== (string) get_post_field('post_modified_gmt', $da)
                : strtotime((string) get_post_field('post_modified_gmt', $da)) > strtotime((string) get_post_field('post_date_gmt', $da)) + 120;
            if ($altPruef === $pruef && get_post_thumbnail_id($da)) { $log[] = $wer . ': aktuell (' . get_post_status($da) . ').'; continue; }
            if ($vonHand) { $log[] = $wer . ': im Backend bearbeitet, nicht überschrieben.'; continue; }
            wp_update_post(wp_slash(['ID' => $da, 'post_title' => (string) $a['titel'], 'post_excerpt' => (string) ($a['text'] ?? '')]));
            $id = $da;
        } else {
            $r = wp_insert_post(wp_slash(['post_type' => 'ma_ad', 'post_status' => 'publish', 'post_title' => (string) $a['titel'], 'post_excerpt' => (string) ($a['text'] ?? '')]), true);
            if (is_wp_error($r) || !$r) { $log[] = $wer . ': nicht angelegt' . (is_wp_error($r) ? ' (' . $r->get_error_message() . ')' : '') . '.'; continue; }
            $id = (int) $r; $eigene[] = $id;
            $plaetze = ma_firmen_banner_plaetze();
            update_post_meta($id, 'ma_ad_slot', $plaetze[0]);
            foreach (array_slice($plaetze, 1) as $pl) add_post_meta($id, 'ma_ad_slot_weitere', $pl);
            update_post_meta($id, 'ma_ad_active', '1');
            update_post_meta($id, 'ma_business_id', (string) $pid);
        }
        update_post_meta($id, 'ma_firmen_banner', $slug . ':' . $schluessel);
        update_post_meta($id, 'ma_ad_sponsor', (string) ($a['zeile'] ?? $name));
        update_post_meta($id, 'ma_ad_knopf', (string) ($a['knopf'] ?? 'Zum Profil'));
        update_post_meta($id, 'ma_ad_url', (string) ($a['ziel'] ?? '') ?: (string) get_permalink($pid));
        update_post_meta($id, 'ma_ad_ki', !empty($a['ki']) ? '1' : '');
        update_post_meta($id, 'ma_ad_fokus', preg_match('/^\d{1,3}% \d{1,3}%$/', (string) ($a['fokus'] ?? '')) ? (string) $a['fokus'] : '');
        $nachweis = ma_firmen_banner_nachweis($a, $name); $alt = (string) ($a['alt'] ?? 'Anzeige ' . $name); $fehler = '';
        $m = !empty($a['bild']) ? ma_firmen_medium('banner', (string) $a['bild'], 'ma_firmen_banner_datei', $id, $alt, $nachweis, (string) ($a['quelle'] ?? ''), $fehler, true) : 0;
        if ($m) set_post_thumbnail($id, $m);
        $leer = '';
        $v = !empty($a['video']) ? ma_firmen_medium('banner', (string) $a['video'], 'ma_firmen_banner_datei', $id, $alt, $nachweis, (string) ($a['quelle'] ?? ''), $leer, true) : 0;
        update_post_meta($id, 'ma_ad_video', $v ? (string) $v : '');
        $vw = $webm !== '' ? ma_firmen_medium('banner', $webm, 'ma_firmen_banner_datei', $id, $alt, $nachweis, (string) ($a['quelle'] ?? ''), $leer, true) : 0;
        update_post_meta($id, 'ma_ad_video_webm', $vw ? (string) $vw : '');
        update_post_meta($id, '_ma_firmen_banner_pruef', $pruef);
        update_post_meta($id, '_ma_firmen_banner_geschrieben', (string) get_post_field('post_modified_gmt', $id));
        if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen($id, $da ? 'Werbebanner aktualisiert' : 'Werbebanner angelegt', 'Aus data/firmen-entwuerfe.json (Anzeige ' . $n . ' von ' . $name . '). Läuft ohne Ende, bis der Betreiber es austauscht.');
        $log[] = $wer . ($da ? ': aktualisiert' : ': läuft') . ($m ? '' : ' (ohne Bild: ' . ($fehler ?: 'keine Bilddatei') . ')') . ($v || empty($a['video']) ? '' : ' (ohne Video)') . '.';
    }
    // Banner der Firma aus der Datei, deren Motiv es dort nicht mehr gibt: Schaltung aus (nichts wird gelöscht).
    foreach (get_posts(['post_type' => 'ma_ad', 'post_status' => ['publish', 'future', 'draft', 'pending'], 'numberposts' => -1, 'fields' => 'ids', 'meta_query' => [['key' => 'ma_business_id', 'value' => (string) $pid]]]) as $alt) {
        $marke = (string) get_post_meta($alt, 'ma_firmen_banner', true);
        if ($marke === '' || ($marke !== $slug && strpos($marke, $slug . ':') !== 0) || in_array((int) $alt, $eigene, true) || (string) get_post_meta($alt, 'ma_ad_active', true) !== '1') continue;
        update_post_meta($alt, 'ma_ad_active', '0');
        $log[] = $name . ': Werbebanner „' . get_the_title($alt) . '“ steht nicht mehr in der Datei, Schaltung aus.';
        if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen((int) $alt, 'Werbebanner abgeschaltet', 'Motiv nicht mehr in data/firmen-entwuerfe.json.');
    }
    return $log;
}

/**
 * Zusage eines Betriebs eintragen. $nachweis: woher die Zusage stammt (Pflicht).
 * Einwilligung und Logo getrennt; was schon eingetragen ist, bleibt unverändert.
 * Ergebnis: Zeilen für die Rückmeldung.
 */
function ma_firmen_zusage_eintragen(string $slug, string $nachweis, bool $einwilligung, bool $logo): array {
    $f = ma_firmen_eintrag($slug);
    if (!$f) return ['Unbekannter Betrieb.'];
    $p = (array) $f['profil']; $name = (string) ($p['titel'] ?? $slug);
    $nachweis = trim($nachweis);
    if ($nachweis === '') return [$name . ': Ohne Nachweis der Zusage wird nichts eingetragen.'];
    if (empty($p['logo'])) $logo = false;
    if (!$einwilligung && !$logo) return [$name . ': Kein Haken gesetzt, nichts eingetragen.'];
    $pid = ma_firmen_vorhanden('ma_business', (string) $p['slug']);
    if (!$pid || get_post_status($pid) === 'trash') return [$name . ': Profil fehlt. Zuerst „Fehlende Entwürfe anlegen“.'];
    $wer = wp_get_current_user();
    $wer = (string) ($wer->display_name ?? '') ?: (string) ($wer->user_login ?? '');
    $jetzt = (string) current_time('d.m.Y H:i');
    $log = [];
    if ($logo && (string) get_post_meta($pid, 'ma_business_logo_rechte', true) === 'geklaert') {
        $log[] = $name . ': Logo war schon freigegeben, nichts geändert.';
    } elseif ($logo) {
        $fehler = '';
        $m = ma_firmen_logo_medium($p, $pid, $fehler);
        if (!$m) $log[] = $name . ': Logo nicht übernommen (' . $fehler . ').';
        else {
            set_post_thumbnail($pid, $m);
            update_post_meta($pid, 'ma_business_logo_rechte', 'geklaert');
            update_post_meta($pid, 'ma_business_logo_freigabe', $nachweis . ' · eingetragen von ' . $wer . ' am ' . $jetzt);
            $log[] = $name . ': Logo freigegeben und als Beitragsbild gesetzt.';
            if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen($pid, 'Logo freigegeben', $nachweis);
        }
    }
    if ($einwilligung) {
        // Leere Profilfelder aus der Datei ergänzen (28.10.2026: Merzlicht bekam die Branche erst nach dem Anlegen),
        // ohne vorhandene Angaben zu überschreiben.
        foreach (['branche', 'ortsteil', 'ort', 'adresse', 'telefon', 'email', 'website'] as $feld) {
            $wert = (string) ($p[$feld] ?? '');
            if ($wert !== '' && (string) get_post_meta($pid, 'ma_business_' . $feld, true) === '') update_post_meta($pid, 'ma_business_' . $feld, $wert);
        }
        if ((string) get_post_meta($pid, 'ma_business_consent', true) !== '1') {
            update_post_meta($pid, 'ma_business_consent', '1');
            update_post_meta($pid, 'ma_business_consent_by', $wer);
            update_post_meta($pid, 'ma_business_consent_at', $jetzt);
            update_post_meta($pid, 'ma_business_consent_quelle', $nachweis);
            if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen($pid, 'Einwilligung eingetragen', $nachweis);
        }
        if (get_post_status($pid) !== 'publish') {
            $r = wp_update_post(['ID' => $pid, 'post_status' => 'publish'], true);
            $log[] = $name . (!is_wp_error($r) && get_post_status($pid) === 'publish' ? ': Einwilligung eingetragen, Profil veröffentlicht.' : ': Einwilligung eingetragen, Profil aber nicht veröffentlicht.');
        } else $log[] = $name . ': Einwilligung eingetragen, Profil war schon veröffentlicht.';
        // Der Werbebeitrag (erster Beitrag der Datei) geht zur Prüfung in die Freigaben; dort setzt die Redaktion die
        // Prüfhäkchen und veröffentlicht (Sperre in freigabe.php). Zusatzbeiträge bleiben Entwurf (Review 20.10.2026).
        $bid = ma_firmen_vorhanden('post', (string) ($f['beitrag']['slug'] ?? ''));
        if ($bid && get_post_status($pid) === 'publish' && get_post_status($bid) === 'draft') {
            wp_update_post(['ID' => $bid, 'post_status' => 'pending']);
            $log[] = $name . ': Werbebeitrag liegt in den Freigaben zur Prüfung.';
            if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen($bid, 'Zur Freigabe vorgelegt', 'Einwilligung des Unternehmens eingetragen: ' . $nachweis);
        }
        // Werbebanner erst, wenn das Profil veröffentlicht ist (Einwilligung wirksam).
        if (get_post_status($pid) === 'publish') $log = array_merge($log, ma_firmen_banner_anlegen($f, $pid));
    }
    return $log;
}

/**
 * Firma zurückziehen: veröffentlichte, geplante und wartende Beiträge des Profils,
 * seine laufenden Werbebanner und das Profil selbst werden Entwurf (Banner auch
 * „Schaltung aus“). Nichts wird gelöscht; Logos bleiben in der Mediathek. Nur für
 * Unternehmen aus der Datei (aktuell oder „frueher“). Ergebnis: Zeilen.
 */
function ma_firmen_zurueckziehen(string $slug): array {
    $bekannt = [];
    foreach ((array) (ma_firmen_entwuerfe_daten()['firmen'] ?? []) as $f) $bekannt[(string) ($f['profil']['slug'] ?? '')] = (string) ($f['profil']['titel'] ?? '');
    foreach ((array) (ma_firmen_entwuerfe_daten()['frueher'] ?? []) as $f) $bekannt[(string) ($f['slug'] ?? '')] = (string) ($f['titel'] ?? '');
    if ($slug === '' || !isset($bekannt[$slug])) return ['Unbekannter Betrieb.'];
    $name = $bekannt[$slug] ?: $slug;
    $pid = ma_firmen_vorhanden('ma_business', $slug);
    if (!$pid) return [$name . ': Profil nicht gefunden, nichts geändert.'];
    if (get_post_status($pid) === 'trash') return [$name . ': Profil liegt im Papierkorb, nichts geändert.'];
    $log = []; $n = 0;
    foreach (['post', 'ma_ad'] as $typ) {
        $ids = get_posts(['post_type' => $typ, 'post_status' => ['publish', 'future', 'pending', 'ma_in_pruefung'], 'posts_per_page' => -1, 'fields' => 'ids',
            'meta_query' => [['key' => 'ma_business_id', 'value' => (string) $pid]]]);
        foreach ($ids as $id) {
            if ($typ === 'ma_ad') update_post_meta((int) $id, 'ma_ad_active', '0');
            wp_update_post(['ID' => (int) $id, 'post_status' => 'draft']);
            if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen((int) $id, 'Zurückgezogen', 'Unternehmen ' . $name . ' von der Seite genommen (Firmen-Entwürfe).');
            $n++;
        }
    }
    $log[] = $name . ': ' . $n . ($n === 1 ? ' Beitrag oder Banner' : ' Beiträge und Banner') . ' auf Entwurf gesetzt.';
    if (get_post_status($pid) !== 'draft') {
        wp_update_post(['ID' => $pid, 'post_status' => 'draft']);
        if (function_exists('ma_verlauf_eintragen')) ma_verlauf_eintragen($pid, 'Zurückgezogen', 'Profil von der Seite genommen (Firmen-Entwürfe).');
        $log[] = $name . ': Profil auf Entwurf gesetzt.';
    } else $log[] = $name . ': Profil war schon Entwurf.';
    return $log;
}

// Priorität 30: Das Hauptmenü „Merzenich Aktuell“ meldet admin.php erst bei plugins_loaded an (Priorität 10);
// vorher angemeldet, fehlte die Seite (403 „Keine Berechtigung“).
add_action('admin_menu', function (): void {
    add_submenu_page('merzenich-aktuell', 'Firmen-Entwürfe', 'Firmen-Entwürfe', 'edit_others_posts', 'ma-firmen-entwuerfe', 'ma_firmen_entwuerfe_seite');
}, 30);

/** Nur ein Lauf zur Zeit (Banner-Import mit Videos dauert; ein zweiter Klick legte sonst doppelt an). */
function ma_firmen_gesperrt(callable $lauf): array {
    if (!add_option('ma_firmen_lauf', (string) time(), '', false)) {
        if ((int) get_option('ma_firmen_lauf') > time() - 600) return ['Ein Lauf ist noch nicht fertig. Bitte in ein bis zwei Minuten die Seite neu laden.'];
        update_option('ma_firmen_lauf', (string) time(), false);
    }
    try { return $lauf(); } finally { delete_option('ma_firmen_lauf'); }
}

add_action('admin_post_ma_firmen_zusage', function (): void {
    if (!current_user_can('edit_others_posts')) wp_die('Keine Berechtigung.');
    check_admin_referer('ma_firmen_zusage');
    $log = ma_firmen_gesperrt(fn() => ma_firmen_zusage_eintragen(sanitize_title(wp_unslash($_POST['firma'] ?? '')), sanitize_text_field(wp_unslash($_POST['nachweis'] ?? '')), !empty($_POST['einwilligung']), !empty($_POST['logo'])));
    set_transient('ma_firmen_entwuerfe_log_' . get_current_user_id(), $log, 300);
    wp_safe_redirect(admin_url('admin.php?page=ma-firmen-entwuerfe&angelegt=1'));
    exit;
});

add_action('admin_post_ma_firmen_zurueckziehen', function (): void {
    if (!current_user_can('edit_others_posts')) wp_die('Keine Berechtigung.');
    check_admin_referer('ma_firmen_zurueckziehen');
    set_transient('ma_firmen_entwuerfe_log_' . get_current_user_id(), ma_firmen_zurueckziehen(sanitize_title(wp_unslash($_POST['firma'] ?? ''))), 300);
    wp_safe_redirect(admin_url('admin.php?page=ma-firmen-entwuerfe&angelegt=1'));
    exit;
});

add_action('admin_post_ma_firmen_entwuerfe', function (): void {
    if (!current_user_can('edit_others_posts')) wp_die('Keine Berechtigung.');
    check_admin_referer('ma_firmen_entwuerfe');
    set_transient('ma_firmen_entwuerfe_log_' . get_current_user_id(), ma_firmen_gesperrt('ma_firmen_entwuerfe_anlegen'), 300);
    wp_safe_redirect(admin_url('admin.php?page=ma-firmen-entwuerfe&angelegt=1'));
    exit;
});

function ma_firmen_entwuerfe_seite(): void {
    $daten = ma_firmen_entwuerfe_daten();
    echo '<div class="wrap"><h1>Firmen-Entwürfe</h1><p>' . esc_html((string) ($daten['hinweis'] ?? '')) . '</p>';
    $log = get_transient('ma_firmen_entwuerfe_log_' . get_current_user_id());
    if (!empty($_GET['angelegt']) && is_array($log)) { echo '<div class="notice notice-success"><ul>'; foreach ($log as $z) echo '<li>' . esc_html((string) $z) . '</li>'; echo '</ul></div>'; }
    $zurueck = fn(string $slug, string $name): string => '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(' . esc_attr(wp_json_encode($name . ' von der Seite nehmen? Profil, Beiträge und Banner werden Entwurf.')) . ')"><input type="hidden" name="action" value="ma_firmen_zurueckziehen"><input type="hidden" name="firma" value="' . esc_attr($slug) . '">'
        . wp_nonce_field('ma_firmen_zurueckziehen', '_wpnonce', true, false) . '<button class="button-link" style="color:#b32d2e">Firma zurückziehen</button></form>';
    echo '<table class="widefat striped"><thead><tr><th>Betrieb</th><th>Profil</th><th>Einwilligung</th><th>Werbebeitrag</th><th>Logo</th><th>Werbebanner</th><th>Zusage eintragen</th></tr></thead><tbody>';
    foreach ((array) ($daten['firmen'] ?? []) as $f) {
        $p = (array) ($f['profil'] ?? []); $b = (array) ($f['beitrag'] ?? []);
        $pid = ma_firmen_vorhanden('ma_business', (string) ($p['slug'] ?? ''));
        $bid = ma_firmen_vorhanden('post', (string) ($b['slug'] ?? ''));
        $zelle = fn(int $id): string => $id ? '<a href="' . esc_url((string) get_edit_post_link($id)) . '">' . esc_html(function_exists('ma_status_name') ? ma_status_name((string) get_post_status($id)) : (string) get_post_status($id)) . '</a>' . (get_post_status($id) !== 'publish' ? ' · <a href="' . esc_url((string) get_preview_post_link($id)) . '" target="_blank">Vorschau</a>' : '') : 'fehlt';
        $ja = $pid && (string) get_post_meta($pid, 'ma_business_consent', true) === '1';
        $logoJa = $pid && (string) get_post_meta($pid, 'ma_business_logo_rechte', true) === 'geklaert';
        $logo = (array) ($p['logo'] ?? []);
        $einw = $ja ? 'liegt vor<br><small>' . esc_html(trim((string) get_post_meta($pid, 'ma_business_consent_quelle', true) . ' · ' . get_post_meta($pid, 'ma_business_consent_by', true) . ', ' . get_post_meta($pid, 'ma_business_consent_at', true), ' ·,')) . '</small>' : '<strong>fehlt</strong>';
        $logoZelle = !$logo ? '– <small>(noch kein Logo)</small>' : (!empty($logo['quelle']) ? '<a href="' . esc_url((string) $logo['quelle']) . '" target="_blank" rel="noopener">Quelle</a>, ' : '')
            . ($logoJa ? 'freigegeben<br><small>' . esc_html((string) get_post_meta($pid, 'ma_business_logo_freigabe', true)) . '</small>' : 'Rechte <strong>offen</strong>');
        $anzeigen = ma_firmen_anzeigen($f);
        $banZelle = !$anzeigen ? '–' : implode('<br>', array_map(function (array $a, int $i) use ($p, $zelle): string {
            $ban = ma_firmen_banner_vorhanden((string) $p['slug'], $i + 1, ma_firmen_anzeige_schluessel($a, $i + 1));
            return ($i + 1) . ': ' . ($ban ? $zelle($ban) . ((string) get_post_meta($ban, 'ma_ad_active', true) === '1' ? ' · läuft' : ' · aus') : 'kommt mit der Einwilligung');
        }, $anzeigen, array_keys($anzeigen)));
        if (!$logo) $logoJa = true;
        $form = '';
        if ($pid && (!$ja || !$logoJa)) {
            $form = '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="ma_firmen_zusage"><input type="hidden" name="firma" value="' . esc_attr((string) $p['slug']) . '">'
                . wp_nonce_field('ma_firmen_zusage', '_wpnonce', true, false)
                . '<label style="display:block">Nachweis <input type="text" name="nachweis" required class="regular-text" placeholder="z. B. E-Mail vom … / Zusage laut Betreiber am …"></label>'
                . (!$ja ? '<label style="display:block"><input type="checkbox" name="einwilligung" value="1"> Das Unternehmen hat der Veröffentlichung von Profil' . ($b ? ' und Werbebeitrag' : '') . (ma_firmen_anzeigen($f) ? ' und Werbebanner' : '') . ' zugestimmt.</label>' : '')
                . (!$logoJa ? '<label style="display:block"><input type="checkbox" name="logo" value="1"> Das Unternehmen hat die Nutzung seines Logos freigegeben.</label>' : '')
                . '<button class="button">Zusage eintragen</button></form>';
        }
        echo '<tr><td><strong>' . esc_html((string) ($p['titel'] ?? '')) . '</strong><br><small>' . esc_html((string) ($p['adresse'] ?? '') ?: (!empty($f['nur_name']) ? 'bisher nur der Name' : '')) . '</small></td><td>' . $zelle($pid) . '</td><td>' . $einw . '</td><td>' . ($b ? $zelle($bid) : '–') . '</td>'
            . '<td>' . $logoZelle . '</td><td>' . $banZelle . '</td><td>' . ($form ?: ($pid ? 'eingetragen' : '–')) . ($pid && get_post_status($pid) === 'publish' ? $zurueck((string) $p['slug'], (string) ($p['titel'] ?? '')) : '') . '</td></tr>';
    }
    echo '</tbody></table>';
    $frueher = (array) ($daten['frueher'] ?? []);
    if ($frueher) {
        echo '<h2 style="margin-top:24px">Früher eingetragen</h2><p>Diese Betriebe sind nicht mehr in der Datei. „Firma zurückziehen“ setzt Profil, Beiträge und Banner auf Entwurf; gelöscht wird nichts.</p><table class="widefat striped"><thead><tr><th>Betrieb</th><th>Profil</th><th>Veröffentlichte Beiträge</th><th></th></tr></thead><tbody>';
        foreach ($frueher as $alt) {
            $slug = (string) ($alt['slug'] ?? ''); $pid = $slug !== '' ? ma_firmen_vorhanden('ma_business', $slug) : 0;
            $n = $pid ? count(get_posts(['post_type' => ['post', 'ma_ad'], 'post_status' => ['publish', 'future', 'pending', 'ma_in_pruefung'], 'posts_per_page' => -1, 'fields' => 'ids', 'meta_query' => [['key' => 'ma_business_id', 'value' => (string) $pid]]])) : 0;
            $aktiv = $pid && get_post_status($pid) !== 'trash' && (get_post_status($pid) !== 'draft' || $n);
            echo '<tr><td><strong>' . esc_html((string) ($alt['titel'] ?? $slug)) . '</strong></td><td>' . ($pid ? esc_html(function_exists('ma_status_name') ? ma_status_name((string) get_post_status($pid)) : (string) get_post_status($pid)) : 'nicht vorhanden') . '</td><td>' . $n . '</td><td>' . ($aktiv ? $zurueck($slug, (string) ($alt['titel'] ?? $slug)) : 'von der Seite genommen') . '</td></tr>';
        }
        echo '</tbody></table>';
    }
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:16px"><input type="hidden" name="action" value="ma_firmen_entwuerfe">';
    wp_nonce_field('ma_firmen_entwuerfe');
    echo '<button class="button button-primary">Fehlende Entwürfe anlegen</button> <span class="description">Legt fehlende Profile und Beiträge als Entwurf an. Bei Firmen mit Einwilligung laufen fehlende Werbebanner sofort, geänderte werden nachgezogen.</span></form></div>';
}
