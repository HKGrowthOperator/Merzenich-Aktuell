<?php
/**
 * Redaktionszugänge für alle Vereine der Gemeinde (30.09.2026).
 *
 * Wunsch Betreiber: alle Vereine aus Merzenich, ausdrücklich auch alle
 * Sportvereine, bekommen einen eigenen Zugang. Damit reichen sie Meldungen,
 * Termine, Fotos und Ergänzungen zu ihrem Vereinsprofil ein; veröffentlicht
 * wird erst nach Freigabe durch die Redaktion (Partner-Rollen, partners.php).
 *
 * Grundlage ist data/vereinsverzeichnis.json (Kopie von
 * deploy/vereinsverzeichnis.json, belegt aus Bürgerbroschüre, Amtsblättern,
 * Heimat-Info und Vereinswebsites). Sportvereine erhalten die Rolle
 * Sport-Partner, alle anderen Vereins-Partner. Die Feuerwehr hat eigene
 * Partner-Rollen und bleibt hier außen vor.
 *
 * Benutzer → Vereinszugänge: fehlende Zugänge anlegen (E-Mail-Vorlage mit
 * {kurz}). Eine Einladungsfunktion gibt es vorerst nicht (Entscheidung KBS,
 * 03.10.2026: noch keine echten Vereinsadressen). Die Administration trägt die
 * echte Adresse im Profil ein und setzt dort das Passwort bzw. schickt danach
 * den Passwort-Link.
 */
if (!defined('ABSPATH')) { exit; }

function ma_vereinsverzeichnis(): array {
    static $v = null;
    if ($v !== null) return $v;
    $pfad = MA_CORE_PATH . 'data/vereinsverzeichnis.json';
    $d = is_readable($pfad) ? json_decode((string) file_get_contents($pfad), true) : null;
    return $v = is_array($d['vereine'] ?? null) ? $d['vereine'] : [];
}

/** Kurzer, stabiler Schlüssel je Verein (für Login und E-Mail-Vorlage). */
function ma_verein_kurz(string $name): string {
    $s = remove_accents(str_replace(['ä', 'ö', 'ü', 'Ä', 'Ö', 'Ü', 'ß'], ['ae', 'oe', 'ue', 'ae', 'oe', 'ue', 'ss'], $name));
    $s = preg_replace('/\b(e\s*\.?\s*v\.?|gegr\.?|vor)\b/i', ' ', $s);
    $s = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($s)), '-');
    return substr($s, 0, 40) ?: 'verein';
}

function ma_verein_rolle(array $v): string {
    return ($v['kategorie'] ?? '') === 'Sport' ? 'ma_sport_partner' : 'ma_vereine_partner';
}

/** Vereine, die einen Zugang bekommen (ohne Feuerwehr, die eigene Rollen hat). */
function ma_vereine_fuer_zugang(): array {
    return array_values(array_filter(ma_vereinsverzeichnis(), fn($v) => ($v['kategorie'] ?? '') !== 'Feuerwehr' && !empty($v['name'])));
}

function ma_verein_benutzer(string $kurz): ?WP_User {
    $u = get_users(['meta_key' => 'ma_verein_kurz', 'meta_value' => $kurz, 'number' => 1]);
    return $u[0] ?? null;
}

/**
 * Legt fehlende Vereinszugänge an. $vorlage z. B. "info+{kurz}@example.de";
 * leer = ohne E-Mail (Vorgabe Betreiber 07.10.2026: die Vereine tragen ihre
 * Adresse selbst ein). Gibt [angelegt, vorhanden, fehler[]] zurück. Sendet keine Mail.
 */
function ma_vereinszugaenge_anlegen(string $vorlage): array {
    $angelegt = 0; $vorhanden = 0; $fehler = [];
    foreach (ma_vereine_fuer_zugang() as $v) {
        $kurz = ma_verein_kurz($v['name']);
        if (ma_verein_benutzer($kurz)) { $vorhanden++; continue; }
        $mail = trim($vorlage) === '' ? '' : sanitize_email(str_replace('{kurz}', $kurz, $vorlage));
        if ($mail !== '' && !is_email($mail)) { $fehler[] = $v['name'] . ': E-Mail ungültig'; continue; }
        if ($mail !== '' && email_exists($mail)) { $fehler[] = $v['name'] . ': E-Mail ' . $mail . ' ist schon vergeben'; continue; }
        $login = 'verein-' . substr($kurz, 0, 50); $i = 2;
        while (username_exists($login)) { $login = 'verein-' . substr($kurz, 0, 46) . '-' . $i++; }
        $id = wp_insert_user(['user_login' => $login, 'user_email' => $mail, 'display_name' => $v['name'], 'nickname' => $v['name'],
            'user_pass' => wp_generate_password(24, true, true), 'role' => ma_verein_rolle($v), 'user_url' => $v['website'] ?? '']);
        if (is_wp_error($id)) { $fehler[] = $v['name'] . ': ' . $id->get_error_message(); continue; }
        update_user_meta($id, 'ma_verein_kurz', $kurz);
        update_user_meta($id, 'ma_verein_name', $v['name']);
        update_user_meta($id, 'ma_verein_ort', $v['ort'] ?? '');
        update_user_meta($id, 'ma_verein_quelle', $v['quelle'] ?? '');
        $angelegt++;
    }
    return [$angelegt, $vorhanden, $fehler];
}

add_action('admin_menu', function (): void {
    add_users_page('Vereinszugänge', 'Vereinszugänge', 'manage_options', 'ma-vereinszugaenge', 'ma_vereinszugaenge_seite');
});

/* ---------------------------------------------------------- Platzhalter-Adressen (07.10.2026) */

/** Rollen der Partner- und Vereinskonten, die ihre E-Mail selbst eintragen dürfen. */
function ma_partner_rollen(): array {
    return function_exists('ma_partner_policies') ? array_keys(ma_partner_policies()) : ['ma_sport_partner', 'ma_vereine_partner'];
}

/** Ist ein Konto ein Partner- oder Vereinskonto (nie Redaktion oder Administration)? */
function ma_ist_partnerkonto(WP_User $u): bool {
    if (user_can($u, 'edit_others_posts') || user_can($u, 'manage_options')) return false;
    return (bool) array_intersect((array) $u->roles, ma_partner_rollen()) || preg_match('/^(verein|partner)-/', $u->user_login);
}

/** Pure Prüfung: Platzhalter-Adresse der Agentur (info+…@hk-growthoperator.de), nicht die eigene des Kontos. */
function ma_ist_platzhalter_mail(string $mail): bool {
    return (bool) preg_match('/@hk-?growthoperator\.de$/i', trim($mail));
}

/** Partner- und Vereinskonten mit Platzhalter-Adresse. */
function ma_platzhalter_konten(): array {
    return array_values(array_filter(get_users(['search' => '*growthoperator.de', 'search_columns' => ['user_email'], 'number' => 500]),
        fn(WP_User $u) => ma_ist_platzhalter_mail($u->user_email) && ma_ist_partnerkonto($u)));
}

/** Entfernt die Platzhalter-Adressen; Name, Rolle, Passwort und Zuordnung bleiben. Ohne Benachrichtigung. */
function ma_platzhalter_mails_entfernen(): int {
    add_filter('send_email_change_email', '__return_false', 99);
    $n = 0;
    foreach (ma_platzhalter_konten() as $u) {
        $r = wp_update_user(['ID' => $u->ID, 'user_email' => '']);
        if (!is_wp_error($r)) { update_user_meta($u->ID, 'ma_mail_entfernt', current_time('mysql')); $n++; }
    }
    remove_filter('send_email_change_email', '__return_false', 99);
    return $n;
}

add_action('admin_post_ma_platzhalter_mails', function (): void {
    if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    check_admin_referer('ma_platzhalter_mails');
    $n = ma_platzhalter_mails_entfernen();
    wp_safe_redirect(add_query_arg('ma_meldung', rawurlencode($n . ' Platzhalter-Adressen entfernt. Die Partner tragen ihre E-Mail selbst im Profil ein.'), admin_url('users.php?page=ma-vereinszugaenge')));
    exit;
});

/* Partner- und Vereinskonten dürfen ihr Profil ohne E-Mail speichern, bis sie ihre eigene eintragen. */
add_action('user_profile_update_errors', function (WP_Error $fehler, bool $update, $user): void {
    if (!$update || trim((string) ($user->user_email ?? '')) !== '') return;
    $u = get_userdata((int) ($user->ID ?? 0));
    if ($u && ma_ist_partnerkonto($u)) { $fehler->remove('empty_email'); $fehler->remove('invalid_email'); }
}, 10, 3);

/* Die erste eigene Adresse gilt sofort: Ohne alte Adresse gibt es nichts zu schützen, und die
   Bestätigungsmail von WordPress käme ohne eingerichteten Mailversand womöglich nie an. */
add_action('personal_options_update', function (int $id): void {
    $u = get_userdata($id);
    if ($u && trim($u->user_email) === '' && ma_ist_partnerkonto($u)) remove_action('personal_options_update', 'send_confirmation_on_profile_email');
}, 1);

/* Hinweis im eigenen Profil, solange die Adresse fehlt. */
add_action('admin_notices', function (): void {
    $s = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$s || !in_array($s->id, ['profile', 'dashboard'], true)) return;
    $u = wp_get_current_user();
    if (!$u->exists() || trim($u->user_email) !== '' || !ma_ist_partnerkonto($u)) return;
    echo '<div class="notice notice-warning"><p><strong>Bitte tragen Sie Ihre eigene E-Mail-Adresse ein</strong> (' . ($s->id === 'profile' ? 'unten unter „Kontaktinfo“' : '<a href="' . esc_url(admin_url('profile.php')) . '">im Profil</a>') . '). Darüber erreichen Sie Hinweise der Redaktion und können Ihr Passwort zurücksetzen.</p></div>';
});


function ma_vereinszugaenge_seite(): void {
    if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
    $meldung = '';
    if (isset($_POST['ma_vereinszugaenge'])) {
        check_admin_referer('ma_vereinszugaenge');
        $vorlage = sanitize_text_field(wp_unslash($_POST['vorlage'] ?? ''));
        if ($vorlage !== '' && (!str_contains($vorlage, '{kurz}') || !str_contains($vorlage, '@'))) $meldung = 'Die E-Mail-Vorlage braucht {kurz} und ein @, z. B. info+{kurz}@ihre-domain.de, oder bleibt leer.';
        else {
            [$a, $v, $f] = ma_vereinszugaenge_anlegen($vorlage);
            update_option('ma_vereinszugang_vorlage', $vorlage, false);
            $meldung = "$a Zugänge angelegt, $v waren schon da." . ($f ? ' Nicht angelegt: ' . implode('; ', $f) : '') . ' Es wurde keine E-Mail verschickt.';
        }
    }
    if (!empty($_GET['ma_meldung'])) $meldung = sanitize_text_field(wp_unslash($_GET['ma_meldung']));
    if (!empty($_GET['ma_profile'])) { [$pa, $pv] = array_map('intval', explode('-', sanitize_text_field(wp_unslash($_GET['ma_profile'])) . '-0')); $meldung = "$pa Vereinsprofile angelegt, $pv waren schon da."; }
    $vereine = ma_vereine_fuer_zugang();
    echo '<div class="wrap"><h1>Vereinszugänge</h1>';
    echo '<p>Jeder Verein aus dem Vereinsverzeichnis der Gemeinde bekommt einen eigenen Redaktionszugang. Damit reicht er Meldungen, Termine, Fotos und Ergänzungen zu seinem Vereinsprofil ein. <strong>Veröffentlicht wird immer erst nach Freigabe</strong> unter <a href="' . esc_url(admin_url('admin.php?page=ma-freigaben')) . '">Merzenich Aktuell → Freigaben</a>. Wer Fotos hochlädt, muss vorher die Bildrechte bestätigen.</p>';
    if ($meldung !== '') echo '<div class="notice notice-info"><p>' . esc_html($meldung) . '</p></div>';
    echo '<form method="post" style="background:#fff;border:1px solid #dcdcde;padding:14px 16px;max-width:760px">';
    wp_nonce_field('ma_vereinszugaenge');
    printf('<p><label><strong>E-Mail-Vorlage für neue Zugänge (freiwillig)</strong><br><input class="regular-text" name="vorlage" value="%s" placeholder="leer = ohne E-Mail, die Vereine tragen sie selbst ein"></label><br><span class="description">{kurz} wird durch den Kurznamen des Vereins ersetzt. Die Adresse lässt sich später im Benutzerprofil auf die echte Vereinsadresse ändern.</span></p>',
        esc_attr(ma_ist_platzhalter_mail(str_replace('{kurz}', 'x', (string) get_option('ma_vereinszugang_vorlage', ''))) ? '' : (string) get_option('ma_vereinszugang_vorlage', '')));
    echo '<p><button class="button button-primary" name="ma_vereinszugaenge" value="1">Fehlende Zugänge anlegen (ohne Benachrichtigung)</button></p></form>';
    $platz = ma_platzhalter_konten();
    if ($platz) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="background:#fff8e5;border:1px solid #dba617;padding:14px 16px;max-width:760px;margin-top:12px"><input type="hidden" name="action" value="ma_platzhalter_mails">';
        wp_nonce_field('ma_platzhalter_mails');
        echo '<p><strong>' . count($platz) . ' Partner- und Vereinskonten haben noch eine Platzhalter-Adresse</strong> (@hk-growthoperator.de). Entfernen leert nur die E-Mail; Name, Rolle, Passwort und Zuordnung bleiben, niemand wird benachrichtigt. Die Partner tragen ihre Adresse danach selbst im Profil ein.</p>';
        echo '<details><summary>Betroffene Konten anzeigen</summary><p class="description">' . esc_html(implode(', ', array_map(fn($u) => $u->user_login, $platz))) . '</p></details>';
        echo '<p><button class="button" onclick="return confirm(\'Platzhalter-Adressen bei ' . count($platz) . ' Konten entfernen?\')">Platzhalter-Adressen entfernen</button></p></form>';
    }
    if (function_exists('ma_vereine_struktur')) {
        $struktur = ma_vereine_struktur();
        $mitProfil = count(array_filter(array_keys($struktur), fn($k) => ma_verein_profil($k)));
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;margin-top:16px;max-width:1100px">';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="background:#fff;border:1px solid #dcdcde;padding:14px 16px"><input type="hidden" name="action" value="ma_vereinsprofile_anlegen">';
        wp_nonce_field('ma_vereinsprofile_anlegen');
        echo '<p><strong>Vereinsprofile</strong><br>' . (int) $mitProfil . ' von ' . count($struktur) . ' Vereinen haben ein Profil unter /vereine/…/. Abteilungen stehen im Profil ihres Hauptvereins.</p><p><button class="button">Fehlende Vereinsprofile anlegen</button></p><p class="description">Nur Angaben aus dem Verzeichnis (Name, Ortsteil, Kategorie, Sportarten, Abteilungen, Website). Beschreibung, Logo und Bilder ergänzt der Verein, die Redaktion gibt frei.</p></form>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="background:#fff;border:1px solid #dcdcde;padding:14px 16px"><input type="hidden" name="action" value="ma_verein_zugang"><input type="hidden" name="aktion" value="neu"><input type="hidden" name="user" value="0">';
        wp_nonce_field('ma_verein_zugang_neu_0');
        echo '<p><strong>Weiteren Redakteur für einen Verein anlegen</strong></p><p><select name="verein" required style="max-width:100%"><option value="">Verein wählen</option>';
        foreach ($struktur as $k => $e) printf('<option value="%s">%s</option>', esc_attr($k), esc_html($e['verein']['name']));
        echo '</select></p><p><input name="name" placeholder="Name der Person" required class="regular-text"> <input name="email" type="email" placeholder="E-Mail" required class="regular-text"></p><p><button class="button">Redakteur anlegen</button> <span class="description">Keine Mail. Passwort danach im Profil setzen.</span></p></form></div>';
    }
    echo '<table class="widefat striped" style="margin-top:18px"><thead><tr><th>Verein</th><th>Ort</th><th>Rolle</th><th>Zugang</th><th></th></tr></thead><tbody>';
    $orte = ['merzenich' => 'Merzenich', 'golzheim' => 'Golzheim', 'girbelsrath' => 'Girbelsrath', 'morschenich' => 'Morschenich', 'buergewald' => 'Bürgewald'];
    $mit = 0;
    foreach ($vereine as $v) {
        $u = ma_verein_benutzer(ma_verein_kurz($v['name']));
        if ($u) $mit++;
        $weitere = function_exists('ma_verein_redakteure') && !ma_verein_ist_abteilung($v) ? array_filter(ma_verein_redakteure(ma_verein_kurz($v['name'])), fn($x) => !$u || $x->ID !== $u->ID) : [];
        $rolle = ma_verein_rolle($v) === 'ma_sport_partner' ? 'Sport-Partner' : 'Vereins-Partner';
        $zeile = function (WP_User $x) {
            $ein = (string) get_user_meta($x->ID, 'ma_verein_eingeladen', true);
            $gesperrt = function_exists('ma_zugang_gesperrt') && ma_zugang_gesperrt($x->ID);
            return '<a href="' . esc_url(get_edit_user_link($x->ID)) . '">' . esc_html($x->user_login) . '</a>' . ($gesperrt ? ' <strong style="color:#b32d2e">deaktiviert</strong>' : '')
                . '<br><span class="description">' . esc_html($x->user_email) . ($ein !== '' ? ' · eingeladen ' . esc_html($ein) : '') . '</span>'
                . (function_exists('ma_verein_zugang_link') ? '<br><a href="' . esc_url(ma_verein_zugang_link($gesperrt ? 'freigeben' : 'sperren', $x->ID)) . '">' . ($gesperrt ? 'Aktivieren' : 'Deaktivieren') . '</a> · <a href="' . esc_url(ma_verein_zugang_link('passwort', $x->ID)) . '">Passwort-Link senden</a> <span class="description">(nur mit echter Adresse)</span> · <a href="' . esc_url(get_edit_user_link($x->ID) . '#password') . '">Passwort im Profil setzen</a>' : '');
        };
        $status = $u ? $zeile($u) : '<em>noch kein Zugang</em>';
        foreach ($weitere as $w) $status .= '<hr style="margin:6px 0">' . $zeile($w);
        $einladen = '';
        printf('<tr><td>%s%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html($v['name']),
            !empty($v['website']) ? '<br><a class="description" href="' . esc_url($v['website']) . '" target="_blank" rel="noopener">' . esc_html(preg_replace('#^https?://#', '', rtrim($v['website'], '/'))) . '</a>' : '',
            esc_html($orte[$v['ort'] ?? ''] ?? 'gemeindeweit'), esc_html($rolle . (($v['sportart'] ?? '') ? ' · ' . $v['sportart'] : '')), $status, $einladen);
    }
    echo '</tbody></table><p class="description">' . (int) $mit . ' von ' . count($vereine) . ' Vereinen haben einen Zugang. Quelle der Liste: Vereinsverzeichnis der Gemeinde (Bürgerbroschüre November 2025, Amtsblätter, Heimat-Info), Stand 30.09.2026.</p></div>';
}
