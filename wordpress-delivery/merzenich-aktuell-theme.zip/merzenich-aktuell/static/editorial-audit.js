/* Merzenich Aktuell — Editorial QA runtime, 17.09.2026 */
(() => {
  'use strict';

  /* Stilllegung 17.09.2026 — Gewerk 3: Laufzeit-Skripte schreiben kein Markup mehr um.
   * Grund: Der ausgelieferte Stand ist der sichtbare Stand. Wer die Seite ohne
   * JavaScript, mit langsamer Verbindung oder als Suchmaschine liest, muss dasselbe
   * sehen wie alle anderen. Gestaltung, Reihenfolge und Inhalt entstehen deshalb in
   * den Generatoren unter deploy/*.mjs und stehen fertig im HTML.
   * Alles, was hier Markup erzeugt, ersetzt oder umsortiert, haengt an dieser
   * Konstante und bleibt aus. Weiter laufen nur zwei Gruppen:
   *   - Zeitabhaengiges, das ein Generator nicht vorberechnen kann: Uhr und
   *     Tagesdatum (1), abgelaufene Termine (4).
   *   - Bedienung und echte Laufzeitzustaende: Ortsleiste auf- und zuklappen (2b),
   *     totes Wettermodul wegblenden (5), Ladefehler eines Dienstes (6).
   * true setzen ist nur zum Vergleichen gedacht, nicht fuer den Betrieb. */
  const LAUFZEIT_UMBAU = false;

  const q=(s,r=document)=>r.querySelector(s), qa=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const path=location.pathname.replace(/\/+$/,'')||'/';
  const htmlEsc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot',"'":'&#39;'}[c]));
  const bildUrl=src=>/^https?:\/\//i.test(src)?`/api/bild?u=${encodeURIComponent(src)}`:src;

  const symbolbilder={
    sport:'https://commons.wikimedia.org/wiki/Special:FilePath/2026-08-30%20Fu%C3%9Fballplatz%20Trogen%20HOF8480%20RAW-Export.png?width=1600',
    polizei:'https://commons.wikimedia.org/wiki/Special:FilePath/Neue%20Streifenwagen%20f%C3%BCr%20die%20Polizei%20vorgestellt.jpg?width=1600',
    feuerwehr:'https://commons.wikimedia.org/wiki/Special:FilePath/Feuerwehrm%C3%A4nner%20im%20Einsatz.jpg?width=1600',
    rathaus:'https://commons.wikimedia.org/wiki/Special:FilePath/Merzenich%20Rathaus%20HDR.jpg?width=1600',
    leben:'https://commons.wikimedia.org/wiki/Special:FilePath/Merzenich%20Alte%20Pfarrkirche.jpg?width=1600',
    termine:'https://commons.wikimedia.org/wiki/Special:FilePath/Merzenich%20Denkmal-Nr.%2018%2C%20Lindenplatz%20%281235%29.jpg?width=1600'
  };
  function keyForEntry(x){
    const t=`${x?.k||''} ${x?.t||''} ${x?.g||''} ${x?.u||''}`.toLocaleLowerCase('de-DE');
    if(/feuerwehr|brand|lösch|einsatz/.test(t))return'feuerwehr';
    if(/blaulicht|polizei|einbruch|zeugen|verkehr/.test(t))return'polizei';
    if(/sport|fußball|fussball|kreisliga|sc 1919/.test(t))return'sport';
    if(/rathaus|politik|gemeinde|rat/.test(t))return'rathaus';
    if(/termin|veranstaltung|verein/.test(t))return'termine';
    return'leben';
  }
  function placeFromEntry(x){
    const t=`${x?.g||''} ${x?.d||''} ${x?.t||''}`.toLocaleLowerCase('de-DE');
    if(t.includes('bürgewald')||t.includes('buergewald'))return'BÜRGEWALD';
    if(t.includes('morschenich'))return'MORSCHENICH';
    if(t.includes('girbelsrath'))return'GIRBELSRATH';
    if(t.includes('golzheim'))return'GOLZHEIM';
    return'MERZENICH';
  }

  /* 1) Tagesdatum darf nie am Build-Tag hängen bleiben. */
  const berlinParts=()=>new Intl.DateTimeFormat('de-DE',{timeZone:'Europe/Berlin',day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date()).reduce((o,p)=>(o[p.type]=p.value,o),{});
  function refreshClock(){
    const p=berlinParts(), short=`${p.day}.${p.month}.`, full=`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:00+02:00`;
    qa('[data-today]').forEach(el=>{el.textContent=short;el.setAttribute('datetime',full)});
    qa('[data-clock]').forEach(el=>{el.textContent=`${p.hour}:${p.minute} Uhr`;el.setAttribute('datetime',full)});
  }
  refreshClock(); setInterval(refreshClock,60000);

  /* 2) Hauptnavigation auf sechs redaktionelle Ziele reduzieren. */
  function simplifyNav(){
    qa('.mainnav').forEach(nav=>{
      const row=q('.navscroll',nav), more=q('.more-links',nav); if(!row||!more)return;
      const wanted=['/nachrichten/','/blaulicht/','/sport/','/leben/','/rathaus/','/termine/'];
      const labels={'/nachrichten/':'Aktuell','/blaulicht/':'Blaulicht','/sport/':'Sport','/leben/':'Leben','/rathaus/':'Rathaus','/termine/':'Termine'};
      const byHref=new Map(qa(':scope > a',row).map(a=>[a.getAttribute('href'),a]));
      wanted.forEach(h=>{const a=byHref.get(h);if(a){a.textContent=labels[h];row.append(a)}});
      qa(':scope > a',row).filter(a=>!wanted.includes(a.getAttribute('href'))).forEach(a=>{
        const h=a.getAttribute('href'); if(!q(`a[href="${CSS.escape(h)}"]`,more)) more.prepend(a); else a.remove();
      });
    });
  }
  /* Stillgelegt: Die Ressortleiste ist Gestaltung. Welche sechs Ziele oben stehen,
   * wie sie heissen und was unter "Mehr" wandert, gehoert in den Generator, der die
   * Kopfzeile schreibt (deploy/kopf-theme-einbinden.mjs). Ein Umbau nach dem Laden
   * laesst die Navigation sichtbar springen. */
  if (LAUFZEIT_UMBAU) simplifyNav();

  /* 2b) Die Ortswahl kommt seit 20.09. fertig aus deploy/inhaltsindex.mjs:
   * ein <details> mit den echten Meldungszahlen, das ohne JavaScript
   * funktioniert. Der frueher hier gebaute Toggle ist ersatzlos entfallen. */

  /* 3) Homepage: ein Content-Index, ein Hero und bebilderte Nebenmeldungen. */
  async function verifiedHomepage(){
    if(path!=='/')return;
    const grid=q('.frontpage-grid'); if(!grid)return;
    try{
      const [editorial,index]=await Promise.all([
        fetch('/api/editorial-current.json',{cache:'no-store'}).then(r=>{if(!r.ok)throw new Error('editorial');return r.json()}),
        fetch('/suche-index.json',{cache:'no-store'}).then(r=>{if(!r.ok)throw new Error('index');return r.json()})
      ]);
      if(!Array.isArray(index)||!editorial?.hero)return;
      const urls=new Set(index.map(x=>x.u));
      const hero=editorial.hero;if(!urls.has(hero.url))return;
      const secondary=index.filter(x=>x?.u&&x?.t&&urls.has(x.u)&&x.u!==hero.url).slice(0,4);
      const heroKey=keyForEntry(hero);
      const heroLogo=hero.imageFit==='contain'||/(logo|wappen|vereinslogo|crest)/i.test(`${hero.image||''} ${hero.imageAlt||''}`);
      const heroSrc=heroLogo?symbolbilder[heroKey]:(hero.image||symbolbilder[heroKey]);
      const heroBadge=heroLogo?'Symbolbild':hero.imageBadge;
      const image=heroSrc?`<a class="front-lead-media" href="${htmlEsc(hero.url)}" tabindex="-1" aria-hidden="true"><div class="media"><img src="${htmlEsc(bildUrl(heroSrc))}" alt="${htmlEsc(heroLogo?'Symbolbild zur Meldung':(hero.imageAlt||hero.title))}" loading="eager" fetchpriority="high" data-editorial-image>${heroBadge?`<span class="badge">${htmlEsc(heroBadge)}</span>`:''}</div></a>`:'';
      const next=`${image}<div class="front-lead-copy"><div class="location-line"><span class="location-brand">${htmlEsc(hero.location||'MERZENICH')}</span></div><span class="kicker">${htmlEsc(hero.kicker||'Aktuell')}</span>${hero.eyebrow?`<span class="eyebrow">${htmlEsc(hero.eyebrow)}</span>`:''}<h1><a href="${htmlEsc(hero.url)}">${htmlEsc(hero.title)}</a></h1><p>${htmlEsc(hero.teaser||'')}</p><div class="meta"><time datetime="${htmlEsc(hero.published||'')}">${htmlEsc(hero.timeLabel||'')}</time>${hero.readTime?`<span>${htmlEsc(hero.readTime)}</span>`:''}</div><div class="story-actions"><a class="read-more" href="${htmlEsc(hero.url)}">Mehr lesen</a></div></div>`;
      const sides=secondary.map(x=>{
        const img=bildUrl(symbolbilder[keyForEntry(x)]||symbolbilder.leben);
        return `<article class="front-brief"><a class="front-brief-media" href="${htmlEsc(x.u)}" tabindex="-1" aria-hidden="true"><div class="media"><img src="${htmlEsc(img)}" alt="" loading="lazy" decoding="async" data-editorial-image></div></a><div><div class="location-line"><span class="location-brand">${placeFromEntry(x)}</span></div><span class="kicker">${htmlEsc(x.k||'Aktuell')}${x.dt?` · ${htmlEsc(String(x.dt).replace(/\.\.$/,'.'))}`:''}</span><h2><a href="${htmlEsc(x.u)}">${htmlEsc(x.t)}</a></h2><p>${htmlEsc(x.d||'')}</p><div class="story-actions"><a class="read-more" href="${htmlEsc(x.u)}">Mehr lesen</a></div></div></article>`;
      }).join('');
      const current=q('.front-lead h1',grid)?.textContent?.trim();
      if(current===hero.title&&grid.dataset.editorialVerified==='1'&&qa('.front-brief .media img',grid).length===secondary.length)return;
      grid.innerHTML=`<article class="front-lead" data-story="${htmlEsc(hero.id||'')}" data-editorial-verified="1">${next}</article><div class="front-side"><span class="front-side-title">Weitere aktuelle Meldungen</span>${sides}</div>`;
      grid.dataset.editorialVerified='1';
    }catch(e){/* stabiles ausgeliefertes HTML bleibt Fallback */}
  }
  /* Stillgelegt: Das Startseitenraster wird von deploy/inhaltsindex.mjs gebaut und
   * steht vollstaendig im ausgelieferten HTML. Ein zweiter Aufbau per innerHTML nach
   * dem Laden verwirft die fertigen Bilder samt Bildnachweis, verliert die
   * Symbolbild-Kennzeichnung und erzeugt einen sichtbaren Sprung. Der
   * MutationObserver hat diesen Neubau zusaetzlich gegen fremde Layer verteidigt und
   * faellt mit weg — ohne Umbau gibt es nichts zu verteidigen. */
  if(LAUFZEIT_UMBAU && path==='/'){
    verifiedHomepage();
    const grid=q('.frontpage-grid');
    if(grid&&'MutationObserver' in window){
      let timer=0;const obs=new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(()=>verifiedHomepage(),50)});
      obs.observe(grid,{childList:true,subtree:true});setTimeout(()=>obs.disconnect(),6500);
    }
  }

  /* 4) Vergangene Termine verschwinden aus „Heute / nächste Tage“, nicht aus Archiven. */
  function expireAgenda(){
    const now=Date.now();
    qa('[data-event-end]').forEach(el=>{if(el.closest('.past'))return;const end=Date.parse(el.getAttribute('data-event-end')||'');if(Number.isFinite(end)&&end<now)el.remove()});
    if(path==='/termine'){
      const p=berlinParts(),startToday=Date.parse(`${p.year}-${p.month}-${p.day}T00:00:00+02:00`);
      qa('.event-list article,.event-list .event-row,.events-grid article').forEach(el=>{if(el.closest('.past'))return;const t=q('time[datetime]',el);if(!t)return;const d=Date.parse(t.getAttribute('datetime'));if(Number.isFinite(d)&&d<startToday&&!el.hasAttribute('data-event-end'))el.setAttribute('data-editorial-hidden','1')});
    }
  }
  expireAgenda();

  /* 5) Tote Wettermodule beanspruchen keinen prominenten Platz. */
  function suppressDeadWeather(){
    qa('[data-weather], [data-weather-mini], .weather, .weather-box, .weather-card').forEach(el=>{
      const txt=(el.textContent||'').toLowerCase();
      if(/nicht verfügbar|nicht verfuegbar|konnte nicht geladen|wetterdaten.*derzeit/.test(txt)){
        const box=el.closest('.service-accordion,.sidebox,.weather-box,.weather-card')||el;box.setAttribute('data-editorial-hidden','1');
      }
    });
  }
  suppressDeadWeather();setTimeout(suppressDeadWeather,2200);setTimeout(suppressDeadWeather,7000);

  /* 6) Ladefehler bekommen einen echten Zustand. */
  setTimeout(()=>{
    if(path!=='/diskussion')return;
    qa('main p, main div').forEach(el=>{if(el.children.length)return;if(!/^\s*(wird geladen|die diskussion wird geladen)[….\.]*\s*$/i.test(el.textContent||''))return;const box=document.createElement('div');box.className='editorial-error';box.innerHTML='<h2>Inhalt konnte nicht geladen werden</h2><p>Die Verbindung zum Dienst ist gerade nicht verfügbar. Die übrige Website funktioniert weiter.</p><button type="button">Erneut versuchen</button>';q('button',box).addEventListener('click',()=>location.reload());el.replaceWith(box)});
  },8000);

  /* 7) Leeres Menschen-Ressort zeigt keine fachfremden Fallbacks.
   * Stillgelegt: Der Leerzustand ist redaktioneller Inhalt mit Ueberschrift, Text und
   * drei Verweisen. Er gehoert in die Ressortseite selbst, nicht in ein Skript, das
   * den Feed nach dem Laden per innerHTML ersetzt. */
  if(LAUFZEIT_UMBAU && path==='/menschen'){
    const count=q('.count-line');
    if(count&&/^\s*0\s+Meldung/.test(count.textContent||'')){const feed=q('.feed');if(feed)feed.innerHTML='<div class="editorial-empty"><h2>Menschen & Familien aus der Gemeinde</h2><p>Hier erscheinen veröffentlichte Jubiläen, Hochzeiten, Ehrungen, Nachrufe und Porträts. Solange keine redaktionell bestätigten Meldungen vorliegen, zeigen wir keine fachfremden Ersatzartikel.</p><div class="editorial-empty-actions"><a href="/familienanzeigen/">Familienanzeigen</a><a href="/traueranzeigen/">Traueranzeigen</a><a href="/meldung-senden/">Meldung einsenden</a></div></div>'}
  }

  /* 8) Themenübersicht: Top-Themen statt CMS-Wolke.
   * Stillgelegt: Sortierung nach Haeufigkeit und die Grenze bei 20 Themen sind
   * Gestaltungsentscheidungen. Sie gehoeren in deploy/thema-prerender.mjs, das die
   * Themenseite ohnehin schreibt. Der Aufklapper waere Bedienung, haengt hier aber am
   * Umbau: Ohne vorgerendertes Markup gibt es nichts zu bedienen. */
  if(LAUFZEIT_UMBAU && path==='/thema'){
    const cloud=q('.tagcloud');if(cloud){const links=qa(':scope > a',cloud);links.sort((a,b)=>{const n=x=>Number((q('small',x)?.textContent||'0').replace(/\D/g,''))||0;return n(b)-n(a)||a.textContent.localeCompare(b.textContent,'de')}).forEach((a,i)=>{cloud.append(a);if(i>=20)a.dataset.editorialExtra='1'});if(links.length>20){cloud.classList.add('is-collapsed');const btn=document.createElement('button');btn.type='button';btn.className='editorial-topic-toggle';btn.textContent='Alle Themen A–Z anzeigen';btn.addEventListener('click',()=>{const closed=cloud.classList.toggle('is-collapsed');btn.textContent=closed?'Alle Themen A–Z anzeigen':'Top-Themen anzeigen'});cloud.after(btn)}}
  }

  /* 9) Ortsseiten: News zuerst, Ortsporträt danach. */
  const placePaths=['/merzenich','/golzheim','/girbelsrath','/morschenich','/buergewald'];
  /* Stillgelegt: Die Reihenfolge "News zuerst, Ortsportraet danach" ist Gestaltung und
   * muss schon im ausgelieferten HTML stimmen. Ein Verschieben nach dem Laden laesst
   * die Seite umspringen. Die angehaengte Zeile "zuletzt aktualisiert" nannte zudem
   * immer den Abruftag, nicht den Tag der letzten redaktionellen Aenderung — das ist
   * keine echte Angabe und darf so nicht zurueckkommen. */
  if(LAUFZEIT_UMBAU && placePaths.includes(path)){
    const main=q('main'),intro=q('.place-intro',main),news=q(':scope > section.section',main);
    if(intro&&news){news.after(intro);intro.classList.add('editorial-place-portrait');const p=berlinParts(),count=q('.page-head .count-line',main);if(count&&!q('.editorial-updated',count)){const span=document.createElement('span');span.className='editorial-updated';span.textContent=` · zuletzt aktualisiert ${p.day}.${p.month}.${p.year}`;count.append(span)}}
  }

  /* 10) Interne Projekttexte gehören nicht in Artikelseiten.
   * Stillgelegt: Ein Satz, der im Browser gegen einen anderen getauscht wird, steht
   * falsch in der Quelle. Der richtige Wortlaut gehoert in die Artikelvorlage. */
  if(LAUFZEIT_UMBAU) qa('.author-box p,.info-prose p').forEach(p=>{if((p.textContent||'').includes('Namentlich gezeichnete Beiträge folgen, sobald das Team steht'))p.textContent=(p.textContent||'').replace('Namentlich gezeichnete Beiträge folgen, sobald das Team steht.','Beiträge werden redaktionell geprüft und transparent gekennzeichnet.')});

  /* 11) Öffentlich sichtbare Redaktion nutzt eine Markenadresse.
   * Stillgelegt: Eine Kontaktadresse, die erst im Browser umgeschrieben wird, steht in
   * der ausgelieferten Seite falsch — Mailprogramme, Kopieren und Suchmaschinen sehen
   * die alte. Die richtige Adresse gehoert in die Quellseiten. */
  if(LAUFZEIT_UMBAU && ['/kontakt','/redaktion','/ueber-uns','/meldung-senden'].includes(path))qa('a[href="mailto:info@kbs-management.tv"]').forEach(a=>{a.href='mailto:redaktion@merzenich-aktuell.de';a.textContent='redaktion@merzenich-aktuell.de'});
})();
