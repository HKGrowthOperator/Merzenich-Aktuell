<?php
/**
 * Theme 21: WordPress sieht aus wie die statische Seite (30.09.2026).
 *
 * Kopf, Fuß und die Service-Blöcke der Startseite kommen als Vorlagen aus der
 * gebauten Seite (deploy/wp-theme.mjs -> vorlagen/*.html). Die Nachrichten
 * (Bühne, Rubrikflächen, Listen, Artikel) setzt WordPress aus seinen Beiträgen
 * in genau dem Markup, das deploy/inhaltsindex.mjs und deploy/meldungen.mjs
 * erzeugen, damit dieselben Stylesheets greifen.
 *
 * Stylesheets, Skripte, Schriften und Bilder der statischen Seite liegen im
 * Theme unter static/ (beim Paketbau aus chatgpt-site/assets kopiert) und
 * werden unter /assets/ ausgeliefert (Rewrite in .htaccess). Fehlt eine Datei,
 * antwortet PHP aus der Mediathek oder holt sie einmal aus dem Repository und legt
 * sie hier ab (ma21_asset); das Ressort-Menü wird aus den eigenen Beiträgen gefüllt.
 */
if (!defined('ABSPATH')) { exit; }

// Ausbaustufe: ausgeblendete Funktionen bleiben gespeichert und sind einzeln einschaltbar (15.10.2026).
require_once __DIR__ . '/ausbau.php';

const MA21_ORTE = ['merzenich' => 'Merzenich', 'golzheim' => 'Golzheim', 'girbelsrath' => 'Girbelsrath', 'morschenich' => 'Morschenich', 'buergewald' => 'Bürgewald'];
const MA21_RESSORT = ['blaulicht' => 'Blaulicht', 'sport' => 'Sport', 'rathaus' => 'Rathaus & Politik', 'leben' => 'Leben', 'wirtschaft' => 'Wirtschaft', 'menschen' => 'Menschen', 'vereine' => 'Vereine', 'tipp' => 'Tipp'];
// Bildhinweis je Bildtyp: auf der Startseite (knapp) und in Listen/Artikeln.
const MA21_HINWEIS_START = ['symbol' => 'Symbolbild', 'place' => 'Ortsansicht', 'original' => '', 'official' => 'Bild: Quelle', 'licensed' => 'Archivbild'];
const MA21_HINWEIS = ['symbol' => 'Symbolbild', 'place' => 'Ortsansicht', 'original' => 'Originalbild', 'official' => 'Quellenmotiv', 'licensed' => 'Archivbild'];

/**
 * sizes-Angaben der Bildkarten (02.10.2026), gemessen an den gerenderten
 * Breiten bei 390/560/760/1100/1280/1440 px. Dieselbe Tabelle steht in
 * deploy/lib-artikel.mjs (SIZES) fuer die statische Seite. Vorher stammten die
 * Werte aus Schaetzungen; das Handy lud etwa fuer ein 120-px-Vorschaubild die
 * Breite 100vw (Lighthouse „uses-responsive-images“, rund 2 MB je Seite).
 */
const MA21_SIZES = [
    'xl' => '(max-width: 1099px) 100vw, (max-width: 1439px) 62vw, 845px',
    'r' => '(max-width: 759px) 132px, (max-width: 1099px) 46vw, (max-width: 1439px) 31vw, 411px',
    'u' => '(max-width: 759px) 132px, (max-width: 1439px) 31vw, 411px',
    'l' => '(max-width: 759px) 100vw, (max-width: 1099px) 46vw, (max-width: 1439px) 34vw, 468px',
    'l-vereine' => '(max-width: 759px) 100vw, (max-width: 1439px) 46vw, 624px',
    'l-blaulicht' => '(max-width: 759px) 100vw, (max-width: 1099px) 46vw, (max-width: 1439px) 55vw, 749px',
    'l-blaulicht-klein' => '(max-width: 759px) 100vw, (max-width: 1099px) 46vw, 132px',
    'l-rathaus' => '(max-width: 759px) 100vw, (max-width: 1099px) 46vw, (max-width: 1439px) 18vw, 241px',
    'l-wirtschaft' => '(max-width: 759px) 100vw, (max-width: 1099px) 46vw, (max-width: 1439px) 18vw, 240px',
    'm' => '(max-width: 559px) 100vw, (max-width: 759px) 45vw, (max-width: 1099px) 30vw, (max-width: 1439px) 22.5vw, 307px',
    'm-blaulicht' => '(max-width: 559px) 100vw, (max-width: 759px) 45vw, (max-width: 1099px) 30vw, 132px',
    'm-rathaus' => '(max-width: 559px) 100vw, (max-width: 759px) 45vw, (max-width: 1099px) 30vw, (max-width: 1439px) 31vw, 411px',
    'm-vereine' => '(max-width: 559px) 100vw, (max-width: 759px) 45vw, (max-width: 1099px) 30vw, (max-width: 1439px) 31vw, 411px',
    'm-wirtschaft' => '(max-width: 559px) 100vw, (max-width: 759px) 45vw, (max-width: 1099px) 30vw, (max-width: 1439px) 18vw, 240px',
    's' => '(max-width: 759px) 112px, 220px',
    's-vereine' => '(max-width: 759px) 112px, (max-width: 1099px) 220px, 200px',
    'feed-lead' => '(max-width: 1099px) 120px, (max-width: 1439px) 30.5vw, 419px',
    'feed-row' => '(max-width: 1099px) 120px, (max-width: 1439px) 210px, 240px',
    'news-card' => '(max-width: 1099px) 120px, (max-width: 1439px) 30vw, 405px',
    'raster' => '(max-width: 559px) 132px, (max-width: 1099px) 46vw, (max-width: 1279px) 31vw, 300px',
    'ressort-raster' => '(max-width: 520px) 132px, (max-width: 1099px) 46vw, 420px',
    'unternehmen' => '(max-width: 1099px) 100vw, (max-width: 1439px) 32vw, 450px',
    'figur' => '(max-width: 1099px) 100vw, 720px',
];
/** sizes einer Sektionskarte: Blaulicht, Rathaus und Wirtschaft ordnen ab 1100 px anders an (startseite.css). */
function ma21_sizes(string $g, string $sektion = '', int $i = 0): string {
    if ($g === 'l' && $sektion === 'blaulicht') return $i === 0 ? MA21_SIZES['l-blaulicht'] : MA21_SIZES['l-blaulicht-klein'];
    return MA21_SIZES["{$g}-{$sektion}"] ?? MA21_SIZES[$g] ?? '';
}

/* ------------------------------------------------------------ Vorlagen */

/** Vorlage aus vorlagen/ lesen (von deploy/wp-theme.mjs erzeugt). */
function ma21_vorlage(string $name): string {
    static $cache = [];
    if (!isset($cache[$name])) {
        $pfad = get_template_directory() . '/vorlagen/' . $name;
        $cache[$name] = ma21_adressen_wp(is_readable($pfad) ? (string) file_get_contents($pfad) : '');
    }
    return $cache[$name];
}

/**
 * Adressen der statischen Seite, die WordPress anders führt (21.13.0). Bis dahin
 * lief jeder Klick darauf über eine 301-Umleitung (Vollprüfung 06.10.2026:
 * Ortsteile im Kopf und auf der Startseite, Suche, Termin melden, SC 1919).
 */
function ma21_adressen_wp(string $html): string {
    $html = (string) preg_replace('#href="/(merzenich|golzheim|girbelsrath|morschenich|buergewald)/(?=[\#"?])#', 'href="/ort/$1/', $html);
    return strtr($html, [
        'href="/suche/"' => 'href="/?s="',
        'href="/termine/melden/' => 'href="/termin-melden/',
        'href="/sc-1919-merzenich/' => 'href="/vereine/sc-1919-merzenich/',
        // Fuß: „Redaktion“ führte doppelt auf /ueber-uns/.
        'href="/ueber-uns/">Redaktion</a>' => 'href="/redaktion/">Redaktion</a>',
    ]);
}

/** Kopf-Assets: Icons, Schrift-Preloads und das CSS-Buendel (deploy/css-bundle.mjs). bundle-start.css nur auf der Startseite, bundle.css sonst; die Vorlage traegt beide (data-ma-css, deploy/wp-theme.mjs). */
function ma21_kopf_assets(): string {
    $weg = is_front_page() ? 'seite' : 'start';
    $html = (string) preg_replace('/<link rel="stylesheet"[^>]*data-ma-css="' . $weg . '"[^>]*>\n?/', '', ma21_vorlage('kopf-assets.html'));
    // Symbole (21.12.0): die Links der statischen Seite durch die eigenen ersetzen.
    $html = (string) preg_replace('#<link rel="(?:icon|apple-touch-icon|manifest)"[^>]*>\n?#', '', $html);
    return ma21_symbol_links() . $html;
}

/* LCP-Bild vorladen (wp_head, frueh): Aufmacher der Startseite, Bild einer Meldung oder eines Vereinsprofils, mit denselben srcset/sizes wie das <img>. */
add_action('wp_head', function (): void {
    $b = null; $sizes = '';
    if (is_front_page()) { $a = ma21_startseite_belegung()['aufmacher'] ?? null; if ($a instanceof WP_Post) { $b = ma21_bild($a); $sizes = MA21_SIZES['xl']; } }
    elseif (is_singular(['post', 'ma_club'])) { $p = get_queried_object(); if ($p instanceof WP_Post) { $b = ma21_bild($p); $sizes = MA21_SIZES['figur']; } }
    if (!$b || !ma21_echtes_bild($b)) return;
    echo '<link rel="preload" as="image" href="' . esc_url($b['src']) . '"' . ($b['srcset'] ? ' imagesrcset="' . esc_attr($b['srcset']) . '" imagesizes="' . esc_attr($sizes) . '"' : '') . ' fetchpriority="high">' . "\n";
}, 2);

/**
 * Kopf (Masthead). Der Platzhalter {{ma:datum}} (deploy/wp-theme.mjs) wird in
 * Ortszeit gefüllt. Seit 21.9.9 kommt auch der Rest aus WordPress statt aus dem
 * Stand der Vorlage: die Ausgabe-Wahl (Adressen /ort/…/, keine Umleitung mehr,
 * seit 21.10.2 ohne Zahlen), die Zeile „Merzenich · Jetzt“ mit der jüngsten
 * veröffentlichten Meldung und dem nächsten Termin, und die Markierung der gerade besuchten Seite im Menü.
 * (Vorher zeigte die Zeile einen Entwurf, der für Leser ein 404 war.)
 */
/** Menü im Kopf: erst die Ausbaustufe (Vereine weg oder sichtbar, inc/ausbau.php), dann die Markierung der besuchten Seite. */
function ma21_kopf_menue(string $html): string {
    return ma21_kopf_aktuell(ma21_ausbau_html($html));
}

function ma21_kopf(string $name): string {
    $datum = '<time data-today datetime="' . esc_attr((string) wp_date('c')) . '">' . esc_html((string) wp_date('d.m.')) . '</time>';
    $html = str_replace('{{ma:datum}}', $datum, ma21_vorlage($name));
    $d = ma21_kopf_daten();
    $html = ma21_kopf_menue($html);
    $html = ma21_kopf_ortswahl($html);
    if ($name === 'kopf.html') $html = ma21_kopf_logo_h1($html);
    if (function_exists('ma21_heute_links')) $html = ma21_heute_links($html, 'kopf');
    return ma21_kopf_jetzt($html, $d);
}

/**
 * Startseite: Das Logo ist die eine H1 (21.17.0), mit dem Alt-Text „Merzenich
 * Aktuell – Nachrichten aus der Gemeinde Merzenich“. Bis 21.16 war die
 * Überschrift des Aufmachers die H1; Google las als Hauptüberschrift der
 * Startseite also die jeweils oberste Meldung. Der Aufmacher ist jetzt eine H2
 * (ma21_karte, Größe xl). Unterseiten haben ihre eigene H1 und behalten den
 * Logo-Link ohne Überschrift (kopf-seite.html).
 */
function ma21_kopf_logo_h1(string $html): string {
    return (string) preg_replace('#<a class="logo" href="/" aria-label="[^"]*"><img ([^>]*?)alt="Merzenich Aktuell"([^>]*)></a>#u',
        '<h1 class="logo-h1"><a class="logo" href="/"><img $1alt="Merzenich Aktuell – Nachrichten aus der Gemeinde Merzenich"$2></a></h1>', $html, 1);
}

/** Zahlen und Meldungen für den Kopf, 10 Minuten zwischengespeichert (Reset bei jeder Statusänderung von Meldungen und Terminen). */
function ma21_kopf_daten(): array {
    $d = get_transient('ma21_kopf_daten');
    if (is_array($d) && isset($d['daten'], $d['ohne_zahlen'])) return $d;
    // Keine Zahlen auf der Seite (Vorgabe Betreiber 05.10.2026: „wie viele Meldungen es gibt, ist unprofessionell“).
    $d = ['ohne_zahlen' => true, 'neu' => null, 'daten' => [], 'termin' => null];
    // Anzeigen (gesponserte Firmenbeiträge) stehen nicht als „Neu“ im Kopf.
    $neueste = get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1, 'orderby' => 'date', 'order' => 'DESC',
        'meta_query' => [['key' => 'ma_gesponsert', 'compare' => 'NOT EXISTS']]]);
    foreach ($neueste as $i => $p) {
        $iso = (string) get_post_time('c', false, $p);
        $d['daten'][] = $iso;
        if ($i === 0) $d['neu'] = ['iso' => $iso, 'zeit' => ma21_zeit_text($p), 'url' => wp_make_link_relative(get_permalink($p)), 'titel' => html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8')];
    }
    $jetzt = (string) current_time('Y-m-d\TH:i');
    $t = get_posts(['post_type' => 'ma_event', 'post_status' => 'publish', 'posts_per_page' => 1, 'meta_key' => 'ma_event_start', 'orderby' => 'meta_value', 'order' => 'ASC',
        'meta_query' => [['key' => 'ma_event_start', 'value' => $jetzt, 'compare' => '>=']]]);
    if ($t) {
        // Beginn steht als Ortszeit ohne Zone in ma_event_start; strtotime() hätte sie als UTC gelesen (zwei Stunden zu spät).
        $p = $t[0];
        try { $start = (new DateTimeImmutable((string) get_post_meta($p->ID, 'ma_event_start', true), wp_timezone()))->getTimestamp(); } catch (Exception $e) { $start = 0; }
        $wann = $start ? wp_date('d.m.', $start) . (wp_date('H:i', $start) !== '00:00' ? ', ' . wp_date('H:i', $start) . ' Uhr' : '') : '';
        $d['termin'] = ['url' => wp_make_link_relative(get_permalink($p)), 'titel' => html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8'), 'wann' => $wann];
    }
    set_transient('ma21_kopf_daten', $d, 10 * MINUTE_IN_SECONDS);
    return $d;
}
add_action('transition_post_status', function (string $neu, string $alt, WP_Post $p): void {
    if (in_array($p->post_type, ['post', 'ma_event'], true) && ($neu === 'publish' || $alt === 'publish')) delete_transient('ma21_kopf_daten');
}, 10, 3);

/** Welche Seite gerade besucht wird: nur dieser Menüpunkt trägt aria-current (die Vorlage markiert immer „Aktuell“). */
function ma21_kopf_aktuell(string $html): string {
    $html = str_replace(' aria-current="page"', '', $html);
    $pfad = '/' . trim((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH), '/') . '/';
    if ($pfad === '//') $pfad = '/';
    // Startseite: der Home-Knopf links neben „Aktuell“ (Wunsch Betreiber 15.10.2026).
    // Nur die echte Startseite, nicht Suche (/?s=), Vorschau oder Blätterseiten mit Pfad „/“.
    if ($pfad === '/') {
        $start = !function_exists('is_front_page') || (is_front_page() && !is_search() && !is_paged());
        return $start ? str_replace('<a class="nav-home" href="/"', '<a class="nav-home" href="/" aria-current="page"', $html) : $html;
    }
    if (is_singular('post')) { $o = get_queried_object(); if ($o instanceof WP_Post) $pfad = (function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($o) && get_post_meta($o->ID, 'ma_business_id', true)) ? '/unternehmen/' : '/' . ma21_ressort($o)[0] . '/'; }
    // Unternehmenskanäle und Musterbeiträge (inc/unternehmen.php) gehören zu „Unternehmen“.
    elseif (str_starts_with($pfad, '/unternehmen/')) $pfad = '/unternehmen/';
    // Sammelseiten der roten Menütitel gehören zu ihrem Ressort.
    elseif (str_starts_with($pfad, '/rubrik/')) { $rs = ma21_rubrik((string) (explode('/', trim($pfad, '/'))[1] ?? '')); if ($rs) $pfad = (string) $rs['ressort']; }
    // Themenseiten aus dem Menü (Blaulicht › Feuerwehr, Polizei) ebenso.
    elseif (str_starts_with($pfad, '/thema/')) { $rs = ma21_thema_ressort((string) (explode('/', trim($pfad, '/'))[1] ?? '')); if ($rs) $pfad = (string) $rs['ressort']; }
    elseif (is_singular('ma_event') || is_post_type_archive('ma_event')) $pfad = '/termine/';
    elseif (is_singular('ma_club') || is_post_type_archive('ma_club')) $pfad = '/vereine/';
    if (!preg_match('#^/[a-z0-9-]+/$#', $pfad)) return $html;
    return str_replace('<a href="' . $pfad . '">', '<a href="' . $pfad . '" aria-current="page">', $html);
}

/**
 * Ausgabe-Wahl oben im Kopf entfällt (Vorgabe Betreiber 05.10.2026: alle fünf
 * Orte sind Ortsteile der Gemeinde Merzenich; sie stehen weiter im Mehr-Menü,
 * in der Schublade und im Fuß). Ortslinks zeigen auf /ort/<slug>/, auf einer
 * Ortsseite ist ihr Ort markiert. Unterseiten ohne Jetzt-Zeile verlieren die
 * dann leere Leiste ganz.
 */
function ma21_kopf_ortswahl(string $html): string {
    $html = (string) preg_replace('#<details class="ortswahl-schalter">.*?</details>#su', '', $html);
    $html = (string) preg_replace('#<nav class="ortswahl"[^>]*><div class="shell">\s*</div></nav>#u', '', $html);
    $html = str_replace('<nav class="ortswahl" aria-label="Ausgabe waehlen">', '<nav class="ortswahl" aria-label="Merzenich jetzt">', $html);
    $html = (string) preg_replace('#href="/(' . implode('|', array_keys(MA21_ORTE)) . ')/"#', 'href="/ort/$1/"', $html);
    $o = is_tax('ma_location') ? get_queried_object() : null;
    if ($o instanceof WP_Term && isset(MA21_ORTE[$o->slug])) $html = str_replace('<a href="/ort/' . $o->slug . '/">', '<a href="/ort/' . $o->slug . '/" aria-current="page">', $html);
    return $html;
}

/** „Merzenich · Jetzt“: jüngste veröffentlichte Meldung und nächster Termin, keine Zahlen (assets/kopf.js macht aus der Uhrzeit eine relative Zeit). */
function ma21_kopf_jetzt(string $html, array $d): string {
    if (!str_contains($html, 'class="jetzt"')) return $html;
    if (!empty($d['neu'])) {
        $neu = '<span class="jetzt-feld jetzt-neu">Neu <time datetime="' . esc_attr($d['neu']['iso']) . '">' . ma21_e($d['neu']['zeit']) . '</time> <a href="' . esc_url($d['neu']['url']) . '">' . ma21_e($d['neu']['titel']) . '</a></span>';
        $html = (string) preg_replace('#<span class="jetzt-feld jetzt-neu">.*?</span>#su', $neu, $html, 1);
    } else {
        $html = (string) preg_replace('#<span class="jetzt-feld jetzt-neu">.*?</span>#su', '<span class="jetzt-feld jetzt-neu" hidden></span>', $html, 1);
    }
    // „Heute n neue Meldungen“ entfällt (keine Zahlen auf der Seite); ohne das Feld rechnet assets/kopf.js auch nichts nach.
    $html = (string) preg_replace('#<span class="jetzt-feld jetzt-heute"[^>]*>(?:[^<]*)</span>#u', '', $html, 1);
    $t = $d['termin'] ?? null;
    $terminHtml = $t ? '<span class="jetzt-feld jetzt-termin">Nächster Termin <a href="' . esc_url($t['url']) . '">' . ma21_e($t['titel']) . '</a>' . ($t['wann'] !== '' ? ' · ' . ma21_e($t['wann']) : '') . '</span>' : '<span class="jetzt-feld jetzt-termin" hidden></span>';
    return (string) preg_replace('#<span class="jetzt-feld jetzt-termin"[^>]*>(?:[^<]*)</span>#u', $terminHtml, $html, 1);
}

/*
 * Zwischenspeicher (21.10.3): Der Server bei IONOS gibt HTML-Seiten eine Stunde
 * Speicherzeit mit (mod_expires), JSON sogar 28 Tage. Browser und der
 * Zwischenspeicher des Hosters zeigten dadurch bis zu eine Stunde alte Seiten:
 * neue Meldungen fehlten, entfernte Angaben standen noch da (05.10.2026).
 * Setzt PHP selbst Cache-Control und Expires, fügt mod_expires nichts hinzu.
 * Seiten: jedes Mal frisch prüfen. Daten: kurze, ausdrückliche Speicherzeit.
 */
function ma21_cache(int $sekunden): void {
    if (headers_sent()) return;
    header('Cache-Control: ' . ($sekunden > 0 ? 'public, max-age=' . $sekunden : 'no-cache, max-age=0, must-revalidate'));
    header('Expires: ' . gmdate('D, d M Y H:i:s', time() + max(0, $sekunden)) . ' GMT');
}
add_action('send_headers', function (): void {
    if (is_admin() || wp_doing_ajax() || wp_doing_cron() || (defined('REST_REQUEST') && REST_REQUEST)) return;
    ma21_cache(0);
});

/**
 * Nur verschlüsselt (21.13.0): http:// lieferte die Seite bis dahin unverschlüsselt aus.
 * Umgeleitet wird nur, wenn die Anfrage sicher unverschlüsselt ist (wie is_ssl(), dazu
 * kein HTTPS-Kennzeichen vom Proxy), damit hinter einem Proxy keine Schleife entsteht.
 */
function ma21_unverschluesselt(array $server): bool {
    if (!empty($server['HTTPS']) && strtolower((string) $server['HTTPS']) !== 'off') return false;
    if (strtolower((string) ($server['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') return false;
    if (strtolower((string) ($server['REQUEST_SCHEME'] ?? '')) === 'https') return false;
    return (string) ($server['SERVER_PORT'] ?? '443') !== '443';
}
add_action('init', function (): void {
    if (PHP_SAPI === 'cli' || wp_doing_cron() || !ma21_unverschluesselt($_SERVER)) return;
    $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
    if (!in_array($host, ['merzenich-aktuell.de', 'www.merzenich-aktuell.de'], true)) return;
    wp_redirect('https://merzenich-aktuell.de' . (string) ($_SERVER['REQUEST_URI'] ?? '/'), 301, 'Merzenich Aktuell');
    exit;
}, 0);

/* Sicherheits-Kopfzeilen (21.13.0). HSTS nur über HTTPS und ohne Subdomains. */
add_action('send_headers', function (): void {
    if (headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), interest-cohort=()');
    if (is_ssl()) header('Strict-Transport-Security: max-age=31536000');
});

/* /assets/ -> Theme-Verzeichnis static/, danach die einmal aus dem Repository
   nachgeladenen Dateien (uploads/ma-assets/assets/); das Ressort-Menü und alles
   Übrige (Poolfotos, Quellen) beantwortet PHP: Mediathek, sonst nachladen. */
add_filter('mod_rewrite_rules', function (string $regeln): string {
    $dir = trailingslashit(get_template_directory()) . 'static/';
    $rel = ltrim(str_replace(ABSPATH, '', $dir), '/');
    $nach = ma21_nachgeladen_verzeichnis() . '/assets/';
    $nachRel = ltrim(str_replace(ABSPATH, '', $nach), '/');
    $block = "# BEGIN Merzenich Aktuell Assets\n<IfModule mod_rewrite.c>\nRewriteEngine On\n"
        // WordPress-Infodateien verraten die Version (21.13.0).
        . "RewriteRule ^(readme\\.html|license\\.txt|wp-config-sample\\.php)$ - [F,L]\n"
        . "RewriteRule ^assets/ressort-menue\\.json$ index.php?ma_asset=ressort-menue.json [L,QSA]\n"
        . "RewriteCond {$dir}$1 -f\nRewriteRule ^assets/(.*)$ {$rel}$1 [L]\n"
        . "RewriteCond {$nach}$1 -f\nRewriteRule ^assets/(.*)$ {$nachRel}$1 [L]\n"
        . "RewriteRule ^assets/(.*)$ index.php?ma_asset=$1 [L,QSA]\n"
        . "</IfModule>\n# END Merzenich Aktuell Assets\n";
    return $block . $regeln;
});

/** Das Repository (Stand von main) als letzte Quelle für Dateien aus chatgpt-site/. */
const MA21_REPO = 'https://raw.githubusercontent.com/HKGrowthOperator/Merzenich-Aktuell/main/chatgpt-site';

// Nach dem Registrieren von Beitragstypen und Taxonomien (init 10), sonst
// liefert get_permalink() für Termine nur ?p= und ma_location fehlt.
add_action('init', function (): void {
    if (!isset($_GET['ma_asset'])) return;
    ma21_asset((string) wp_unslash($_GET['ma_asset']));
}, 50);

/**
 * Fehlende /assets/-Datei: zuerst die Mediathek (ma_image_static_src, alle
 * Poolfotos liegen dort), sonst einmal aus dem Repository holen und hier ablegen.
 * Die Vorschauseite auf Coolify gibt es seit 05.10.2026 nicht mehr; der Browser
 * lädt nichts von GitHub, nur von dieser Domain.
 */
function ma21_asset(string $pfad): void {
    $pfad = '/' . ltrim((string) preg_replace('#/+#', '/', $pfad), '/');
    if ($pfad === '/' || str_contains($pfad, '..') || !preg_match('#^/[\w./@%-]+$#u', $pfad)) { status_header(404); nocache_headers(); exit; }
    if ($pfad === '/ressort-menue.json') ma21_ressort_menue_ausgeben();
    $voll = '/assets' . $pfad;
    $ziel = ma21_asset_lokal($voll);
    if ($ziel === '') $ziel = ma21_asset_nachladen($voll);
    if ($ziel === '') { status_header(404); nocache_headers(); exit; }
    header('Cache-Control: public, max-age=3600');
    wp_redirect($ziel, 302, 'Merzenich Aktuell');
    exit;
}

/** Medium der Mediathek zu einem statischen Pfad (Größenendung -480/-800/… wird ignoriert), sonst leer. */
function ma21_asset_lokal(string $pfad): string {
    if (!preg_match('#^(/assets/[\w./-]+?)(?:-(\d{3,4}))?\.(webp|jpe?g|png)$#i', $pfad, $m)) return '';
    global $wpdb;
    $basis = $m[1]; $breite = (int) ($m[2] ?? 0);
    $ids = $wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'ma_image_static_src' AND meta_value LIKE %s ORDER BY post_id ASC LIMIT 8", $wpdb->esc_like($basis) . '%'));
    foreach ((array) $ids as $id) {
        $src = (string) get_post_meta((int) $id, 'ma_image_static_src', true);
        if (!preg_match('#^' . preg_quote($basis, '#') . '(?:-\d{3,4})?\.(webp|jpe?g|png)$#i', $src)) continue;
        $datei = get_attached_file((int) $id);
        if (!$datei || !file_exists($datei)) continue;
        $groesse = !$breite || $breite > 1024 ? 'full' : ($breite <= 480 ? 'ma-480' : ($breite <= 768 ? 'medium_large' : 'large'));
        $url = wp_get_attachment_image_url((int) $id, $groesse);
        if ($url) return $url;
    }
    return '';
}

/** Ablage der aus dem Repository nachgeladenen Dateien (uploads/ma-assets). */
function ma21_nachgeladen_verzeichnis(): string {
    return trailingslashit((string) wp_upload_dir(null, false)['basedir']) . 'ma-assets';
}

/** Ist der Pfad als nachladbare Datei erlaubt? Nur Medien, Stile, Skripte, Schriften und Daten; nie PHP. */
function ma21_nachladbar(string $voll): bool {
    return (bool) preg_match('#^/assets/[\w./@%-]+\.(webp|jpe?g|png|gif|svg|avif|ico|css|js|json|woff2?|ttf|txt|pdf)$#i', $voll) && !str_contains($voll, '..');
}

/**
 * Holt eine fehlende Datei einmal aus dem Repository und legt sie unter
 * uploads/ma-assets/ ab (danach liefert Apache sie direkt, siehe .htaccess).
 * Rückgabe: ihre Adresse auf dieser Domain oder leer (dann 404). Fehlt die Datei
 * auch im Repository, wird eine Stunde lang nicht erneut gefragt.
 */
function ma21_asset_nachladen(string $voll): string {
    if (!ma21_nachladbar($voll)) return '';
    $ziel = ma21_nachgeladen_verzeichnis() . $voll;
    $url = trailingslashit((string) wp_upload_dir(null, false)['baseurl']) . 'ma-assets' . $voll;
    if (is_file($ziel)) return $url;
    $sperre = 'ma21_fehlt_' . md5($voll);
    if (get_transient($sperre)) return '';
    $r = wp_remote_get(MA21_REPO . $voll, ['timeout' => 10]);
    $body = !is_wp_error($r) && (int) wp_remote_retrieve_response_code($r) === 200 ? (string) wp_remote_retrieve_body($r) : '';
    if ($body === '' || strlen($body) > 15 * MB_IN_BYTES) { set_transient($sperre, 1, HOUR_IN_SECONDS); return ''; }
    if (!wp_mkdir_p(dirname($ziel)) || file_put_contents($ziel, $body) === false) return '';
    return $url;
}

/**
 * Datei aus chatgpt-site/ im Repository (Stand von main), zwischengespeichert;
 * antwortet GitHub nicht, gilt die letzte gute Kopie. Für Daten, die die Kette
 * laufend erneuert (Spielstand, Stellen- und Immobilienmarkt).
 */
function ma21_repo_datei(string $pfad, int $ttl = HOUR_IN_SECONDS): string {
    $schluessel = 'ma21_repo_' . md5($pfad);
    $t = get_transient($schluessel);
    if (is_string($t) && $t !== '') return $t;
    // Abgelaufen, aber eine nicht zu alte Kopie ist da: sofort ausliefern und im Hintergrund
    // (WP-Cron) auffrischen. Vorher wartete der Seitenaufruf bis zu 8 s auf GitHub
    // (Vorführ-Check 15.10.2026: einzelne erste Aufrufe 12 bis 20 s).
    $kopie = (string) get_option($schluessel . '_kopie', '');
    $alter = time() - (int) get_option($schluessel . '_zeit', 0);
    if ($kopie !== '' && $alter < max(3 * $ttl, 3 * HOUR_IN_SECONDS)) {
        set_transient($schluessel, $kopie, 5 * MINUTE_IN_SECONDS);
        if (function_exists('wp_schedule_single_event') && !wp_next_scheduled('ma21_repo_auffrischen', [$pfad, $ttl])) wp_schedule_single_event(time(), 'ma21_repo_auffrischen', [$pfad, $ttl]);
        return $kopie;
    }
    return ma21_repo_holen($pfad, $ttl);
}
/** Datei jetzt aus dem Repository holen; antwortet GitHub nicht, gilt die letzte gute Kopie. */
function ma21_repo_holen(string $pfad, int $ttl): string {
    $schluessel = 'ma21_repo_' . md5($pfad);
    $r = wp_remote_get(MA21_REPO . '/' . ltrim($pfad, '/'), ['timeout' => 8]);
    $body = !is_wp_error($r) && (int) wp_remote_retrieve_response_code($r) === 200 ? (string) wp_remote_retrieve_body($r) : '';
    if ($body !== '') {
        set_transient($schluessel, $body, $ttl);
        update_option($schluessel . '_kopie', $body, false);
        update_option($schluessel . '_zeit', time(), false);
        return $body;
    }
    $kopie = (string) get_option($schluessel . '_kopie', '');
    if ($kopie !== '') set_transient($schluessel, $kopie, 10 * MINUTE_IN_SECONDS);
    return $kopie;
}
add_action('ma21_repo_auffrischen', function ($pfad, $ttl): void { ma21_repo_holen((string) $pfad, (int) $ttl); }, 10, 2);

/**
 * Ressort-Menü (assets/ressort-menue.json, liest ressort-dropdowns.js): rote
 * Titel (punkte) aus der statischen Datei, „Neu im Ressort“ aus den veröffentlichten
 * Beiträgen dieser WordPress-Installation, nie aus dem redaktionellen Stand
 * im Repository (dort stehen auch noch nicht freigegebene Meldungen).
 */
function ma21_ressort_menue_ausgeben(): void {
    $datei = trailingslashit(get_template_directory()) . 'static/ressort-menue.json';
    $d = is_readable($datei) ? json_decode((string) file_get_contents($datei), true) : null;
    if (!is_array($d) || empty($d['ressorts']) || !is_array($d['ressorts'])) { status_header(404); nocache_headers(); exit; }
    $d = ma21_ressort_menue_daten($d);
    header('Content-Type: application/json; charset=utf-8');
    ma21_cache(300);
    echo wp_json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Menüdaten aus der statischen Datei mit dem Stand dieser Installation (testbar ohne Ausgabe). */
function ma21_ressort_menue_daten(array $d): array {
    // Ausbaustufe (inc/ausbau.php): ausgeblendete Ressorts (Vereine) nur mit eingeschaltetem Schalter.
    foreach ($d['ressorts'] as $pfad => $r) {
        $stufe = is_array($r) ? (string) ($r['ausbau'] ?? '') : '';
        if ($stufe !== '' && !ma21_ausbau($stufe)) unset($d['ressorts'][$pfad]);
    }
    $voll = ma21_ausbau('menue_voll');
    foreach ($d['ressorts'] as $pfad => &$r) {
        if (!is_array($r)) continue;
        unset($r['ausbau']);
        $r['neu'] = ma21_menue_neu((string) $pfad, (array) ($r['neu'] ?? []));
        // „Weitere Bildmeldungen“ (mehr) kommen aus der statischen Datei und waren nur gegen deren „neu“ entdoppelt:
        // Fehlt dort ein Entwurf, rückt eine Meldung nach und stand im Sport-Menü zweimal (Vorführ-Check 15.10.2026).
        if (!empty($r['mehr']) && is_array($r['mehr'])) {
            $pfadVon = fn($u) => rtrim((string) parse_url((string) $u, PHP_URL_PATH), '/');
            $schon = array_map(fn($e) => $pfadVon($e['url'] ?? ''), $r['neu']);
            $r['mehr'] = array_values(array_filter($r['mehr'], fn($e) => is_array($e) && !in_array($pfadVon($e['url'] ?? ''), $schon, true)));
            if (!$r['mehr']) unset($r['mehr']);
        }
        // Unternehmen wie Oberberg Aktuell (Auftrag Betreiber 13.10.2026): links die
        // Firmen, beim Überfahren rechts ihre Beiträge; ohne Wahl die neuesten
        // Firmenbeiträge. Die Musteranzeige unter „Für Unternehmen“ entfällt.
        if ($pfad === '/unternehmen/') { unset($r['werbung']); $r['firmen'] = ma21_menue_firmen(); }
        // Nur rote Titel, keine kleinen Unterpunkte (Wunsch Betreiber 15.10.2026).
        $r['punkte'] = ma21_menue_punkte_pruefen((array) ($r['punkte'] ?? []));
        // Volle Fassung mit Unterpunkten und Anzeige (Stand 14.10.2026), gespeichert
        // in „voll“: nur mit eingeschaltetem Schalter „Unterpunkte in den Aufklappmenüs“.
        $gespeichert = is_array($r['voll'] ?? null) ? $r['voll'] : [];
        unset($r['gruppen'], $r['voll']);
        if ($pfad !== '/unternehmen/') unset($r['werbung']);
        if ($voll && $gespeichert) {
            $gruppen = ma21_menue_gruppen_pruefen((array) ($gespeichert['gruppen'] ?? []));
            if ($gruppen) $r['gruppen'] = $gruppen;
            if ($gruppen && (string) ($gespeichert['alle'] ?? '') !== '') $r['alle'] = (string) $gespeichert['alle'];
            if ($gruppen && !empty($gespeichert['werbung']) && $pfad !== '/unternehmen/') $r['werbung'] = true;
        }
    }
    unset($r);
    $d['standWordPress'] = (string) wp_date('c');
    return $d;
}

/**
 * Firmen für das Unternehmen-Menü (ressort-dropdowns.js): echte Kanäle mit
 * Beiträgen, solange es weniger als drei sind dazu die Musterfirmen; je Firma
 * bis zu drei Beiträge. 5 Minuten zwischengespeichert.
 */
function ma21_menue_firmen(): array {
    // _v2 seit 21.19.0: nach dem Update sofort die drei neuen Beispielfirmen, nicht die alte Liste.
    $c = get_transient('ma21_menue_firmen_v2');
    if (is_array($c)) return $c;
    $rel = fn(string $u): string => wp_make_link_relative($u);
    $l = [];
    foreach (ma21_alle_firmen(8) as $f) {
        $l[] = ['name' => $f['name'], 'url' => $rel($f['url']), 'zeile' => $f['zeile'], 'kuerzel' => $f['kuerzel'], 'farbe' => $f['farbe'], 'logo' => $f['logo'], 'muster' => $f['muster'],
            // Kanalbeiträge echter Firmen sind gesponsert (ma_business_beitraege); Bildnachweis mit Lizenzlink.
            'beitraege' => array_map(fn(array $b): array => ['titel' => $b['titel'], 'url' => $rel($b['url']), 'anriss' => $b['anriss'], 'zeit' => $b['zeit'], 'muster' => $b['muster'], 'gesponsert' => !$b['muster'],
                'bild' => ma21_menue_bildnachweis($b['bild'])],
                array_slice($f['beitraege'], 0, 3))];
    }
    set_transient('ma21_menue_firmen_v2', $l, 300);
    return $l;
}
add_action('transition_post_status', function (string $neu, string $alt, WP_Post $p): void {
    if (in_array($p->post_type, ['post', 'ma_business', 'ma_ad'], true) && ($neu === 'publish' || $alt === 'publish')) delete_transient('ma21_menue_firmen_v2');
}, 10, 3);
add_action('updated_user_meta', function ($mid, $uid, $key): void { if ($key === 'ma_business_id') delete_transient('ma21_menue_firmen_v2'); }, 10, 3);
add_action('added_user_meta', function ($mid, $uid, $key): void { if ($key === 'ma_business_id') delete_transient('ma21_menue_firmen_v2'); }, 10, 3);
foreach (['added_post_meta', 'updated_post_meta', 'deleted_post_meta'] as $h) add_action($h, function ($mid, $pid, $key): void { if (in_array($key, ['ma_business_id', 'ma_gesponsert'], true)) delete_transient('ma21_menue_firmen_v2'); }, 10, 3);

/**
 * Rote Titel des Ressort-Menüs (Wunsch Betreiber 15.10.2026): Jeder Titel führt
 * auf alle Meldungen dazu. Ein Thema (/thema/<slug>/) oder eine Sammelseite
 * (/rubrik/<slug>/) fällt weg, solange sie keine veröffentlichte Meldung hat
 * (die Seite wäre leer). Ortsteile zeigen direkt auf /ort/<slug>/, vorgefilterte
 * Termine (/termine/?ort=…) bleiben, wie sie sind.
 */
/**
 * Linkgruppen der vollen Fassung (Ausbaustufe, gespeichert in „voll“): Ortsteile
 * zeigen auf /ort/<slug>/, Themen erst ab einer Meldung, Gruppen ohne Link fallen weg.
 */
function ma21_menue_gruppen_pruefen(array $gruppen, int $mindestens = 1): array {
    $raus = [];
    foreach ($gruppen as $g) {
        if (!is_array($g) || (string) ($g['titel'] ?? '') === '') continue;
        $links = [];
        foreach ((array) ($g['links'] ?? []) as $l) {
            if (!is_array($l) || count($l) < 2) continue;
            $l = [(string) $l[0], (string) $l[1]];
            if (preg_match('#^/(' . implode('|', array_keys(MA21_ORTE)) . ')/$#', $l[1], $m)) $l[1] = '/ort/' . $m[1] . '/';
            if (preg_match('#^/thema/([^/]+)/$#', $l[1], $m)) {
                $t = get_term_by('slug', $m[1], 'post_tag');
                if (!$t || (int) $t->count < $mindestens) continue;
            }
            $links[] = $l;
        }
        if ($links) $raus[] = ['titel' => (string) $g['titel'], 'links' => $links];
    }
    return $raus;
}

function ma21_menue_punkte_pruefen(array $punkte): array {
    $raus = [];
    foreach ($punkte as $p) {
        if (!is_array($p) || (string) ($p['titel'] ?? '') === '' || (string) ($p['href'] ?? '') === '') continue;
        $href = (string) $p['href'];
        if (preg_match('#^/(' . implode('|', array_keys(MA21_ORTE)) . ')/$#', $href, $m)) $href = '/ort/' . $m[1] . '/';
        if (preg_match('#^/thema/([^/]+)/$#', $href, $m)) {
            $t = get_term_by('slug', $m[1], 'post_tag');
            if (!$t || (int) $t->count < 1) continue;
        }
        if (preg_match('#^/rubrik/([^/]+)/$#', $href, $m) && !ma21_rubrik_hat_beitraege($m[1])) continue;
        // Verzeichnisse ohne einen einzigen Eintrag (Branchenbuch „Noch keine Einträge.“) wie leere Themen ausblenden
        // (Vorführ-Check 15.10.2026). Traueranzeigen bleiben: Die Seite verweist auf die Gedenkportale.
        // Familienanzeigen zählen wie auf der Seite nur freigegebene, nicht abgelaufene (ma21_aktive_anzeigen, Review 16.10.2026).
        if ($href === '/betriebe/' && function_exists('wp_count_posts') && (int) (wp_count_posts('ma_business')->publish ?? 0) < 1) continue;
        if ($href === '/familienanzeigen/' && function_exists('ma21_aktive_anzeigen') && !ma21_aktive_anzeigen(['post_type' => 'ma_family_notice', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true])) continue;
        $raus[] = ['titel' => (string) $p['titel'], 'href' => $href];
    }
    return $raus;
}

function ma21_menue_bild(WP_Post $p): ?array {
    $id = (int) get_post_thumbnail_id($p->ID);
    if (!$id) return null;
    $url = wp_get_attachment_image_url($id, 'ma-480');
    if (!$url) return null;
    $typ = (string) (get_post_meta($p->ID, 'ma_image_type', true) ?: get_post_meta($id, 'ma_image_type', true));
    return ['src' => $url, 'alt' => (string) (get_post_meta($id, '_wp_attachment_image_alt', true) ?: get_the_title($id)), 'symbol' => $typ === 'symbol', 'etikett' => $typ === 'place' ? 'Ortsansicht' : ($typ === 'symbol' ? 'Symbolbild' : '')];
}

/** „Neu im Ressort“: Meldungen der Rubrik, alle Meldungen (Aktuell) oder kommende Termine; unbekannte Ressorts behalten die statische Liste. */
function ma21_menue_neu(string $pfad, array $statisch): array {
    $slug = trim($pfad, '/');
    $titel = fn(WP_Post $p): string => html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8');
    if ($slug === 'termine') {
        $jetzt = (string) current_time('Y-m-d\TH:i');
        $l = get_posts(['post_type' => 'ma_event', 'post_status' => 'publish', 'posts_per_page' => 4, 'meta_key' => 'ma_event_start', 'orderby' => 'meta_value', 'order' => 'ASC', 'meta_query' => [['key' => 'ma_event_start', 'value' => $jetzt, 'compare' => '>=']]]);
        return array_map(function (WP_Post $p) use ($titel): array {
            $start = function_exists('ma_event_timestamp') ? (int) ma_event_timestamp($p->ID, 'start') : 0;
            return ['titel' => $titel($p), 'url' => wp_make_link_relative(get_permalink($p)), 'ort' => (string) (get_post_meta($p->ID, 'ma_event_place', true) ?: (MA21_ORTE[ma21_ort($p)] ?? ucfirst(ma21_ort($p)))), 'datum' => $start ? (string) wp_date('c', $start) : (string) get_post_meta($p->ID, 'ma_event_start', true), 'bild' => ma21_menue_bild($p), 'termin' => true];
        }, $l);
    }
    $args = ['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 4, 'orderby' => 'date', 'order' => 'DESC', 'ignore_sticky_posts' => true];
    if ($slug === 'unternehmen') {
        $ids = ma21_unternehmen_ids();
        $echte = $ids ? get_posts($args + ['post__in' => $ids]) : [];
        $neu = array_map(fn(WP_Post $p): array => ['titel' => $titel($p), 'url' => wp_make_link_relative(get_permalink($p)), 'ort' => 'Anzeige · ' . (MA21_ORTE[ma21_ort($p)] ?? ucfirst(ma21_ort($p))), 'datum' => (string) get_post_time('c', false, $p), 'bild' => ma21_menue_bild($p)], $echte);
        return array_slice(array_merge($neu, function_exists('ma21_menue_musterbeitraege') ? ma21_menue_musterbeitraege() : []), 0, 4);
    }
    elseif ($slug !== 'nachrichten') {
        if (!get_category_by_slug($slug)) {
            // Kein Ressort mit eigener Rubrik (z. B. Unternehmen): statische Liste, aber nur Beiträge, die hier veröffentlicht sind.
            return array_values(array_filter($statisch, function ($e): bool {
                if (!is_array($e) || empty($e['url'])) return false;
                $id = url_to_postid(home_url((string) $e['url']));
                return $id > 0 && get_post_status($id) === 'publish';
            }));
        }
        $args['category_name'] = $slug;
    }
    // Anriss nur, wo das Menü Karten mit Text zeigt (Wirtschaft im Unternehmen-Menü).
    $anriss = in_array($slug, ['wirtschaft', 'unternehmen'], true);
    // Gesponserte Beiträge mit „Anzeige“ vor dem Ort (wie die Karten auf den Seiten).
    $anzeige = fn(WP_Post $p): string => function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($p) ? 'Anzeige · ' : '';
    return array_map(fn(WP_Post $p): array => ['titel' => $titel($p), 'url' => wp_make_link_relative(get_permalink($p)), 'ort' => $anzeige($p) . (MA21_ORTE[ma21_ort($p)] ?? ucfirst(ma21_ort($p))), 'datum' => (string) get_post_time('c', false, $p), 'bild' => ma21_menue_bild($p)]
        + ($anriss ? ['anriss' => html_entity_decode(ma21_kurz(ma21_teaser($p), 170), ENT_QUOTES, 'UTF-8')] : []), get_posts($args));
}
add_action('after_switch_theme', function (): void { flush_rewrite_rules(true); });

/* Kopf aufräumen: WordPress-Blockstile und Emoji-Skripte gibt es auf der
   statischen Seite nicht, sie verschieben Abstände. */
add_action('wp_enqueue_scripts', function (): void {
    foreach (['wp-block-library', 'wp-block-library-theme', 'global-styles', 'classic-theme-styles'] as $h) wp_dequeue_style($h);
}, 100);
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

add_filter('body_class', function (array $k): array { $k[] = 'v20'; return $k; });

/* ------------------------------------------------------------ Bausteine */

function ma21_e($s): string { return esc_html((string) $s); }

function ma21_ressort(WP_Post $p): array {
    foreach (get_the_category($p->ID) as $c) {
        if (isset(MA21_RESSORT[$c->slug])) return [$c->slug, MA21_RESSORT[$c->slug]];
    }
    $c = get_the_category($p->ID)[0] ?? null;
    return $c ? [$c->slug, $c->name] : ['nachrichten', 'Nachrichten'];
}

function ma21_ort(WP_Post $p): string {
    $t = get_the_terms($p->ID, 'ma_location');
    if (is_array($t)) foreach ($t as $term) if (isset(MA21_ORTE[$term->slug])) return $term->slug;
    return 'merzenich';
}

/** Ortsmarke: MERZENICH, Ortsteil, Rubrik (Ressort oder Kicker). */
function ma21_marke(WP_Post $p, string $rubrik = 'ressort'): string {
    $ort = ma21_ort($p);
    $label = $rubrik === 'kicker' ? (get_post_meta($p->ID, 'ma_kicker', true) ?: ma21_ressort($p)[1]) : ma21_ressort($p)[1];
    return '<p class="marke"><span class="marke-ort">Merzenich</span>'
        . ($ort !== 'merzenich' ? '<span class="marke-teil"> · ' . ma21_e(MA21_ORTE[$ort]) . '</span>' : '')
        . '<span class="marke-rubrik">' . ma21_e($label) . '</span>'
        // Bezahlte Unternehmenspräsentation (Plugin, werbung-stat.php): immer gekennzeichnet.
        . (function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($p) ? '<span class="gesponsert">Anzeige · Gesponsert</span>' : '') . '</p>';
}

function ma21_zeit(WP_Post $p, bool $lang = false): string {
    return '<time datetime="' . esc_attr(get_post_time('c', false, $p)) . '">' . ma21_e(ma21_zeit_text($p, $lang)) . '</time>';
}

/** „05.10. · 14:30 Uhr“; Meldungen ohne bekannte Uhrzeit (00:00, aus der Quelle nur das Datum) nur mit Datum. */
function ma21_zeit_text(WP_Post $p, bool $lang = false, string $trenner = ' · '): string {
    $datum = (string) get_post_time($lang ? 'd.m.Y' : 'd.m.', false, $p, true);
    $uhr = (string) get_post_time('H:i', false, $p, true);
    return $uhr === '00:00' ? $datum : $datum . $trenner . $uhr . ' Uhr';
}

function ma21_lesezeit(WP_Post $p): int {
    $w = str_word_count(wp_strip_all_tags($p->post_excerpt . ' ' . $p->post_content));
    return max(1, (int) round($w / 200));
}

function ma21_teaser(WP_Post $p): string {
    $t = trim($p->post_excerpt) ?: wp_trim_words(wp_strip_all_tags($p->post_content), 30, ' …');
    return $t;
}

/** Text auf höchstens $n Zeichen kürzen, am Wortende („Der Kreis ne …“ stand mitten im Wort, Vorführ-Check 15.10.2026). */
function ma21_kurz(string $t, int $n): string {
    $t = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($t)));
    if (mb_strlen($t) <= $n) return $t;
    $k = mb_substr($t, 0, $n + 1);
    $leer = mb_strrpos($k, ' ');
    $k = $leer !== false && $leer > $n * 0.6 ? mb_substr($k, 0, $leer) : mb_substr($t, 0, $n);
    return rtrim($k, " ,;:–-") . ' …';
}

/** Bilddaten des Beitragsbilds oder null. */
function ma21_bild(WP_Post $p): ?array {
    $id = (int) get_post_thumbnail_id($p->ID);
    if (!$id) return null;
    $voll = wp_get_attachment_image_src($id, 'full');
    if (!$voll) return null;
    $alt = get_post_meta($id, '_wp_attachment_image_alt', true) ?: get_the_title($id);
    $typ = get_post_meta($p->ID, 'ma_image_type', true) ?: get_post_meta($id, 'ma_image_type', true);
    return ['id' => $id, 'src' => $voll[0], 'w' => (int) $voll[1], 'h' => (int) $voll[2], 'srcset' => (string) wp_get_attachment_image_srcset($id, 'full'),
        'alt' => $alt, 'typ' => (string) $typ, 'credit' => ma_credit_kurz((string) get_post_meta($p->ID, 'ma_image_credit', true), (string) get_post_meta($p->ID, 'ma_image_license', true))];
}

/** Echtes, redaktionell nutzbares Bild: kein Logo, kein Wappen. */
function ma21_echtes_bild(?array $b): bool {
    return $b && !preg_match('/logo|wappen/i', $b['alt'] . ' ' . $b['src']);
}

function ma21_img(array $b, string $sizes, bool $eager): string {
    return '<img src="' . esc_url($b['src']) . '"' . ($b['srcset'] ? ' srcset="' . esc_attr($b['srcset']) . '"' : '')
        . ' sizes="' . esc_attr($sizes) . '" alt="' . esc_attr($b['alt']) . '"' . ($b['w'] && $b['h'] ? ' width="' . $b['w'] . '" height="' . $b['h'] . '"' : '')
        . ' loading="' . ($eager ? 'eager' : 'lazy') . '"' . ($eager ? ' fetchpriority="high"' : '') . ' decoding="async" data-editorial-image class="">';
}

function ma21_badge(array $b, bool $start): string {
    $t = ($start ? MA21_HINWEIS_START : MA21_HINWEIS)[$b['typ']] ?? '';
    return $t !== '' ? '<span class="badge">' . ma21_e($t) . '</span>' : '';
}

function ma21_story_id(WP_Post $p): string { return get_post_time('Y-m-d', false, $p) . '-' . $p->post_name; }

function ma21_bildflaeche(WP_Post $p, ?array $b, string $sizes, bool $eager): string {
    if (!$b) return '';
    return '<a class="karte-bild" href="' . esc_url(get_permalink($p)) . '" tabindex="-1" aria-hidden="true"><div class="media">'
        . ma21_img($b, $sizes, $eager) . ma21_badge($b, true) . '</div></a>';
}

/** Datenattribute einer Karte für den Bearbeitungsmodus (includes/layout-front.php): Beitrag, Platz, fest. */
function ma21_karte_attr(WP_Post $p, string $slot = '', bool $fest = false): string {
    return ' data-story="' . esc_attr(ma21_story_id($p)) . '" data-post="' . (int) $p->ID . '"' . ($slot !== '' ? ' data-slot="' . esc_attr($slot) . '"' : '') . ($fest ? ' data-fest="1"' : '');
}

/** Startseitenkarte in den Größen xl (Aufmacher), r/u (Bühne), l, m, s (Rubrikflächen). */
function ma21_karte(WP_Post $p, string $g, string $tag = 'h3', string $slot = '', bool $fest = false, string $sektion = '', int $i = 0): string {
    $url = esc_url(get_permalink($p)); $titel = ma21_e(get_the_title($p)); $b = ma21_bild($p); $attr = ma21_karte_attr($p, $slot, $fest);
    $kopf = "<{$tag}><a href=\"{$url}\">{$titel}</a></{$tag}>";
    if ($g === 'xl') {
        return "<article class=\"front-lead\"{$attr}>" . ma21_bildflaeche($p, $b, MA21_SIZES['xl'], true)
            . '<div class="front-lead-copy">' . ma21_marke($p) . "<h2><a href=\"{$url}\">{$titel}</a></h2><p>" . ma21_e(ma21_teaser($p)) . '</p>'
            . '<div class="meta">' . ma21_zeit($p) . '<span>' . ma21_lesezeit($p) . ' Min. Lesezeit</span></div></div></article>';
    }
    if ($g === 'r' || $g === 'u') {
        return "<article class=\"front-neben-story buehne-karte buehne-karte--{$g}\"{$attr}>" . ma21_bildflaeche($p, $b, MA21_SIZES[$g], false)
            . '<div class="karte-text">' . ma21_marke($p) . "<h2><a href=\"{$url}\">{$titel}</a></h2><div class=\"meta\">" . ma21_zeit($p) . '</div></div></article>';
    }
    // Feste Plätze dürfen auch ohne Bild belegt sein (Layout-Karte): dann ohne Bildfläche.
    if ($g === 'l') {
        return "<article class=\"desk-karte desk-karte--gross" . ($b ? '' : ' desk-karte--ohne-bild') . "\"{$attr}>" . ma21_bildflaeche($p, $b, ma21_sizes('l', $sektion, $i), false)
            . '<div class="karte-text">' . ma21_marke($p) . $kopf . '<p class="dek">' . ma21_e(ma21_teaser($p)) . '</p><div class="meta">' . ma21_zeit($p) . '</div></div></article>';
    }
    if ($g === 'm') {
        return "<article class=\"desk-karte desk-karte--mittel" . ($b ? '' : ' desk-karte--ohne-bild') . "\"{$attr}>" . ma21_bildflaeche($p, $b, ma21_sizes('m', $sektion, $i), false)
            . '<div class="karte-text">' . ma21_marke($p) . $kopf . '<div class="meta">' . ma21_zeit($p) . '</div></div></article>';
    }
    $mitBild = ma21_echtes_bild($b);
    return '<article class="front-zeile' . ($mitBild ? ' front-zeile--bild' : '') . "\"{$attr}>"
        . ($mitBild ? ma21_bildflaeche($p, $b, ma21_sizes('s', $sektion, $i), false) : '')
        . '<div class="karte-text">' . ma21_marke($p) . $kopf . '<div class="meta">' . ma21_zeit($p) . '</div></div></article>';
}

/* ------------------------------------------------------------ Startseite */

/** Platzwahl der Redaktion (Metabox im Plugin): auto, aufmacher, buehne-1 … buehne-4, aus. */
function ma21_startplatz(WP_Post $p): string {
    $v = (string) get_post_meta($p->ID, 'ma_startplatz', true);
    if ($v === '' && get_post_meta($p->ID, 'ma_top_pinned', true) === '1') {
        $bis = (string) get_post_meta($p->ID, 'ma_top_until', true);
        if ($bis === '' || strtotime($bis) > time()) return 'aufmacher';
    }
    return $v ?: 'auto';
}

/** Sport im Sinn der sportfreien Startseite (KBS 26.09.2026): mit Plugin auch Vereins- und Fanclub-Meldungen mit Sportbezug. */
function ma21_ist_sport(WP_Post $p): bool { return has_category('sport', $p) || (function_exists('ma_is_sport_post') && ma_is_sport_post($p)); }

/** Darf auf die Startseite: Startseiten-Freigabe (Plugin, seit 03.10.2026), ohne Plugin nicht „aus“ (Nur in der Rubrik). */
function ma21_startseite_frei(WP_Post $p): bool { return function_exists('ma_relevanz_startseite') ? ma_relevanz_startseite($p) : ma21_startplatz($p) !== 'aus'; }

/**
 * Belegung der Startseite wie deploy/inhaltsindex.mjs: Aufmacher, vier
 * Nebenmeldungen (zwei rechts, zwei darunter, daneben eine Anzeige), dann die
 * Rubrikflächen. Die Startseiten-Freigabe entscheidet, ob eine Meldung
 * erscheint; die Relevanz 1–10 (mit Aktualität) entscheidet, wo.
 * Feste Plätze der Redaktion (Layout-Karte, Plugin includes/layout.php) gehen
 * vor, auch gegen die Bildregeln; freie Plätze füllt die jüngste passende
 * Meldung. „aus“ = nur in der eigenen Rubrik, nie auf der Startseite.
 * $neu = true leert den Zwischenspeicher (nach einer Änderung im Bearbeitungsmodus).
 */
function ma21_startseite_belegung(bool $neu = false): array {
    static $cache = null;
    if ($cache !== null && !$neu) return $cache;
    $alle = get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 120, 'orderby' => 'date', 'order' => 'DESC', 'suppress_filters' => false]);
    // Startseiten-Freigabe und Relevanz 1–10 (Plugin, includes/relevanz.php):
    // „Nur in der Rubrik“ (aus) bleibt draußen, alles andere sortiert die
    // zentrale Relevanzlogik. Aufmacher und Bühne bekommen zuerst, was frisch
    // die Schwellen erreicht (Zone hero, dann buehne), danach den höchsten Wert.
    // Seit 03.10.2026 mit eigener Startseiten-Freigabe (ma_relevanz_startseite), ohne Plugin wie bisher.
    $alle = array_values(array_filter($alle, 'ma21_startseite_frei'));
    if (function_exists('ma_relevanz_sortieren')) $alle = ma_relevanz_sortieren($alle);
    $zone = fn($p) => function_exists('ma_relevanz_zone') ? ma_relevanz_zone($p) : 'feed';
    $rang = ['hero' => 0, 'buehne' => 1];
    $pos = []; $z = [];
    foreach ($alle as $i => $p) { $pos[$p->ID] = $i; $z[$p->ID] = $rang[$zone($p)] ?? 2; }
    $vorrang = $alle;
    usort($vorrang, fn($a, $b) => [$z[$a->ID], $pos[$a->ID]] <=> [$z[$b->ID], $pos[$b->ID]]);
    $termine = function_exists('ma21_kommende_termine') ? count(ma21_kommende_termine(4)) : 3;
    $SEK = [
        'blaulicht' => ['titel' => 'Blaulicht', 'mehr' => '/blaulicht/', 'mehrText' => 'Alle Einsatzmeldungen', 'nimm' => fn($p) => has_category('blaulicht', $p)],
        'rathaus' => ['titel' => 'Politik & Gemeinde', 'mehr' => '/rathaus/', 'mehrText' => 'Zum Rathaus', 'nimm' => fn($p) => has_category('rathaus', $p)],
        'wirtschaft' => ['titel' => 'Wirtschaft', 'mehr' => '/wirtschaft/', 'mehrText' => 'Zur Wirtschaft', 'nimm' => fn($p) => has_category('wirtschaft', $p)],
        'vereine' => ['titel' => 'Vereine & Menschen', 'mehr' => '/vereine/', 'mehrText' => 'Zu den Vereinen', 'nimm' => fn($p) => (has_category('vereine', $p) || has_category('menschen', $p)) && !ma21_ist_sport($p)],
        'gemeinde' => ['titel' => 'Nachrichten aus Merzenich', 'mehr' => '/nachrichten/', 'mehrText' => 'Alle Meldungen', 'nimm' => fn($p) => !ma21_ist_sport($p) && !has_category('tipp', $p), 'jeRessort' => 3, 'fenster' => 44, 'zeilen' => max(2, min(4, $termine))],
    ];
    $regeln = [
        'vorrang' => $vorrang,
        'buehnenTauglich' => fn($p) => !ma21_ist_sport($p) && !has_category('tipp', $p) && ma21_echtes_bild(ma21_bild($p)),
        'breite' => fn($p) => (ma21_bild($p)['w'] ?? 0),
        'motiv' => fn($p) => (int) get_post_thumbnail_id($p->ID),
        'bildtyp' => fn($p) => (string) (ma21_bild($p)['typ'] ?? ''),
        'bild' => fn($p) => ma21_bild($p),
        'echtesBild' => fn($p) => ma21_echtes_bild(ma21_bild($p)),
        'ressort' => fn($p) => ma21_ressort($p)[0],
        'kategorie' => fn($p, $slug) => has_category($slug, $p),
        'sektionen' => $SEK,
        'holen' => fn($id) => get_post($id) ?: null,
    ];
    if (function_exists('ma_layout_aufloesen')) return $cache = ma_layout_aufloesen('startseite', ma_layout_feste_plaetze('startseite'), $alle, $regeln);
    return $cache = ma21_belegung_ohne_plugin($alle, $regeln);
}

/** Notnagel ohne Plugin: Aufmacher und Bühne nach Reihenfolge, keine Rubrikflächen. Die Seite bleibt lesbar. */
function ma21_belegung_ohne_plugin(array $alle, array $r): array {
    $aufmacher = null; $neben = array_fill(1, 4, null); $pl = [];
    foreach ($r['vorrang'] as $p) {
        if (!$r['buehnenTauglich']($p)) continue;
        if (!$aufmacher && $r['breite']($p) >= 480) { $aufmacher = $p; $pl['aufmacher'] = ['post' => $p->ID, 'fest' => false, 'warnungen' => []]; continue; }
        $i = array_search(null, $neben, true);
        if ($i === false) break;
        $neben[$i] = $p; $pl["buehne-$i"] = ['post' => $p->ID, 'fest' => false, 'warnungen' => []];
    }
    return ['aufmacher' => $aufmacher, 'neben' => $neben, 'sektionen' => [], 'plaetze' => $pl];
}

/** Werbefläche der Vorlage; mit laufender Anzeige aus der Werbeverwaltung ersetzt sie das Muster (Plugin, includes/ads.php). */
function ma21_werbung(string $marker): string {
    if (function_exists('ma_render_werbeplatz') && function_exists('ma_ad_marker_slot')) {
        $slot = ma_ad_marker_slot($marker);
        if ($slot !== '' && ma_active_ads($slot)) { $echt = ma_render_werbeplatz($slot, $marker); if ($echt !== '') return $echt; }
    }
    return trim(ma21_vorlage("werbung-{$marker}.html"));
}

/**
 * Werbeband unter Seiten, deren Inhalt schon geschlossen ist (Märkte, Tipps, Termine):
 * ohne eigene Spalte lief es über die ganze Fensterbreite (Vorführ-Check 15.10.2026).
 */
function ma21_werbung_band(): string {
    $w = ma21_werbung('artikel');
    return $w === '' ? '' : '<div class="shell werbung-seitenband">' . $w . '</div>';
}

function ma21_block(string $name): string {
    $b = ma21_startseite_belegung();
    $pl = $b['plaetze'] ?? [];
    $fest = fn(string $slot) => !empty($pl[$slot]['fest']);
    if ($name === 'oben') {
        $n = $b['neben'];
        // Jeder Platz bleibt, wo er ist: Bühne 1–2 rechts, 3–4 unten. Leere Plätze rutschen nicht.
        $rechts = ''; foreach ([1, 2] as $i) if (!empty($n[$i])) $rechts .= ma21_karte($n[$i], 'r', 'h3', "buehne-$i", $fest("buehne-$i"));
        $unten = ''; foreach ([3, 4] as $i) if (!empty($n[$i])) $unten .= ma21_karte($n[$i], 'u', 'h3', "buehne-$i", $fest("buehne-$i"));
        $inhalt = ($b['aufmacher'] ? ma21_karte($b['aufmacher'], 'xl', 'h3', 'aufmacher', $fest('aufmacher')) : '')
            . ($rechts !== '' ? '<div class="buehne-rechts">' . $rechts . '</div>' : '')
            . '<div class="buehne-unten">' . $unten . ma21_werbung('buehne') . '</div>';
        return '<!-- start:oben:start --><section class="shell buehne" data-editorial-verified="1" aria-label="Die wichtigsten Nachrichten">' . $inhalt . '</section><!-- start:oben:end -->';
    }
    $sek = $b['sektionen'][$name] ?? null;
    $rahmen = fn($x) => "<!-- start:{$name}:start -->{$x}<!-- start:{$name}:end -->";
    if (!$sek || !($sek['gross'] || $sek['mittel'] || $sek['zeilen'])) return $rahmen('');
    $s = $sek['s'];
    $kopf = '<div class="desk-heading"><div><h2>' . ma21_e($s['titel']) . '</h2></div><a class="desk-more" href="' . esc_url(home_url($s['mehr'])) . '">' . ma21_e($s['mehrText']) . '</a></div>';
    // Platz je Karte aus der Belegung (bei festen Plätzen kann die Reihe Lücken haben).
    $slotVon = function (string $art, WP_Post $p, int $i) use ($pl, $name): string {
        foreach ($pl as $slot => $e) if ($e['post'] === $p->ID && str_starts_with($slot, "{$name}.{$art}.")) return $slot;
        return "{$name}.{$art}." . ($i + 1);
    };
    $reihe = function (string $klasse, array $l, string $g, string $art) use ($slotVon, $fest, $name): string {
        if (!$l) return '';
        $h = '';
        foreach (array_values($l) as $i => $p) { $slot = $slotVon($art, $p, $i); $h .= ma21_karte($p, $g, 'h3', $slot, $fest($slot), $name, $i); }
        return "<div class=\"{$klasse}\">{$h}</div>";
    };
    return $rahmen("<section class=\"desk shell\" data-sektion=\"{$name}\">{$kopf}" . $reihe('desk-gross', $sek['gross'], 'l', 'gross') . $reihe('desk-mittel', $sek['mittel'], 'm', 'mittel') . $reihe('desk-zeilen', $sek['zeilen'], 's', 'zeilen') . '</section>');
}

/** „Weitere Meldungen“ (Endlos-Scrollen) nur mit eingeschaltetem Schalter (inc/ausbau.php). */
function ma21_startseite_ausbau(string $html): string {
    return ma21_ausbau('endlos') ? $html : (string) preg_replace('#<!-- endlos:start -->.*?<!-- endlos:end -->#s', '', $html);
}

/** Startseite: Vorlage mit gefüllten Nachrichtenblöcken und Werbeflächen. */
function ma21_startseite(): string {
    $html = ma21_vorlage('startseite.html');
    $html = ma21_startseite_ausbau($html);
    $html = (string) preg_replace_callback('/\{\{ma:([a-z0-9:-]+)\}\}/', fn($m) => str_starts_with($m[1], 'werbung:') ? ma21_werbung(substr($m[1], 8)) : ma21_block($m[1]), $html);
    // Foto des Tages wählt WordPress selbst (die Vorlage kann leer oder vom Bautag sein).
    $html = (string) preg_replace_callback('#<!-- fotodestages:start -->.*?<!-- fotodestages:end -->#s', fn() => '<!-- fotodestages:start -->' . ma21_foto_des_tages() . '<!-- fotodestages:end -->', $html, 1);
    // „Merzenich jetzt“ führt auf die Seite „Heute in Merzenich“ (21.17.0, inc/termine.php).
    if (function_exists('ma21_heute_da') && ma21_heute_da()) $html = str_replace('<h2 class="mj-ort" id="mj-titel">Merzenich <span>jetzt</span></h2>', '<h2 class="mj-ort" id="mj-titel"><a href="/heute/">Merzenich <span>jetzt</span></a></h2>', $html);
    return ma21_startseite_bloecke($html);
}

/**
 * Blöcke der Startseite, die in der Vorlage vom Bautag stehen und sonst
 * veralten (Theme 21.11.0): die Terminspalte kommt aus WordPress (neue Termine
 * erscheinen sofort), Umkreis sowie Stellen- und Immobilien-Teaser aus dem
 * aktuellen Stand der Startseite im Repository (die Kette erneuert ihn täglich).
 * Antwortet GitHub nicht, bleibt die letzte gute Kopie bzw. die Vorlage.
 */
function ma21_startseite_bloecke(string $html): string {
    $html = (string) preg_replace_callback('#<!-- start:termine:start -->.*?<!-- start:termine:end -->#s', fn() => '<!-- start:termine:start -->' . ma21_agenda_zeilen(4) . '<!-- start:termine:end -->', $html, 1);
    // „Merzenich jetzt“: nächster Termin aus WordPress (nur veröffentlichte, Entwürfe aus der Recherche nie).
    $html = (string) preg_replace_callback('#<a class="mj-eintrag"[^>]*data-cockpit="termin".*?</a>#s', fn() => ma21_cockpit_termin(), $html, 1);
    // Letzter Feuerwehreinsatz aus WordPress statt vom Bautag der Vorlage (21.13.0); ohne Treffer bleibt die Vorlage.
    $html = (string) preg_replace_callback('#<a class="mj-eintrag"[^>]*data-cockpit="einsatz".*?</a>#s', fn($m) => ma21_cockpit_einsatz() ?: $m[0], $html, 1);
    $repo = ma21_repo_datei('index.html', HOUR_IN_SECONDS);
    foreach (['umkreis', 'markt:home-jobs', 'markt:home-immobilien'] as $k) {
        $q = preg_quote($k, '#');
        if ($repo === '' || !preg_match('#<!-- ' . $q . ':start -->(.*?)<!-- ' . $q . ':end -->#s', $repo, $m)) continue;
        $neu = ma21_block_saeubern($m[1]);
        $html = (string) preg_replace_callback('#<!-- ' . $q . ':start -->.*?<!-- ' . $q . ':end -->#s', fn() => "<!-- {$k}:start -->{$neu}<!-- {$k}:end -->", $html, 1);
    }
    return $html;
}

/** Eintrag „Nächster Termin“ in „Merzenich jetzt“ (Markup wie deploy/cockpit.mjs, assets/cockpit.js passt die Zeile an). */
function ma21_cockpit_termin(): string {
    $tage = ['So.', 'Mo.', 'Di.', 'Mi.', 'Do.', 'Fr.', 'Sa.'];
    $monate = ['Jan.', 'Feb.', 'März', 'Apr.', 'Mai', 'Juni', 'Juli', 'Aug.', 'Sept.', 'Okt.', 'Nov.', 'Dez.'];
    foreach (ma21_kommende_termine(12) as $p) {
        if (strcasecmp((string) get_post_meta($p->ID, 'ma_event_category', true), 'Sport') === 0) continue;
        $start = function_exists('ma_event_timestamp') ? ma_event_timestamp($p->ID, 'start') : 0;
        if (!$start) continue;
        $uhr = wp_date('i', $start) === '00' ? wp_date('G', $start) : wp_date('G:i', $start);
        $lead = $tage[(int) wp_date('w', $start)] . ', ' . wp_date('j', $start) . '. ' . $monate[(int) wp_date('n', $start) - 1] . ($uhr !== '0' ? ', ' . $uhr . ' Uhr' : '');
        $ort = (string) get_post_meta($p->ID, 'ma_event_place', true);
        return '<a class="mj-eintrag" href="' . esc_url(wp_make_link_relative(get_permalink($p))) . '" data-cockpit="termin" data-start="' . esc_attr(gmdate('Y-m-d\TH:i:s.000\Z', $start)) . '">'
            . '<svg class="mj-zeichen" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3.5" y="5" width="17" height="15.5" rx="1.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4M8 13.5h3v3H8z"/></svg>'
            . '<span class="mj-text"><span class="mj-lead" data-cockpit-wert>' . esc_html($lead) . '</span><span class="mj-titel">' . esc_html(html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8')) . '</span><small class="mj-klein">' . esc_html($ort !== '' ? $ort : 'Nächster Termin') . '</small></span></a>';
    }
    return '';
}

/** Eintrag „Feuerwehr · Einsatz N/JJ“ in „Merzenich jetzt“: jüngste veröffentlichte Einsatzmeldung (Adresse /blaulicht/einsatz-N-…/). */
function ma21_cockpit_einsatz(): string {
    $tage = ['So.', 'Mo.', 'Di.', 'Mi.', 'Do.', 'Fr.', 'Sa.'];
    $monate = ['Jan.', 'Feb.', 'März', 'Apr.', 'Mai', 'Juni', 'Juli', 'Aug.', 'Sept.', 'Okt.', 'Nov.', 'Dez.'];
    foreach (get_posts(['post_type' => 'post', 'post_status' => 'publish', 'category_name' => 'blaulicht', 'posts_per_page' => 20, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true]) as $p) {
        if (!preg_match('/^einsatz-(\d+)-/', $p->post_name, $m)) continue;
        $ts = (int) get_post_time('U', true, $p);
        $titel = html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8');
        $kurz = trim(explode(':', $titel, 2)[0]);
        $ort = MA21_ORTE[ma21_ort($p)] ?? 'Merzenich';
        return '<a class="mj-eintrag" href="' . esc_url(wp_make_link_relative(get_permalink($p))) . '" data-cockpit="einsatz">'
            . '<svg class="mj-zeichen" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 21c-3.9 0-6.5-2.6-6.5-6.1 0-3.6 3-5.6 3.6-9.4 2.4 1.5 3.6 3.8 3.6 5.9 1-.6 1.8-1.7 2-3.1 2 1.7 3.8 4 3.8 6.6 0 3.5-2.6 6.1-6.5 6.1z"/><path d="M12 21c-1.6 0-2.7-1.1-2.7-2.6 0-1.7 1.4-2.5 1.8-4.1 1.9 1.1 3.6 2.4 3.6 4.1 0 1.5-1.1 2.6-2.7 2.6z"/></svg>'
            . '<span class="mj-text"><span class="mj-lead">Feuerwehr · Einsatz ' . esc_html($m[1] . '/' . wp_date('y', $ts)) . '</span><span class="mj-titel">' . esc_html($kurz !== '' ? $kurz : $titel) . '</span>'
            . '<small class="mj-klein">' . esc_html($ort . ' · ' . $tage[(int) wp_date('w', $ts)] . ', ' . wp_date('j', $ts) . '. ' . $monate[(int) wp_date('n', $ts) - 1]) . '</small></span></a>';
    }
    return '';
}

/** HTML aus dem Repository: nur erlaubte Tags (Beitrags-HTML plus die Symbole der Märkte). */
function ma21_block_saeubern(string $html): string {
    $svg = ['viewbox' => true, 'aria-hidden' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'class' => true];
    $erlaubt = wp_kses_allowed_html('post') + [
        'svg' => $svg, 'g' => $svg,
        'path' => $svg + ['d' => true], 'rect' => $svg + ['x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true],
        'circle' => $svg + ['cx' => true, 'cy' => true, 'r' => true], 'line' => $svg + ['x1' => true, 'y1' => true, 'x2' => true, 'y2' => true],
        'time' => ['datetime' => true, 'class' => true],
    ];
    return wp_kses($html, $erlaubt);
}

/**
 * Terminspalte der Startseite aus WordPress, im Markup der Vorlage
 * (deploy/termine-prerender.mjs): Tag und Monat, Kategorie, Titel, Uhrzeit und
 * Ort, Knopf „Im Kalender speichern“. Sporttermine stehen nur unter /sport/
 * und /termine/ (Vorgabe KBS 26.09.2026).
 */
function ma21_agenda_zeilen(int $n): string {
    $monate = ['Jan', 'Feb', 'Mrz', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
    $h = '';
    foreach (ma21_kommende_termine(12) as $p) {
        $kat = (string) get_post_meta($p->ID, 'ma_event_category', true);
        if (strcasecmp($kat, 'Sport') === 0) continue;
        $start = function_exists('ma_event_timestamp') ? ma_event_timestamp($p->ID, 'start') : 0;
        if (!$start) continue;
        $ende = (string) get_post_meta($p->ID, 'ma_event_end', true) !== '' ? ma_event_timestamp($p->ID, 'end') : 0;
        $tagEnde = (new DateTimeImmutable('@' . max($start, $ende)))->setTimezone(wp_timezone())->setTime(23, 59, 59);
        $mehrtaegig = $ende && wp_date('Ymd', $ende) !== wp_date('Ymd', $start);
        $zeit = $mehrtaegig ? 'bis ' . wp_date('j.n.', $ende) : (wp_date('H:i', $start) === '00:00' ? 'Ganztägig' : wp_date('H:i', $start) . ' Uhr');
        $zeile = implode(' · ', array_filter([$zeit, (string) get_post_meta($p->ID, 'ma_event_place', true)]));
        $titel = html_entity_decode(get_the_title($p), ENT_QUOTES, 'UTF-8');
        $url = wp_make_link_relative(get_permalink($p));
        $h .= '<article class="agenda-row" data-event-end="' . esc_attr(gmdate('Y-m-d\TH:i:s.000\Z', $tagEnde->getTimestamp())) . '">'
            . '<time class="agenda-date" datetime="' . esc_attr(gmdate('Y-m-d\TH:i:s.000\Z', $start)) . '"><b>' . esc_html(wp_date('j', $start)) . '</b><span>' . esc_html($monate[(int) wp_date('n', $start) - 1]) . '</span></time>'
            . '<div>' . ($kat !== '' ? '<span class="eyebrow">' . esc_html($kat) . '</span>' : '')
            . '<h3><a href="' . esc_url($url) . '">' . esc_html($titel) . '</a></h3><p>' . esc_html($zeile) . '</p></div>'
            . '<a class="calendar-save" href="' . esc_url(trailingslashit($url) . 'termin.ics') . '" aria-label="' . esc_attr($titel . ' im Kalender speichern') . '" download><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M3 10h18M8 3v4M16 3v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></a></article>';
        if (--$n <= 0) break;
    }
    return $h !== '' ? $h : '<p class="agenda-leer">Gerade sind keine Termine eingetragen. <a href="' . esc_url(home_url('/termin-melden/')) . '">Termin melden</a></p>';
}

/** Motiv eines Bildpfads ohne Breite und Endung (wie deploy/foto-des-tages.mjs): /assets/places/golzheim-1440.webp → places/golzheim. */
function ma21_motiv_schluessel(string $src): string {
    $s = (string) preg_replace('#[?\#].*$#', '', $src);
    $s = (string) preg_replace('#^.*?/assets/#', '', $s);
    $s = (string) preg_replace('#-\d{3,4}(?=\.[a-z0-9]+$)#i', '', $s);
    return (string) preg_replace('#\.[a-z0-9]+$#i', '', $s);
}

/**
 * Wahl des Fotos des Tages: datierte Leser-Einsendung für heute, sonst reihum
 * nach Tag eine gesichtete Ortsansicht. Motive, die schon als Bild einer
 * Meldung auf der Startseite stehen ($belegt), kommen erst später dran; sind
 * alle belegt, gilt die volle Reihe. So fällt die Fläche nie weg.
 */
function ma21_foto_des_tages_wahl(array $d, string $heute, array $belegt): ?array {
    // Im Eingang eingeplantes Leserfoto (Plugin, foto-des-tages.php) geht vor.
    $leser = function_exists('ma_foto_des_tages_eingeplant') ? ma_foto_des_tages_eingeplant($heute) : null;
    if ($leser) return $leser;
    foreach ((array) ($d['eintraege'] ?? []) as $e) if (is_array($e) && ($e['datum'] ?? '') === $heute && !empty($e['src'])) return $e;
    $alle = array_values(array_filter((array) ($d['alle'] ?? $d['reihe'] ?? []), fn($r) => is_array($r) && !empty($r['src']) && !empty($r['alt'])));
    if (!$alle) return null;
    $frei = array_values(array_filter($alle, fn($r) => !in_array(ma21_motiv_schluessel((string) $r['src']), $belegt, true)));
    $reihe = $frei ?: $alle;
    return $reihe[intdiv((int) strtotime($heute . ' 00:00:00 UTC'), 86400) % count($reihe)];
}

/** Motive der Meldungsbilder auf der Startseite (Bühne und Rubrikflächen). */
function ma21_startseite_motive(): array {
    $b = ma21_startseite_belegung();
    $posts = array_merge([$b['aufmacher'] ?? null], array_values((array) ($b['neben'] ?? [])));
    foreach ((array) ($b['sektionen'] ?? []) as $sek) foreach (['gross', 'mittel', 'zeilen'] as $art) $posts = array_merge($posts, array_values((array) ($sek[$art] ?? [])));
    $motive = [];
    foreach ($posts as $p) {
        if (!$p instanceof WP_Post) continue;
        $src = (string) get_post_meta((int) get_post_thumbnail_id($p->ID), 'ma_image_static_src', true);
        if ($src !== '') $motive[] = ma21_motiv_schluessel($src);
    }
    return array_values(array_unique($motive));
}

/**
 * Foto des Tages auf der Startseite (Wunsch KBS 26.09.2026; Vorgabe Betreiber
 * 05.10.2026: „muss auf jeden Fall mit rein“). Daten: static/foto-des-tages.json
 * aus deploy/foto-des-tages.mjs. Poolfotos kommen aus der Mediathek, Ortsansichten
 * aus /assets/. assets/foto-des-tages.js tauscht nur, wenn die Seite von gestern ist.
 */
function ma21_foto_des_tages(): string {
    $datei = trailingslashit(get_template_directory()) . 'static/foto-des-tages.json';
    $d = is_readable($datei) ? json_decode((string) file_get_contents($datei), true) : null;
    if (!is_array($d)) return '';
    $heute = (string) wp_date('Y-m-d');
    $f = ma21_foto_des_tages_wahl($d, $heute, ma21_startseite_motive());
    if (!$f) return '';
    $src = (string) $f['src']; $srcset = (string) ($f['srcset'] ?? '');
    $mediathek = function_exists('ma21_asset_lokal') ? ma21_asset_lokal($src) : '';
    if ($mediathek !== '') {
        $id = attachment_url_to_postid($mediathek);
        $src = $mediathek;
        $srcset = $id ? (string) wp_get_attachment_image_srcset($id, 'full') : '';
    }
    $tage = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
    $monate = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
    $ts = (int) strtotime($heute . ' 12:00:00 UTC');
    $datum = $tage[(int) gmdate('w', $ts)] . ', ' . gmdate('j', $ts) . '. ' . $monate[(int) gmdate('n', $ts) - 1];
    $credit = ma21_e((string) ($f['credit'] ?? ''));
    if (!empty($f['quelle'])) $credit = '<a href="' . esc_url((string) $f['quelle']) . '" target="_blank" rel="noopener">' . $credit . '</a>';
    return '<section class="ansichten foto-des-tages" aria-labelledby="ansichten-titel" data-foto-des-tages>'
        . '<figure class="ansichten-bild shell"><img id="foto-des-tages-bild" src="' . esc_url(str_starts_with($src, '/') ? home_url($src) : $src) . '"'
        . ($srcset !== '' ? ' srcset="' . esc_attr(str_starts_with($srcset, '/') ? (string) preg_replace('#(^|,\s*)/#', '$1' . home_url('/'), $srcset) : $srcset) . '" sizes="(max-width: 1440px) 100vw, 1440px"' : '')
        . ' alt="' . esc_attr((string) $f['alt']) . '" width="1440" height="960" loading="lazy" decoding="async"></figure>'
        . '<div class="shell ansichten-text">'
        . '<p class="ansichten-marke">Foto des Tages · <time id="foto-des-tages-datum" datetime="' . esc_attr($heute) . '">' . esc_html($datum) . '</time></p>'
        . '<h2 id="ansichten-titel" data-ansicht-ort>' . ma21_e((string) (($f['ort'] ?? '') ?: 'Gemeinde Merzenich')) . '</h2>'
        . '<p class="ansichten-beschreibung" data-ansicht-text>' . ma21_e(rtrim((string) $f['alt'], '.')) . '.</p>'
        . '<p class="ansichten-credit" id="foto-des-tages-credit">Foto: ' . $credit . '</p>'
        . '<a class="ansichten-senden" href="' . esc_url(home_url('/meldung-senden/#foto-des-tages')) . '">Ihr Foto des Tages einsenden</a>'
        . '</div></section>';
}

/** Kommende Termine (ma_event), nach Beginn sortiert. */
function ma21_kommende_termine(int $n): array {
    $jetzt = current_time('Y-m-d\TH:i');
    $q = get_posts(['post_type' => 'ma_event', 'post_status' => 'publish', 'posts_per_page' => 50, 'meta_key' => 'ma_event_start', 'orderby' => 'meta_value', 'order' => 'ASC']);
    $raus = [];
    foreach ($q as $p) {
        $ende = get_post_meta($p->ID, 'ma_event_end', true) ?: substr((string) get_post_meta($p->ID, 'ma_event_start', true), 0, 10) . 'T23:59';
        if ($ende >= $jetzt) $raus[] = $p;
        if (count($raus) >= $n) break;
    }
    return $raus;
}

/* ------------------------------------------------------------ Listen */

/** Karte im „Weiterlesen“-Block unter einer Meldung. */
function ma21_news_card(WP_Post $p): string {
    $url = esc_url(get_permalink($p)); $titel = ma21_e(get_the_title($p)); $b = ma21_bild($p);
    return '<article class="news-card">' . ($b ? "\n  <a href=\"{$url}\" tabindex=\"-1\" aria-hidden=\"true\"><div class=\"media\">" . ma21_img($b, MA21_SIZES['news-card'], false) . ma21_badge($b, false) . '</div></a>' : '')
        . "\n  <div class=\"news-card-body\">\n    " . ma21_marke($p, 'kicker') . "\n    <h3><a href=\"{$url}\">{$titel}</a></h3>\n    <p class=\"dek\">" . ma21_e(ma21_teaser($p)) . "</p>\n    <div class=\"meta\">" . ma21_zeit($p, true) . '</div>'
        . "<div class=\"story-actions\"><a class=\"read-more\" href=\"{$url}\">Mehr lesen<span class=\"sr-only\">: {$titel}</span></a></div>\n  </div>\n</article>";
}

/** Erste Meldung einer Liste (Rubrik, Ort, Thema). */
function ma21_feed_lead(WP_Post $p, string $slot = '', bool $fest = false): string {
    $url = esc_url(get_permalink($p)); $titel = ma21_e(get_the_title($p)); $b = ma21_bild($p);
    // Ohne Bild über die ganze Breite (.feed-lead.no-media, korrekturen.css), sonst stand der Text in der Bildspalte (Suche, Vorführ-Check 15.10.2026).
    return '<article class="feed-lead' . ($b ? '' : ' no-media') . '"' . ma21_karte_attr($p, $slot, $fest) . '>'
        . ($b ? "<a href=\"{$url}\" tabindex=\"-1\" aria-hidden=\"true\"><div class=\"media\">" . ma21_img($b, MA21_SIZES['feed-lead'], true) . ma21_badge($b, false) . '</div></a>' : '')
        . '<div class="lead-copy">' . ma21_marke($p, 'kicker') . "<h2><a href=\"{$url}\">{$titel}</a></h2><p class=\"dek\">" . ma21_e(ma21_teaser($p)) . '</p>'
        . '<div class="meta">' . ma21_zeit($p, true) . '<span class="readtime">' . ma21_lesezeit($p) . ' Min.</span></div></div></article>';
}

function ma21_feed_row(WP_Post $p, string $slot = '', bool $fest = false): string {
    $url = esc_url(get_permalink($p)); $titel = ma21_e(get_the_title($p)); $b = ma21_bild($p);
    // Ohne Bild eine Spalte wie in der statischen Kopie (deploy/inhaltsindex.mjs), sonst stünde der Text in der schmalen Bildspalte.
    return '<article' . ma21_karte_attr($p, $slot, $fest) . ' class="feed-row' . ($b ? '' : ' no-media no-image') . '">'
        . ($b ? "<a class=\"feed-img\" href=\"{$url}\" tabindex=\"-1\" aria-hidden=\"true\"><div class=\"media\">" . ma21_img($b, MA21_SIZES['feed-row'], false) . ma21_badge($b, false) . '</div></a>' : '')
        . '<div class="feed-copy">' . ma21_marke($p, 'kicker') . "<h3><a href=\"{$url}\">{$titel}</a></h3><p class=\"dek\">" . ma21_e(ma21_teaser($p)) . '</p>'
        . '<div class="meta">' . ma21_zeit($p, true) . '<span class="readtime">' . ma21_lesezeit($p) . ' Min.</span></div>'
        . "<div class=\"story-actions\"><a class=\"read-more\" href=\"{$url}\">Mehr lesen<span class=\"sr-only\">: {$titel}</span></a></div></div></article>";
}

/** Bildraster der Sportseite: gleich hohe Karten mit Bild, Marke, Titel, Zeit. $plaetze: je Karte [Platz, fest]. */
function ma21_bildraster(array $posts, array $plaetze = []): string {
    $h = '<div class="bildraster">';
    foreach (array_values($posts) as $i => $p) {
        $url = esc_url(get_permalink($p)); $titel = ma21_e(get_the_title($p)); $b = ma21_bild($p);
        [$slot, $fest] = $plaetze[$i] ?? ['', false];
        $h .= '<article class="bildraster-karte' . ($b ? '' : ' bildraster-karte--ohne-bild') . '"' . ma21_karte_attr($p, $slot, $fest) . '>'
            . ($b ? "<a class=\"bildraster-bild\" href=\"{$url}\" tabindex=\"-1\" aria-hidden=\"true\"><div class=\"media\">" . ma21_img($b, MA21_SIZES['raster'], false) . ma21_badge($b, false) . '</div></a>' : '')
            . '<div class="bildraster-text">' . ma21_marke($p, 'kicker') . "<h3><a href=\"{$url}\">{$titel}</a></h3><div class=\"meta\">" . ma21_zeit($p) . '</div></div></article>';
    }
    return $h . '</div>';
}

/** Schlüssel der Layout-Karte für die aktuelle Liste ('' = nicht anordenbar). */
function ma21_ressort_schluessel(): string {
    if (!function_exists('ma_layout_seite_gueltig')) return '';
    if (get_query_var('ma_alle')) return 'ressort-nachrichten';
    if (is_category()) { $o = get_queried_object(); if ($o instanceof WP_Term && ma_layout_seite_gueltig('ressort-' . $o->slug)) return 'ressort-' . $o->slug; }
    return '';
}

/** Beiträge der ersten Seite einer Ressortliste (für das Neu-Rendern im Bearbeitungsmodus). */
function ma21_ressort_beitraege(string $seite): array {
    $slug = substr($seite, 8);
    $q = ['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => ma21_raster_seite($seite) ? ma21_raster_anzahl($seite) : max(1, (int) get_option('posts_per_page', 10)), 'orderby' => 'date', 'order' => 'DESC', 'suppress_filters' => false];
    if ($slug !== 'nachrichten') $q['category_name'] = $slug;
    return get_posts($q);
}

/** Belegung einer Ressortseite: Aufmacher, Bildraster (Sport), Reihen; feste Plätze aus der Layout-Karte. */
function ma21_ressort_belegung(string $seite, array $posts): array {
    $sport = $seite === 'ressort-sport';
    if (function_exists('ma_layout_aufloesen')) {
        return ma_layout_aufloesen($seite, ma_layout_feste_plaetze($seite), $posts, ['raster' => $sport, 'echtesBild' => fn($p) => ma21_echtes_bild(ma21_bild($p)), 'holen' => fn($id) => get_post($id) ?: null]);
    }
    $lead = array_shift($posts); $raster = []; $reihen = [];
    foreach ($posts as $p) { if ($sport && count($raster) < 6 && ma21_echtes_bild(ma21_bild($p))) $raster[] = $p; else $reihen[] = $p; }
    return ['lead' => $lead, 'raster' => $raster, 'reihen' => $reihen, 'plaetze' => []];
}

/**
 * Ressorts mit Kartenraster statt Zeilen (Vorgabe Betreiber 07.10.2026: „alles
 * so untereinander“, Vorbild Oberberg Aktuell mit zwei Spalten). Sport und
 * Vereine behalten ihr Layout, Ort, Thema und Suche bleiben Listen.
 */
function ma21_raster_seite(string $seite): bool {
    return str_starts_with($seite, 'ressort-') && !in_array($seite, ['ressort-sport', 'ressort-vereine'], true);
}

/** Meldungen je Seite im Raster: Aufmacher plus gerade Kartenzahl (Aktuell 20, sonst 12). */
function ma21_raster_anzahl(string $seite): int {
    return $seite === 'ressort-nachrichten' ? 21 : 13;
}

/**
 * Kartenraster einer Ressortseite: je Karte Bild, Rubrik, Überschrift, Anriss
 * und Zeit, zwei Spalten; nach sechs Karten ein Werbeplatz über die ganze
 * Breite. $plaetze: je Karte [Platz, fest] für den Bearbeitungsmodus.
 */
function ma21_feed_raster(array $posts, array $plaetze = []): string {
    $h = '<div class="bildraster bildraster--ressort">';
    foreach (array_values($posts) as $i => $p) {
        if ($i === 6) { $w = ma21_werbung('artikel'); if ($w !== '') $h .= '<div class="bildraster-werbung">' . $w . '</div>'; }
        $url = esc_url(get_permalink($p)); $titel = ma21_e(get_the_title($p)); $b = ma21_bild($p);
        [$slot, $fest] = $plaetze[$i] ?? ['', false];
        $h .= '<article class="bildraster-karte' . ($b ? '' : ' bildraster-karte--ohne-bild') . '"' . ma21_karte_attr($p, $slot, $fest) . '>'
            . ($b ? "<a class=\"bildraster-bild\" href=\"{$url}\" tabindex=\"-1\" aria-hidden=\"true\"><div class=\"media\">" . ma21_img($b, MA21_SIZES['ressort-raster'], false) . ma21_badge($b, false) . '</div></a>' : '')
            . '<div class="bildraster-text">' . ma21_marke($p, 'kicker') . "<h3><a href=\"{$url}\">{$titel}</a></h3>"
            . '<p class="dek">' . ma21_e(ma21_kurz(ma21_teaser($p), 150)) . '</p><div class="meta">' . ma21_zeit($p, true) . '</div></div></article>';
    }
    return $h . '</div>';
}

/** Liste einer Ressortseite als HTML (erste Seite: nach Layout-Karte; weitere Seiten: Aufmacher und Raster bzw. Reihen). */
function ma21_feed_html(string $seite, array $posts, bool $ersteSeite): string {
    if (!$posts && is_search()) return '<p class="no-result">Keine Treffer für „' . esc_html(get_search_query(false)) . '“. Versuchen Sie einen anderen Begriff, einen Ortsteil wie „Golzheim“ oder ein Thema wie „Feuerwehr“, oder stöbern Sie in den <a href="' . esc_url(home_url('/nachrichten/')) . '">neuesten Nachrichten</a>.</p>';
    if (!$posts) return '<p class="no-result">Hier gibt es noch keine Meldung. Sobald die erste Meldung vorliegt, steht sie an dieser Stelle.</p>';
    $raster = ma21_raster_seite($seite);
    if (!$ersteSeite && $raster) { $erste = array_shift($posts); return ma21_feed_lead($erste) . "\n" . ($posts ? ma21_feed_raster($posts) : ''); }
    if (!$ersteSeite) return implode("\n", array_map(fn($p) => ma21_feed_row($p), $posts));
    $b = ma21_ressort_belegung($seite, $posts);
    $pl = $b['plaetze'];
    $slotVon = function (WP_Post $p, string $art) use ($pl): array {
        foreach ($pl as $slot => $e) if ($e['post'] === $p->ID && str_starts_with($slot, $art)) return [$slot, !empty($e['fest'])];
        return ['', false];
    };
    $h = '';
    if ($b['lead']) { [$slot, $fest] = $slotVon($b['lead'], 'lead'); $h .= ma21_feed_lead($b['lead'], $slot, $fest) . "\n"; }
    if ($b['raster']) $h .= ma21_bildraster($b['raster'], array_map(fn($p) => $slotVon($p, 'raster.'), $b['raster'])) . "\n";
    if ($raster) return $h . ($b['reihen'] ? ma21_feed_raster($b['reihen'], array_map(fn($p) => $slotVon($p, 'reihe.'), $b['reihen'])) . "\n" : '');
    foreach ($b['reihen'] as $p) { [$slot, $fest] = $slotVon($p, 'reihe.'); $h .= ma21_feed_row($p, $slot, $fest) . "\n"; }
    return $h;
}

/* ------------------------------------------------------------ Endlos-Scrollen */

/**
 * Endlos-Scrollen (Wunsch Betreiber 15.10.2026: keine Seiten 1, 2, man scrollt
 * einfach weiter). assets/endlos.js lädt beim Scrollen die nächste Seite nach.
 * /…/page/N/ bleibt unverändert für Suchmaschinen und Leser ohne JavaScript.
 * Mit ?ma_endlos=1 liefert dieselbe Adresse nur die Meldungen dieser Seite als
 * Teilstück: ohne Kopf und Aufmacher, Raster-Ressorts als Karten (Anzeige wie
 * gewohnt nach Karte 6), alle anderen Listen als Zeilen.
 */
add_filter('query_vars', function (array $v): array { $v[] = 'ma_endlos'; $v[] = 'ma_ohne_sport'; return $v; });
/** Ist die Anfrage eine Meldungsliste, die endlos weiterlaufen kann? */
function ma21_endlos_liste(): bool {
    return is_category() || is_tag() || is_tax('ma_location') || is_search() || (bool) get_query_var('ma_alle')
        || ma21_rubrik_aktuell() !== null || (string) get_query_var('ma_autor') !== '';
}
/** Adresse der nächsten Seite der aktuellen Liste, '' auf der letzten Seite. */
function ma21_endlos_naechste(): string {
    global $wp_query;
    $seite = max(1, (int) get_query_var('paged'));
    if (!$wp_query || $seite >= (int) ($wp_query->max_num_pages ?? 0)) return '';
    return (string) remove_query_arg('ma_endlos', get_pagenum_link($seite + 1, false));
}
/** Teilstück: Karten oder Zeilen, nie ein Aufmacher; data-naechste nennt die Folgeseite ('' am Ende). */
function ma21_endlos_teil(string $seite, array $posts, string $naechste): string {
    $raster = ma21_raster_seite($seite);
    $inhalt = $raster ? ma21_feed_raster($posts) : implode("\n", array_map(fn($p) => ma21_feed_row($p), $posts));
    return '<div data-endlos-teil data-art="' . ($raster ? 'raster' : 'reihen') . '" data-naechste="' . esc_attr($naechste) . '">' . $inhalt . '</div>';
}
/**
 * Antwort des Teilmodus (?ma_endlos=1): null = keine (normale Seite, auch bei
 * ausgeschaltetem Endlos-Scrollen), sonst [Status, Inhalt]. Hinter der letzten
 * Seite 404, endlos.js meldet dann „Alle Meldungen geladen“.
 */
function ma21_endlos_antwort(): ?array {
    if ((string) get_query_var('ma_endlos') === '' || !ma21_ausbau('endlos') || !ma21_endlos_liste()) return null;
    global $wp_query;
    $posts = array_values(array_filter((array) ($wp_query->posts ?? []), fn($p) => $p instanceof WP_Post));
    if (!$posts || is_404()) return [404, ''];
    // „Weitere Meldungen“ der Startseite (?ma_ohne_sport=1): Die Startseite bleibt sportfrei (KBS 26.09.2026),
    // auch mit Vereins- und Fanclub-Meldungen mit Sportbezug, und zeigt wie die oberen Blöcke nur Meldungen mit
    // Startseiten-Freigabe („Nur in der Rubrik“ bleibt draußen, Review 16.10.2026). Bleibt nichts übrig, lädt endlos.js die Folgeseite.
    if ((string) get_query_var('ma_ohne_sport') !== '') $posts = array_values(array_filter($posts, fn($p) => !ma21_ist_sport($p) && ma21_startseite_frei($p)));
    $schluessel = ma21_ressort_schluessel();
    return [200, ma21_endlos_teil($schluessel !== '' ? $schluessel : (is_category('sport') ? 'ressort-sport' : 'liste'), $posts, ma21_endlos_naechste())];
}
add_action('template_redirect', function (): void {
    $antwort = ma21_endlos_antwort();
    if ($antwort === null) return;
    if (!headers_sent()) header('X-Robots-Tag: noindex, follow');
    status_header($antwort[0]);
    if ($antwort[0] !== 200) { nocache_headers(); exit; }
    header('Content-Type: text/html; charset=utf-8');
    // Wie die Seiten selbst nie zwischenspeichern: Ein altes Teilstück ließe nach einer
    // neuen Meldung eine Meldung aus (sie rutscht von Seite 1 auf die gespeicherte Seite 2).
    if (function_exists('is_user_logged_in') && is_user_logged_in()) nocache_headers(); else ma21_cache(0);
    echo $antwort[1];
    exit;
}, 1);
/* Blättern bleibt für Suchmaschinen und Leser ohne JavaScript: rel="next"/"prev" an den Links. */
add_filter('paginate_links_output', function (string $r): string {
    return str_replace(['<a class="next page-numbers"', '<a class="prev page-numbers"'], ['<a class="next page-numbers" rel="next"', '<a class="prev page-numbers" rel="prev"'], $r);
});
/** Datenattribute am .feed einer Liste für assets/endlos.js. */
function ma21_endlos_attr(string $seite): string {
    if (!ma21_ausbau('endlos')) return '';
    $n = ma21_endlos_naechste();
    return $n === '' ? '' : ' data-endlos-naechste="' . esc_attr($n) . '" data-endlos-art="' . (ma21_raster_seite($seite) ? 'raster' : 'reihen') . '"';
}

/* Bearbeitungsmodus und Board (Plugin): Blöcke neu rendern und Belegung lesen. */
add_filter('ma_layout_block_html', function ($html, string $seite, string $block): string {
    if ($seite === 'startseite') return ma21_block($block); // Belegung vorher über ma_layout_belegung auffrischen.
    return $block === 'feed' ? ma21_feed_html($seite, ma21_ressort_beitraege($seite), true) : (string) $html;
}, 10, 3);
add_filter('ma_layout_belegung', function ($b, string $seite): array {
    if ($seite === 'startseite') return ma21_startseite_belegung(true)['plaetze'] ?? [];
    return ma21_ressort_belegung($seite, ma21_ressort_beitraege($seite))['plaetze'] ?? [];
}, 10, 2);

/** Rechte Spalte der Listen: neueste Meldungen, bei Sport und Vereinen die Vereine der Gemeinde. */
function ma21_liste_seitenspalte(int $ohne = 0): string {
    $h = '';
    $neu = get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 5] + ($ohne ? ['post__not_in' => [$ohne]] : []));
    if ($neu) {
        $h .= '<div class="sidebox"><h3>Neueste Meldungen aus allen Ressorts<a href="' . esc_url(home_url('/nachrichten/')) . '">alle</a></h3><ol class="ranked">';
        foreach ($neu as $p) $h .= '<li><a href="' . esc_url(get_permalink($p)) . '">' . ma21_e(get_the_title($p)) . '</a></li>';
        $h .= '</ol></div>';
    }
    if (is_tax('ma_location')) { $o = get_queried_object(); if ($o instanceof WP_Term) $h .= ma21_ort_seitenspalte($o); }
    $sport = is_category('sport'); $vereine = is_category('vereine');
    // Auf der ersten Sportseite stehen die Vereine groß unter den Meldungen (ma21_sport_vereine), rechts nicht noch einmal.
    $vereineUnten = $sport && !is_paged() && function_exists('ma21_ausbau') && !ma21_ausbau('sport_daten');
    if (($sport || $vereine) && function_exists('ma_vereine_struktur')) {
        if ($sport) $h .= '<div class="sidebox sport-side-action"><h3>Sport direkt aus den Vereinen</h3><p>Vereine reichen Spielberichte, Ergebnisse, Termine und Mannschaftsfotos über ihren Redaktionszugang ein. Veröffentlicht wird nach Freigabe durch die Redaktion.</p><p><a class="read-more" href="' . esc_url(home_url('/meldung-senden/')) . '">Sportmeldung senden</a></p></div>';
        $liste = ''; $n = 0;
        foreach (ma_vereine_struktur() as $kurz => $e) {
            $v = $e['verein'];
            if ($sport !== (($v['kategorie'] ?? '') === 'Sport')) continue;
            $profil = ma_verein_profil($kurz);
            $sportarten = array_filter(array_merge([$v['sportart'] ?? ''], array_map(fn($a) => $a['sportart'] ?? '', $e['abteilungen'])));
            $klein = implode(' · ', array_filter([$sportarten ? implode(', ', array_unique($sportarten)) : ($v['kategorie'] ?? ''), MA21_ORTE[$v['ort'] ?? ''] ?? 'Gemeinde']));
            $name = ma21_e($v['name']);
            $link = $profil && $profil->post_status === 'publish' ? '<a href="' . esc_url(get_permalink($profil)) . '">' . $name . '</a>' : (!empty($v['website']) ? '<a href="' . esc_url($v['website']) . '" target="_blank" rel="noopener">' . $name . '</a>' : '<span>' . $name . '</span>');
            $liste .= '<li>' . $link . '<small>' . ma21_e($klein) . '</small></li>'; $n++;
        }
        if ($n && !$vereineUnten) $h .= '<div class="sidebox sport-leiste"><h3>' . ($sport ? 'Sportvereine in der Gemeinde' : 'Vereine in Merzenich') . '</h3><ul class="sport-vereine">' . $liste . '</ul><p class="sport-leiste-quelle">Vereinsverzeichnis der Gemeinde · Abteilungen im Profil des Hauptvereins</p></div>';
    }
    return $h;
}

/* Ortsseiten (/ort/<slug>/, 04.10.2026): In der Liste stehen nur Meldungen. Vorher
   mischten sich Termine und Vereinsprofile chronologisch hinein, ohne Bild, und
   verdrängten die Meldungen; die statische Ortsseite zeigt Termine und Vereine
   des Orts in der Seitenleiste, so jetzt auch hier. */
add_action('pre_get_posts', function (WP_Query $q): void {
    if (is_admin() || !$q->is_main_query() || !$q->is_tax('ma_location')) return;
    $q->set('post_type', 'post');
});

/** Seitenleiste der Ortsseite: nächste Termine und Vereine des Orts (Aufbau wie die statische Ortsseite). */
function ma21_ort_seitenspalte(WP_Term $ort): string {
    $h = '';
    $termine = get_posts(['post_type' => 'ma_event', 'post_status' => 'publish', 'posts_per_page' => 5, 'meta_key' => 'ma_event_start', 'orderby' => 'meta_value', 'order' => 'ASC',
        'meta_query' => [['key' => 'ma_event_start', 'value' => (string) current_time('Y-m-d\TH:i'), 'compare' => '>=']],
        'tax_query' => [['taxonomy' => 'ma_location', 'field' => 'term_id', 'terms' => (int) $ort->term_id]]]);
    if ($termine) {
        $h .= '<div class="sidebox ort-termine"><h3>Nächste Termine in ' . ma21_e($ort->name) . '<a href="' . esc_url(home_url('/termine/')) . '">alle</a></h3><ul class="linklist">';
        foreach ($termine as $t) {
            $start = function_exists('ma_event_timestamp') ? (int) ma_event_timestamp($t->ID, 'start') : 0;
            // Wochentag immer deutsch, ganztägige Termine ohne „00:00 Uhr“ (21.13.0).
            $wann = $start ? mb_substr(MA21_TAGE[(int) wp_date('w', $start)], 0, 2) . ', ' . wp_date('d.m.', $start) . (wp_date('H:i', $start) !== '00:00' ? ', ' . wp_date('H:i', $start) . ' Uhr' : '') : '';
            $platz = (string) get_post_meta($t->ID, 'ma_event_place', true);
            $h .= '<li><a href="' . esc_url(get_permalink($t)) . '">' . ma21_e(get_the_title($t)) . '</a><small>' . ma21_e(implode(' · ', array_filter([$wann, $platz]))) . '</small></li>';
        }
        $h .= '</ul></div>';
    }
    if (function_exists('ma_vereine_struktur')) {
        $liste = '';
        foreach (ma_vereine_struktur() as $kurz => $e) {
            $v = $e['verein'];
            if (($v['ort'] ?? '') !== $ort->slug) continue;
            $profil = function_exists('ma_verein_profil') ? ma_verein_profil($kurz) : null;
            $name = ma21_e((string) $v['name']);
            $link = $profil instanceof WP_Post && $profil->post_status === 'publish' ? '<a href="' . esc_url(get_permalink($profil)) . '">' . $name . '</a>' : (!empty($v['website']) ? '<a href="' . esc_url($v['website']) . '" target="_blank" rel="noopener">' . $name . '</a>' : $name);
            $klein = (string) (($v['sportart'] ?? '') ?: ($v['kategorie'] ?? ''));
            $liste .= '<li>' . $link . ($klein !== '' ? '<small>' . ma21_e($klein) . '</small>' : '') . '</li>';
        }
        if ($liste !== '') $h .= '<div class="sidebox ort-vereine"><h3>Vereine in ' . ma21_e($ort->name) . '<a href="' . esc_url(home_url('/vereine/')) . '">alle</a></h3><ul class="linklist">' . $liste . '</ul></div>';
    }
    return $h;
}

/** Kopf und Beschreibung je Liste, wie auf der statischen Seite. */
function ma21_liste_kopf(): array {
    // Sammelseite eines roten Menütitels: Ressort als Dachzeile, Titel als Überschrift.
    if (($rs = ma21_rubrik_aktuell()) !== null) return [(string) $rs['ressortTitel'], (string) $rs['titel'], (string) $rs['beschreibung']];
    $o = get_queried_object();
    $TEXTE = [
        'blaulicht' => ['Blaulicht', 'Feuerwehr, Polizei und Rettungsdienst', 'Einsätze der Freiwilligen Feuerwehr Merzenich, Polizeimeldungen für das Gemeindegebiet und Verkehrsmeldungen, sachlich zusammengefasst und mit Originalquelle.'],
        'rathaus' => ['Rathaus & Politik', 'Rathaus, Rat und Gemeinde', 'Beschlüsse, Bekanntmachungen und Projekte der Gemeinde Merzenich.'],
        'sport' => ['Sport', 'Sport in Merzenich', 'Spielberichte und Neues aus den Sportvereinen der Gemeinde.'],
        'leben' => ['Leben', 'Leben in Merzenich', 'Schule, Familie, Kirche, Senioren und Alltag in den fünf Orten.'],
        'wirtschaft' => ['Wirtschaft', 'Wirtschaft und Arbeit', 'Betriebe, Arbeit, Infrastruktur und Strukturwandel im Rheinischen Revier.'],
        'vereine' => ['Vereine', 'Aus den Vereinen', 'Meldungen, Feste und Termine der Vereine in Merzenich.'],
    ];
    if (is_category() && $o instanceof WP_Term && isset($TEXTE[$o->slug])) return $TEXTE[$o->slug];
    if (is_tax('ma_location') && $o instanceof WP_Term) return ['Ort', $o->name, $o->description ?: "Meldungen aus {$o->name}."];
    if (is_tag() && $o instanceof WP_Term) return [(string) (ma21_thema_ressort((string) $o->slug)['ressortTitel'] ?? 'Thema'), $o->name, $o->description ?: "Alle Meldungen zum Thema {$o->name}."];
    if (is_search()) return ['Suche', 'Suche: ' . get_search_query(), ''];
    if ($o instanceof WP_Term) return [$o->name, $o->name, $o->description];
    return ['Nachrichten', 'Alle Meldungen', 'Alle Meldungen aus der Gemeinde Merzenich, die jüngste zuerst.'];
}

/** Übergeordnete Seite in den Brotkrumen einer Liste (Sammelseite: ihr Ressort), sonst null. */
function ma21_liste_eltern(): ?array {
    $rs = ma21_rubrik_aktuell();
    if (!$rs && is_tag() && ($o = get_queried_object()) instanceof WP_Term) $rs = ma21_thema_ressort((string) $o->slug);
    return $rs ? [(string) $rs['ressortTitel'], home_url((string) $rs['ressort'])] : null;
}

/* ------------------------------------------------------------ Sammelseiten der roten Menütitel */

/**
 * Sammelseiten (Wunsch Betreiber 15.10.2026): Ein roter Titel im Aufklappmenü,
 * für den es keine eigene Seite gibt (Blaulicht › Verkehr, Rathaus › Gemeinde),
 * zeigt unter /rubrik/<slug>/ alle Meldungen mit einem seiner Themen, auf ein
 * Ressort beschränkt oder ohne bestimmte Ressorts. Die Definitionen schreibt
 * deploy/rubrik-prerender.mjs aus deploy/ressort-menue.json nach
 * inc/rubriken.json. Die Seiten stehen auf noindex: Die Themenseiten bleiben
 * das, was Suchmaschinen finden sollen.
 */
function ma21_rubriken_datei(): array {
    static $d = null;
    if ($d !== null) return $d;
    $datei = __DIR__ . '/rubriken.json';
    $j = is_readable($datei) ? json_decode((string) file_get_contents($datei), true) : null;
    return $d = is_array($j) ? $j : [];
}
function ma21_rubriken(): array {
    $d = ma21_rubriken_datei();
    return is_array($d['rubriken'] ?? null) ? $d['rubriken'] : [];
}
/** Ressort einer Themenseite, die ein roter Menütitel öffnet (/thema/feuerwehr/ → Blaulicht), sonst null. */
function ma21_thema_ressort(string $slug): ?array {
    $t = ma21_rubriken_datei()['themenRessort'][$slug] ?? null;
    return is_array($t) && !empty($t['ressort']) ? $t : null;
}
function ma21_rubrik(string $slug): ?array {
    $r = ma21_rubriken();
    return isset($r[$slug]) && is_array($r[$slug]) ? $r[$slug] : null;
}
/** Die Sammelseite der aktuellen Anfrage oder null. */
function ma21_rubrik_aktuell(): ?array {
    $slug = (string) get_query_var('ma_rubrik');
    return $slug !== '' ? ma21_rubrik($slug) : null;
}
/** Abfrage einer Sammelseite: Themen als ODER, Ressort ein- oder ausgeschlossen. */
function ma21_rubrik_args(array $def): array {
    $a = ['post_type' => 'post', 'tag_slug__in' => array_values(array_map('strval', (array) ($def['themen'] ?? [])))];
    if ((string) ($def['kategorie'] ?? '') !== '') $a['category_name'] = (string) $def['kategorie'];
    $ohne = [];
    foreach ((array) ($def['ohneKategorie'] ?? []) as $slug) { $c = get_category_by_slug((string) $slug); if ($c) $ohne[] = (int) $c->term_id; }
    if ($ohne) $a['category__not_in'] = $ohne;
    return $a;
}
/** Hat die Sammelseite veröffentlichte Meldungen? Das Menü blendet leere Titel aus (10 Minuten zwischengespeichert). */
function ma21_rubrik_hat_beitraege(string $slug): bool {
    $def = ma21_rubrik($slug);
    if (!$def) return false;
    $c = get_transient('ma21_rubrik_zahlen');
    if (!is_array($c)) $c = [];
    if (!array_key_exists($slug, $c)) {
        $c[$slug] = count(get_posts(ma21_rubrik_args($def) + ['post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'ignore_sticky_posts' => true, 'no_found_rows' => true]));
        set_transient('ma21_rubrik_zahlen', $c, 10 * MINUTE_IN_SECONDS);
    }
    return (int) $c[$slug] > 0;
}
add_action('transition_post_status', function (string $neu, string $alt, WP_Post $p): void {
    if ($p->post_type === 'post' && ($neu === 'publish' || $alt === 'publish')) delete_transient('ma21_rubrik_zahlen');
}, 10, 3);
add_action('init', function (): void {
    add_rewrite_rule('^rubrik/([a-z0-9-]+)/?$', 'index.php?ma_rubrik=$matches[1]', 'top');
    add_rewrite_rule('^rubrik/([a-z0-9-]+)/page/([0-9]+)/?$', 'index.php?ma_rubrik=$matches[1]&paged=$matches[2]', 'top');
});
add_filter('query_vars', function (array $v): array { $v[] = 'ma_rubrik'; return $v; });
add_action('pre_get_posts', function (WP_Query $q): void {
    if (is_admin() || !$q->is_main_query() || (string) $q->get('ma_rubrik') === '') return;
    $def = ma21_rubrik((string) $q->get('ma_rubrik'));
    // Unbekannte Sammelseite: keine Meldungen, pre_handle_404 antwortet mit 404.
    if (!$def) { $q->set('post__in', [0]); $q->is_home = false; return; }
    foreach (ma21_rubrik_args($def) as $k => $v) $q->set($k, $v);
    $q->set('orderby', 'date'); $q->set('order', 'DESC'); $q->set('ignore_sticky_posts', true);
    $q->is_home = false; $q->is_archive = true; $q->is_404 = false;
});
add_filter('pre_handle_404', function ($stop, $q) {
    if (!$q->is_main_query() || (string) $q->get('ma_rubrik') === '') return $stop;
    // Bekannte Sammelseite: auch leer eine Seite; nur jenseits der letzten Seite und für unbekannte Namen 404.
    if (ma21_rubrik((string) $q->get('ma_rubrik')) && !($q->is_paged() && !$q->posts)) return true;
    $q->set_404(); status_header(404); nocache_headers();
    return true;
}, 10, 2);
add_filter('template_include', fn($t) => ma21_rubrik_aktuell() !== null && !is_404() ? (locate_template('archive.php') ?: $t) : $t);
add_action('template_redirect', function (): void {
    if (ma21_rubrik_aktuell() !== null && !headers_sent()) header('X-Robots-Tag: noindex, follow');
});
/** Titel, Adresse, Brotkrumen und noindex der Sammelseiten (Plugin seo.php, ab 1.28.0). */
add_filter('ma_seo_kontext', function (array $k): array {
    $rs = ma21_rubrik_aktuell();
    if ($rs === null || is_404()) return $k;
    $home = home_url('/');
    $url = home_url('/rubrik/' . (string) get_query_var('ma_rubrik') . '/');
    return array_merge($k, ['typ' => 'liste', 'titel' => $rs['titel'] . ' · ' . $rs['ressortTitel'], 'beschreibung' => (string) $rs['beschreibung'],
        'url' => function_exists('ma_seo_liste_url') ? ma_seo_liste_url($url) : $url, 'index' => false,
        'krumen' => [['Start', $home], [(string) $rs['ressortTitel'], home_url((string) $rs['ressort'])], [(string) $rs['titel'], null]],
        'liste' => function_exists('ma_seo_liste') ? ma_seo_liste() : []]);
});
/* Neue Adressen (/rubrik/) brauchen neu geschriebene Umschreibregeln. Das
   Ersetzen des Themes per Upload löst after_switch_theme nicht aus; deshalb
   einmal je Theme-Version neu schreiben (zusätzlich Permalinks speichern). */
add_action('init', function (): void {
    $v = (string) wp_get_theme(get_template())->get('Version');
    if ($v === '' || get_option('ma21_umschreib_stand') === $v) return;
    flush_rewrite_rules(false);
    update_option('ma21_umschreib_stand', $v, true);
}, 99);

/* ------------------------------------------------------------ Adressen der statischen Seite */

/* /nachrichten/ = alle Meldungen (statisch: Liste aller Ressorts). /api/weather.json
   liefert Open-Meteo wie der Dienst der statischen Seite (cockpit.js, app.js). */
add_action('init', function (): void {
    add_rewrite_rule('^nachrichten/?$', 'index.php?ma_alle=1', 'top');
    add_rewrite_rule('^nachrichten/page/([0-9]+)/?$', 'index.php?ma_alle=1&paged=$matches[1]', 'top');
    add_rewrite_rule('^api/weather\.json/?$', 'index.php?ma_api=weather', 'top');
    // Die beiden Abrufe aus assets/v20.js (Sportmodul, redaktionelle Übersteuerung) liefen auf WordPress ins Leere (404).
    add_rewrite_rule('^api/(sport-current|editorial-current)\.json/?$', 'index.php?ma_api=$matches[1]', 'top');
    // /unternehmen/ wie auf der statischen Seite (Aufbau wie Oberberg Aktuell, 30.09.2026).
    add_rewrite_rule('^unternehmen/?$', 'index.php?ma_unternehmen=1', 'top');
});
add_filter('query_vars', function (array $v): array { $v[] = 'ma_alle'; $v[] = 'ma_api'; $v[] = 'ma_unternehmen'; return $v; });
/**
 * Beiträge der Unternehmen für /unternehmen/ (Vorgabe Betreiber 04.10.2026):
 * gesponserte Beiträge (ma_gesponsert) und Beiträge der Unternehmens-Zugänge.
 * Wirtschaftsnachrichten der Redaktion gehören nicht dazu, die stehen unter /wirtschaft/.
 */
function ma21_unternehmen_ids(): array {
    static $ids = null;
    if ($ids !== null) return $ids;
    $a = get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 200, 'fields' => 'ids', 'meta_key' => 'ma_gesponsert', 'meta_value' => '1']);
    $nutzer = get_users(['role' => 'ma_wirtschaft_partner', 'fields' => 'ID']);
    $b = $nutzer ? get_posts(['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 200, 'fields' => 'ids', 'author__in' => array_map('intval', (array) $nutzer)]) : [];
    return $ids = array_values(array_unique(array_map('intval', array_merge((array) $a, (array) $b))));
}
add_action('pre_get_posts', function (WP_Query $q): void {
    if (is_admin() || !$q->is_main_query() || !$q->get('ma_unternehmen')) return;
    $ids = ma21_unternehmen_ids();
    $q->set('post_type', 'post'); $q->set('post__in', $ids ?: [0]); $q->set('posts_per_page', 60); $q->set('orderby', 'date'); $q->set('order', 'DESC');
    $q->is_home = false; $q->is_archive = true; $q->is_404 = false;
});
add_filter('template_include', fn($t) => get_query_var('ma_unternehmen') ? (locate_template('unternehmen.php') ?: $t) : $t);
// Auch ohne Meldung ist /unternehmen/ eine Seite (Kanäle, Angebote), kein 404.
add_filter('pre_handle_404', fn($stop, $q) => ($q->is_main_query() && $q->get('ma_unternehmen')) ? true : $stop, 10, 2);

/** Karte der Unternehmensseite: Bild oben, Kicker, Titel, Zeile, Anriss, Weiterlesen. */
function ma21_u_karte(WP_Post $p, int $i): string {
    $url = esc_url(get_permalink($p)); $titel = ma21_e(get_the_title($p)); $b = ma21_bild($p);
    $ort = ma21_ort($p);
    return '<article class="u-karte' . ($b ? '' : ' u-karte--ohne-bild') . '"' . ($i >= 8 ? ' data-nachladen hidden' : '') . '>'
        . ($b ? "<a class=\"u-karte__bild\" href=\"{$url}\" tabindex=\"-1\" aria-hidden=\"true\">" . ma21_img($b, MA21_SIZES['unternehmen'], $i < 2) . ma21_badge($b, false) . '</a>' : '')
        . '<p class="u-karte__kicker">' . ma21_e(MA21_ORTE[$ort] ?? 'Wirtschaft') . (function_exists('ma_ist_gesponsert') && ma_ist_gesponsert($p) ? '<span class="gesponsert">Anzeige · Gesponsert</span>' : '') . '</p>'
        . "<h2><a href=\"{$url}\">{$titel}</a></h2>"
        // Beiträge von Unternehmen sind Anzeigen: Absender ist die Firma, nicht die Redaktion (21.18.0).
        . '<p class="u-karte__meta">' . ma21_u_absender($p) . ' · <time datetime="' . esc_attr(get_the_date('c', $p)) . '">' . esc_html(ma21_zeit_text($p, true, ', ')) . '</time></p>'
        . '<p class="u-karte__teaser">' . ma21_e(ma21_teaser($p)) . '</p>'
        . "<a class=\"u-karte__weiter\" href=\"{$url}\">Weiterlesen<span class=\"sr-only\">: {$titel}</span></a></article>";
}
/** Absender einer Karte auf /unternehmen/: „Anzeige · Firma“ (mit Link zum Kanal) oder „Redaktion“. */
function ma21_u_absender(WP_Post $p): string {
    if (!function_exists('ma_ist_gesponsert') || !ma_ist_gesponsert($p)) return 'Redaktion';
    $bid = (int) get_post_meta($p->ID, 'ma_business_id', true);
    $von = (string) get_post_meta($p->ID, 'ma_gesponsert_von', true) ?: ($bid ? (string) get_the_title($bid) : 'Auftraggeber');
    $kanal = $bid && get_post_status($bid) === 'publish' && function_exists('ma_business_kanal_url') ? ma_business_kanal_url($bid) : '';
    return 'Anzeige · ' . ($kanal !== '' ? '<a href="' . esc_url($kanal) . '">' . ma21_e($von) . '</a>' : ma21_e($von));
}
/*
 * Feste Reihenfolge bei gleichem Datum (21.15.1). Viele importierte Meldungen
 * tragen dieselbe Zeit (z. B. 04.09., 00:00). Die Datenbank gibt sie dann je
 * nach Abfrage verschieden aus, und das Layout-Board zeigte andere Karten als
 * die Seite; nach einem Tausch sprangen die automatisch belegten Plätze. Bei
 * gleichem Datum entscheidet die Beitragsnummer aufsteigend, wie die Seite es
 * schon zeigt.
 */
add_filter('posts_orderby', function (string $orderby): string {
    global $wpdb;
    $datum = "{$wpdb->posts}.post_date DESC";
    return trim($orderby) === $datum ? $datum . ", {$wpdb->posts}.ID ASC" : $orderby;
});
// Keine Schrägstrich-Umleitung für /api/weather.json (die Skripte rufen genau diese Adresse).
add_filter('redirect_canonical', fn($ziel) => get_query_var('ma_api') ? false : $ziel);
add_action('pre_get_posts', function (WP_Query $q): void {
    if (!is_admin() && $q->is_main_query() && $q->get('ma_alle')) {
        $q->set('post_type', 'post'); $q->set('posts_per_page', ma21_raster_anzahl('ressort-nachrichten'));
        if ($q->get('ma_ohne_sport') && ($sport = get_category_by_slug('sport'))) $q->set('category__not_in', [(int) $sport->term_id]);
        $q->is_home = false; $q->is_archive = true; $q->is_404 = false;
    }
    // Suche: nur Meldungen. Vereinsprofile und Formularseiten erschienen als „Nachrichten“ mit Datum
    // und Lesezeit vor der passenden Meldung (Vorführ-Check 15.10.2026).
    if (!is_admin() && $q->is_main_query() && $q->is_search() && !$q->get('post_type')) $q->set('post_type', 'post');
    // Ressorts mit Kartenraster: Aufmacher plus gerade Kartenzahl je Seite.
    if (!is_admin() && $q->is_main_query() && $q->is_category()) {
        $slug = (string) $q->get('category_name');
        if ($slug !== '' && !str_contains($slug, '/') && ma21_raster_seite('ressort-' . $slug)) $q->set('posts_per_page', ma21_raster_anzahl('ressort-' . $slug));
    }
});
add_action('template_redirect', function (): void {
    if (get_query_var('ma_api') !== 'weather') return;
    $daten = get_transient('ma21_wetter');
    if (!$daten) {
        $url = 'https://api.open-meteo.com/v1/forecast?latitude=50.8317&longitude=6.5361&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&timezone=Europe%2FBerlin&forecast_days=3';
        $r = wp_remote_get($url, ['timeout' => 6]);
        if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
            $daten = wp_remote_retrieve_body($r);
            set_transient('ma21_wetter', $daten, 10 * MINUTE_IN_SECONDS);
        }
    }
    nocache_headers();
    if (!$daten) { status_header(503); wp_send_json(['fehler' => 'Wetter nicht verfügbar']); }
    header('Content-Type: application/json; charset=utf-8');
    echo $daten; exit;
});

/**
 * /api/sport-current.json: der Spielstand des SC Merzenich. Zuerst der Stand aus
 * dem Backend (Plugin, ma_sport_als_json), sonst der aus chatgpt-site/api/ im Repository geholte,
 * 15 Minuten zwischengespeichert, mit Notkopie, falls GitHub gerade nicht antwortet
 * (ma21_repo_datei). /api/editorial-current.json: die
 * redaktionelle Übersteuerung der statischen Startseite; auf WordPress entscheidet
 * das Board „Startseite & Ressorts“, darum eine leere Antwort statt eines 404.
 */
add_action('template_redirect', function (): void {
    $api = (string) get_query_var('ma_api');
    if ($api === 'editorial-current') {
        header('Content-Type: application/json; charset=utf-8');
        ma21_cache(600);
        echo wp_json_encode(['generated' => (string) wp_date('c'), 'hinweis' => 'Auf WordPress entscheidet die Redaktion im Board „Startseite & Ressorts“; diese Datei setzt hier nichts.', 'hero' => null, 'secondary' => []], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($api !== 'sport-current') return;
    $daten = ma21_repo_datei('api/sport-current.json', 15 * MINUTE_IN_SECONDS);
    // Seit 21.11.0: was die Redaktion im Backend (Merzenich Aktuell → Sport) pflegt,
    // gilt, sobald es mindestens so neu ist wie der Stand im Repository.
    $backend = function_exists('ma_sport_als_json') ? ma_sport_als_json() : null;
    $repo = json_decode($daten, true);
    if (is_array($backend) && (!is_array($repo) || strtotime((string) $backend['generated']) >= strtotime((string) ($repo['generated'] ?? '')))) {
        header('Content-Type: application/json; charset=utf-8');
        ma21_cache(300);
        echo wp_json_encode($backend, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); exit;
    }
    if (!is_array(json_decode($daten, true))) $daten = (string) get_option('ma21_sport_current_kopie', '');
    if ($daten === '') { status_header(503); nocache_headers(); wp_send_json(['fehler' => 'Spielstand nicht verfügbar']); }
    header('Content-Type: application/json; charset=utf-8');
    ma21_cache(600);
    echo $daten; exit;
});

/* Symbole und Feed. Seit 21.12.0 liefert die Seite /favicon.ico, /apple-touch-icon.png
   und /manifest.webmanifest selbst aus (vorher Umleitungen auf das 1024er PNG; Handys
   behielten dann gespeicherte Symbole früherer Besuche, Meldung Betreiber 06.10.2026).
   Dateien: chatgpt-site/assets/img/ aus deploy/symbole.mjs. */
const MA21_SYMBOLE = [
    '/favicon.ico' => ['img/favicon.ico', 'image/x-icon'],
    '/apple-touch-icon.png' => ['img/icon-180.png', 'image/png'],
    '/apple-touch-icon-precomposed.png' => ['img/icon-180.png', 'image/png'],
];

/** Datei aus static/ (Theme-Paket) als Antwort, kurz zwischengespeichert. */
function ma21_symbol_senden(string $datei, string $typ): void {
    $pfad = get_template_directory() . '/static/' . $datei;
    if (!is_readable($pfad)) { wp_redirect(home_url('/assets/' . $datei), 302, 'Merzenich Aktuell'); exit; }
    status_header(200);
    header('Content-Type: ' . $typ);
    header('Content-Length: ' . (string) filesize($pfad));
    ma21_cache(DAY_IN_SECONDS);
    readfile($pfad);
    exit;
}

/** Web-Manifest für Android und „Zum Home-Bildschirm“ (Symbole mit neuen Namen, damit Zwischenspeicher sie neu laden). */
function ma21_manifest(): array {
    return [
        'name' => 'Merzenich Aktuell', 'short_name' => 'Merzenich',
        'description' => 'Nachrichten aus Merzenich, Golzheim, Girbelsrath, Morschenich und Bürgewald',
        'start_url' => '/?source=pwa', 'scope' => '/', 'display' => 'standalone', 'lang' => 'de',
        'background_color' => '#fdfdfc', 'theme_color' => '#fdfdfc', 'categories' => ['news'],
        'icons' => [
            ['src' => '/assets/img/icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/assets/img/icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/assets/img/icon-180.png', 'sizes' => '180x180', 'type' => 'image/png', 'purpose' => 'any'],
        ],
        'shortcuts' => [['name' => 'Blaulicht', 'url' => '/blaulicht/'], ['name' => 'Termine', 'url' => '/termine/'], ['name' => 'Meldung senden', 'url' => '/meldung-senden/']],
    ];
}

add_action('do_faviconico', function (): void { ma21_symbol_senden(...MA21_SYMBOLE['/favicon.ico']); });
add_action('template_redirect', function (): void {
    $pfad = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    if (isset(MA21_SYMBOLE[$pfad])) ma21_symbol_senden(...MA21_SYMBOLE[$pfad]);
    if ($pfad === '/manifest.webmanifest' || $pfad === '/site.webmanifest') {
        status_header(200);
        header('Content-Type: application/manifest+json; charset=utf-8');
        ma21_cache(DAY_IN_SECONDS);
        echo wp_json_encode(ma21_manifest(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }
}, 0);

/** Symbol-Links im Kopf (ersetzen die drei Links aus vorlagen/kopf-assets.html, siehe ma21_kopf_assets). */
function ma21_symbol_links(): string {
    return '<link rel="icon" href="/favicon.ico" sizes="48x48">' . "\n"
        . '<link rel="icon" href="/assets/img/favicon.svg?v=2" type="image/svg+xml">' . "\n"
        . '<link rel="icon" href="/assets/img/favicon-32.png?v=2" type="image/png" sizes="32x32">' . "\n"
        . '<link rel="apple-touch-icon" href="/apple-touch-icon.png?v=2" sizes="180x180">' . "\n"
        . '<link rel="manifest" href="/manifest.webmanifest">' . "\n"
        . '<meta name="apple-mobile-web-app-title" content="Merzenich Aktuell">' . "\n";
}

/* WordPress selbst (Login, RSS, REST „site_icon_url“) meldet dasselbe Symbol. */
add_filter('get_site_icon_url', function (string $url, int $groesse): string {
    return home_url($groesse > 0 && $groesse <= 48 ? '/assets/img/favicon-32.png' : ($groesse <= 180 ? '/apple-touch-icon.png' : '/assets/img/icon-512.png'));
}, 10, 2);
// Im Seitenkopf stehen die eigenen Links (ma21_kopf_assets); WordPress' eigene nur auf Login und Verwaltung.
add_action('init', function (): void { remove_action('wp_head', 'wp_site_icon', 99); });
add_filter('rest_index', function ($antwort) {
    if ($antwort instanceof WP_REST_Response) { $d = $antwort->get_data(); $d['site_icon_url'] = home_url('/assets/img/icon-512.png'); $antwort->set_data($d); }
    return $antwort;
});

add_action('wp_head', function (): void {
    echo '<link rel="alternate" type="application/rss+xml" title="Merzenich Aktuell" href="' . esc_url(home_url('/feed/')) . '">' . "\n";
}, 2);

/* Nach einem Theme-Update Regeln und .htaccess einmal neu schreiben (Assets, Adressen). */
add_action('init', function (): void {
    $v = wp_get_theme(get_template())->get('Version');
    if (get_option('ma21_regeln') === $v) return;
    flush_rewrite_rules(true);
    update_option('ma21_regeln', $v, false);
}, 99);

/**
 * Links im Text auf eigene, (noch) nicht veröffentlichte Beiträge (21.13.0): Der
 * Abgleich übernimmt Termine und Meldungen mit Querverweisen („Zur Meldung“), die
 * Gegenstücke warten aber oft noch auf Freigabe. Solche Links liefen ins Leere
 * (Vollprüfung 06.10.2026: Terminseite MSG Hitnight). Der Linktext bleibt stehen.
 */
function ma21_links_ohne_entwuerfe(string $html, callable $status): string {
    if (!str_contains($html, '<a ')) return $html;
    $host = (string) parse_url(home_url('/'), PHP_URL_HOST);
    return (string) preg_replace_callback('#<a\s[^>]*href="((?:https?://' . preg_quote($host, '#') . ')?/[^"\#?]*)[^"]*"[^>]*>(.*?)</a>#is', function (array $m) use ($status): string {
        $s = $status($m[1]);
        return $s !== null && $s !== 'publish' ? $m[2] : $m[0];
    }, $html);
}
add_filter('the_content', function (string $html): string {
    if (is_admin() || !is_singular()) return $html;
    // url_to_postid() findet für Besucher nur Veröffentlichtes, daher über den Namen (letzter Pfadteil).
    return ma21_links_ohne_entwuerfe($html, function (string $url): ?string {
        $pfad = trim((string) parse_url($url, PHP_URL_PATH), '/');
        if ($pfad === '' || str_starts_with($pfad, 'wp-') || str_contains($pfad, '.')) return null;
        $ids = get_posts(['name' => basename($pfad), 'post_type' => ['post', 'page', 'ma_event', 'ma_club', 'ma_job', 'ma_property', 'ma_tip', 'ma_business'],
            'post_status' => ['publish', 'draft', 'pending', 'future', 'private'], 'posts_per_page' => 5, 'fields' => 'ids', 'no_found_rows' => true, 'suppress_filters' => true]);
        if (!$ids) return null;
        foreach ($ids as $id) if (get_post_status($id) === 'publish') return 'publish';
        return 'entwurf';
    });
}, 20);
